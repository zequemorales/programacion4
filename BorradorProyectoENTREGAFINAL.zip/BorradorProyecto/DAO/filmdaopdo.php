<?php

namespace DAO;

use Models\Film as Film;
use Models\Genre as Genre;
use DAO\connection as Connection;


class FilmDAOPDO
{

    private $connection;
    private $tableName = "pelicula";
    private $tableName2 = "pelXgen";
    private $tableName3 = "genero";
    private $pdo = null;

    # Agrega una pelicula a la base de datos
    public function Add(Film $film)
    {
        try {
            $query =  "INSERT INTO " . $this->tableName . "(idPelicula, titulo , duracion, descripcion, lenguaje, imagen) VALUES (:id_film, :title, :duration, :description, :lenguaje, :imagen);";

            $parameters["id_film"] = $film->getIdFilm();
            $parameters["title"] = $film->getTitle();
            //$parameters["genre"] = $film->getGenre(); // Genero puede tener mas de 1 genero
            $parameters["lenguaje"] = $film->getLanguage();
            $parameters["description"] = $film->getDescription();
            $parameters["duration"] = $film->getDuration();
            $parameters["imagen"] = $film->getUrlImage();

            $this->connection =  Connection::GetInstance();

            $this->connection->ExecuteNonQuery($query, $parameters);
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    public function AddGenre(Genre $genre)
    {
        try {
            $query =  "INSERT INTO " . $this->tableName3 . "(idGenero, descripcion) VALUES (:idGenre, :description);";

            $parameters["idGenre"] = $genre->getIdGenre();
            $parameters["description"] = $genre->getDescription();

            $this->connection =  Connection::GetInstance();
            $this->connection->ExecuteNonQuery($query, $parameters);
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Agrega los generos de una determinada pelicula
    public function AddFilmGenre(Film $film)
    {
        try {
            $query =  "INSERT INTO " . $this->tableName2 . "(idPelicula, idGenero) VALUES (:id_film, :id_genre);";

            $parameters["id_film"] = $film->getIdFilm();

            foreach ($film->getGenre() as $idGenre) {
                $parameters["id_genre"] = $idGenre;
                $this->connection =  Connection::GetInstance();
                $this->connection->ExecuteNonQuery($query, $parameters);
            }
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Devuelve la pelicula por titulo.
    public function GetFilmByTitle($title)
    {
        try {
            $filmFound = null;

            $query = "SELECT * FROM " . $this->tableName . " where titulo = :title";

            $parameters[":title"] = $title;

            $this->connection = Connection::GetInstance();

            $resultSet = $this->connection->Execute($query);

            foreach ($resultSet as $row) {
                $filmFound = new Film();
                $filmFound->setIdFilm($row["idPelicula"]);
                $filmFound->setTitle($row["titulo"]);
                $filmFound->setLanguage($row["lenguaje"]);
                $filmFound->setDescription($row["descripcion"]);
                $filmFound->setDuration($row["duracion"]);
                $filmFound->setUrlImage($row["urlImage"]);
            }

            return $filmFound;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }
    # Devuelve una pelicula por ID. VER INNER JOIN!!!
    public function GetFilmByID($filmID)
    {
        try {
            $filmFound = null;

            $query = "SELECT titulo, duracion, lenguaje, pelicula.descripcion, imagen , 
                                 genero.descripcion AS gendescripcion, genero.idGenero AS genidGenero 
                          FROM " . $this->tableName . "
                          INNER JOIN pelXgen ON pelXgen.idPelicula = pelicula.idPelicula 
                          INNER JOIN genero ON genero.idGenero = pelXgen.idGenero
                          WHERE pelXgen.idPelicula = :filmID";

            $parameters["filmID"] = $filmID;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            if ($resultSet != null) {
                $filmFound = new Film();

                $filmFound->setIdFilm($filmID);
                $filmFound->setTitle($resultSet[0]["titulo"]);

                foreach ($resultSet as $row) {
                    $genre = new Genre();
                    $genre->setIdGenre($row["genidGenero"]);
                    $genre->setDescription($row["gendescripcion"]);

                    $filmFound->setGenre($genre);
                }
                $filmFound->setLanguage($row["lenguaje"]);
                $filmFound->setDescription($row["descripcion"]);
                if ($row["duracion"] == NULL) {
                    $durationDefault = 132;
                    $filmFound->setDuration($durationDefault);
                } else {
                    $filmFound->setDuration($row["duracion"]);
                }

                $filmFound->setUrlImage($row["imagen"]);
            }

            return $filmFound;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Devuelve todos las peliculas de la BD en una lista
    public function GetAll()
    {
        try {
            $filmList = array();

            $query = "SELECT * FROM " . $this->tableName;

            $this->connection = Connection::GetInstance();

            $resultSet = $this->connection->Execute($query);

            foreach ($resultSet as $row) {
                $film = new Film();
                $film->setIdFilm($row["idPelicula"]);
                $film->setTitle($row["titulo"]);

                $film->setDescription($row["descripcion"]);
                $film->setDuration($row["duracion"]);
                $film->setLanguage($row["lenguaje"]);
                $film->setUrlImage($row["imagen"]);

                array_push($filmList, $film);
            }

            return $filmList;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Devuelve un genero por descripcion. Sirve para actualizar la BD de generos.
    public function GetGenreByDescription($description)
    {
        try {
            $genreFound = null;

            $query = "SELECT * FROM " . $this->tableName3 . " WHERE descripcion = :description";

            $parameters[":description"] = $description;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $genreFound = new Genre();

                $genreFound->setIdGenre($row["idGenero"]);
                $genreFound->setDescription($row["descripcion"]);
            }

            return $genreFound;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    public function GetAllGenre()
    {
        try {
            $genreList = array();

            $query = "SELECT * FROM " . $this->tableName3;

            $this->connection = Connection::GetInstance();

            $resultSet = $this->connection->Execute($query);

            foreach ($resultSet as $row) {
                $genre = new Genre();
                $genre->setIdGenre($row["idGenero"]);
                $genre->setDescription($row["descripcion"]);

                array_push($genreList, $genre);
            }

            return $genreList;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    public function GetFilmsInProyections()
    {
        try {
            $filmList = array();

            $query = "SELECT * FROM " . $this->tableName . " 
                         INNER JOIN proyeccion 
                         ON proyeccion.idPelicula = pelicula.idPelicula
                         GROUP BY pelicula.titulo";

            $this->connection = Connection::GetInstance();

            $resultSet = $this->connection->Execute($query);

            foreach ($resultSet as $row) {
                $film = new Film();
                $film->setIdFilm($row["idPelicula"]);
                $film->setTitle($row["titulo"]);

                $film->setDescription($row["descripcion"]);
                $film->setDuration($row["duracion"]);
                $film->setLanguage($row["lenguaje"]);
                $film->setUrlImage($row["imagen"]);

                array_push($filmList, $film);
            }

            return $filmList;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }


    ########### GET DE LA API. PELICULAS Y GENEROS ##########

    # Trae peliculas desde la API. Las  inserta a una lista de peliculas.
    public function GetFilmListFromAPI()
    {
        $this->filmList = array();
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.themoviedb.org/3/movie/now_playing?page=1&language=es-LA&api_key=4a93bb257170667e57d0c5ce5571ae6f",  // PAGINA 1,2,3,4,5...ETC
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_POSTFIELDS => "{}",
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        }
        $arrayToDecode = json_decode($response, true);
        $totalPages = $arrayToDecode["total_pages"];
        // No me trae todas las peliculas (66 paginas) tira error "time exceeded 30 secs". Le seteo 5 paginas
        for ($i = 1; $i <= 5; $i++) {

            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.themoviedb.org/3/movie/now_playing?page=" . $i . "&language=es-LA&api_key=4a93bb257170667e57d0c5ce5571ae6f",  // PAGINA 1,2,3,4,5...ETC
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_POSTFIELDS => "{}",
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
                echo "cURL Error #:" . $err;
            }

            $arrayToDecode2 = json_decode($response, true);

            foreach ($arrayToDecode2["results"] as $valuesArray) {
                $film = new Film();

                $film->setIdFilm($valuesArray["id"]);
                $film->setTitle($valuesArray["title"]);
                // Array genero
                foreach ($valuesArray["genre_ids"] as $genres) {
                    $film->setGenre($genres);
                }
                $film->setLanguage($valuesArray["original_language"]);
                $film->setDescription($valuesArray["overview"]);
                $film->setUrlImage($valuesArray["poster_path"]);
                /// LLAMADA PARA LA DURACION //


                $curl2 = curl_init();

                curl_setopt_array($curl2, array(
                    CURLOPT_URL => "https://api.themoviedb.org/3/movie/" . $valuesArray["id"] . "?language=en-US&api_key=4a93bb257170667e57d0c5ce5571ae6f",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_POSTFIELDS => "{}",
                ));

                $response2 = curl_exec($curl2);
                $err2 = curl_error($curl2);

                curl_close($curl2);

                if ($err2) {
                    echo "cURL Error #:" . $err2;
                }

                $arrayToDecode3 = json_decode($response2, true);

                $duracionPeli = $arrayToDecode3["runtime"];
                // SETEO LA DURACION OBTENIDA  SI LA DURACION ES NULL LE SETEO 120 


                $film->setDuration($duracionPeli);

                array_push($this->filmList, $film);
            }
        }
        return $this->filmList;
    }

    // Trae generos desde la API. Las inserta en una lista de generos.
    public function GetGenreListFromAPI()
    {
        $this->genreList = array();

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.themoviedb.org/3/genre/movie/list?language=es-LA&api_key=4a93bb257170667e57d0c5ce5571ae6f",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_POSTFIELDS => "{}",
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        }
        $arrayToDecode = json_decode($response, true);

        foreach ($arrayToDecode["genres"] as $valuesArray) {
            $genre = new Genre();
            $genre->setIdGenre($valuesArray["id"]);
            $genre->setDescription($valuesArray["name"]);

            array_push($this->genreList, $genre);
        }
        return $this->genreList;
    }
}
