<?php

namespace DAO;

use Models\Ticket as Ticket;
use Models\Purchase as Purchase;

/**
 * 
 */
class TicketDAOPDO
{
    private $connection;
    private $tableName = 'entrada';

    # Agrego una entrada a la base de datos.
    public function Add(Ticket $ticket, $idProyection, $purchaseID)
    {
        try {
            $query =  "INSERT INTO " . $this->tableName . "(idProyeccion , idCompra, nroEntrada, qrCode) VALUES ( :idProyection, :purchaseID, :nroEntrada, :qrCode);";

            $parameters["idProyection"] = $idProyection;
            $parameters["purchaseID"] = $purchaseID;
            $parameters["nroEntrada"] = $ticket->getTicketNumber();
            $parameters["qrCode"] = $ticket->getQrCode();

            $this->connection =  Connection::GetInstance();

            $this->connection->ExecuteNonQuery($query, $parameters);
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }


    # Me devuelve si existe una entrada con el mismo nro de ticket.
    public function GetTicketByNumber($ticketNumber)
    {
        try {
            $ticket = null;

            $query = "SELECT * FROM " . $this->tableName . " WHERE nroEntrada = :ticketNumber;";

            $parameters["ticketNumber"] = $ticketNumber;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $ticket = new Ticket();

                $ticket->setTicketID($row["idEntrada"]);
                $ticket->setQrCode($row["qrCode"]);
                $ticket->setTicketNumber($row["nroEntrada"]);
            }

            return $ticket;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    public function getTicketByID($ticketID)
    {
        try {
            $ticket = null;

            $query = "SELECT * FROM " . $this->tableName . " 
                INNER JOIN proyeccion ON proyeccion.idProyeccion = entrada.idProyeccion
                INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                INNER JOIN sala ON sala.idSala = proyeccion.idSala
                WHERE idEntrada = :ticketID;";

            $parameters["ticketID"] = $ticketID;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $ticket = new Ticket();

                $ticket->setTicketID($row["idEntrada"]);
                $ticket->setQrCode($row["qrCode"]);
                $ticket->setTicketNumber($row["nroEntrada"]);
            }

            return $ticket;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    public function GetTicketsByIdCompra($idCompra)
    {
        try {
            $ticketsByCompraList = array();

            $query = "SELECT * FROM " . $this->tableName . " 
                INNER JOIN proyeccion ON proyeccion.idProyeccion = entrada.idProyeccion
                INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                INNER JOIN sala ON sala.idSala = proyeccion.idSala
                WHERE idCompra = :idCompra;";

            $parameters["idCompra"] = $idCompra;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);


            foreach ($resultSet as $row) {
                $ticket = new Ticket();

                $ticket->setTicketID($row["idEntrada"]);
                $ticket->setQrCode($row["qrCode"]);
                $ticket->setTicketNumber($row["nroEntrada"]);

                $compra = new Purchase();
                $compra->setIdPurchase($row["idCompra"]);

                $ticket->setPurchase($compra);

                array_push($ticketsByCompraList, $ticket);
            }

            return $ticketsByCompraList;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }
}
