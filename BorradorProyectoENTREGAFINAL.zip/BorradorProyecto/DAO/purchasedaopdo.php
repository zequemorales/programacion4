<?php

namespace DAO;

use Models\Purchase as Purchase;

use DAO\connection as Connection;

/**
 * 
 */
class PurchaseDAOPDO
{
    private $connection;
    private $tableName = 'compra';

    public function Add(Purchase $purchase, $idUser, $idCreditCardPayment)
    {
        try {
            $query =  "INSERT INTO " . $this->tableName . "( idUsuario, idPagoTC , cantEntradas, descuento, fecha, total) VALUES  (:idUsuario, :idPagoTC, :cantEntradas, :descuento, :fecha, :total);";

            $parameters["idUsuario"] = $idUser;
            $parameters["idPagoTC"] = $idCreditCardPayment;
            $parameters["cantEntradas"] = $purchase->getQuantityTickets();
            $parameters["descuento"] = $purchase->getDiscount();
            $parameters["fecha"] = $purchase->getDate();
            $parameters["total"] = $purchase->getTotal();

            $this->connection =  Connection::GetInstance();

            $this->connection->ExecuteNonQuery($query, $parameters);
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    public function GetLastInsertId()
    {
        try {
            $purchaseID = null;

            $query = "SELECT * FROM " . $this->tableName . " ORDER BY idCompra DESC LIMIT 0, 1";

            $this->connection =  Connection::GetInstance();
            $resultSet = $this->connection->Execute($query);

            foreach ($resultSet as $row) {
                $purchaseID = $row["idCompra"];
            }

            return $purchaseID;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Devuelve cantidad de tickets vendidos por una determinada pelicula 
    public function QuantityByIdFilm($idFilm)
    {
        try {
            $cant = null;
            $query = "  SELECT COUNT(cantEntradas) AS 'Ventas' 
                        FROM compra 
                        INNER JOIN entrada ON entrada.idCompra = compra.idCompra
                        INNER JOIN proyeccion ON proyeccion.idProyeccion = entrada.idProyeccion
                        INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                        WHERE pelicula.idPelicula = :idFilm";

            $parameters["idFilm"] = $idFilm;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $cant = $row["Ventas"];
            }

            return $cant;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Devuelve la cantidad de ticket por un Cine determinado
    public function QuantityByIdCinema($idCinema)
    {
        try {
            $cant = null;
            $query = "  SELECT count(cantEntradas) as 'Total Venta Cine' 
                        FROM `compra` 
                        INNER JOIN entrada ON entrada.idCompra = compra.idCompra
                        INNER JOIN proyeccion ON proyeccion.idProyeccion = entrada.idProyeccion
                        INNER JOIN sala ON sala.idSala = proyeccion.idSala
                        INNER JOIN cine ON cine.idCine = sala.idCine
                        WHERE sala.idCine = :idCine";

            $parameters["idCine"] = $idCinema;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $cant = $row["Total Venta Cine"];
            }

            return $cant;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Devuelve a cantidad de tickets por un TURNO determinado
    public function QuantityByTurn($timeStart, $timeEnd)
    {
        try {
            $cant = null;
            $query = "  SELECT count(cantEntradas) as 'Cantidad venta Turno'
                        FROM compra 
                        INNER JOIN entrada ON entrada.idCompra = compra.idCompra
                        INNER JOIN proyeccion ON proyeccion.idProyeccion = entrada.idProyeccion 
                        WHERE proyeccion.hora >= :timeStart AND proyeccion.hora < :timeEnd ";

            $parameters["timeStart"] = $timeStart;
            $parameters["timeEnd"] = $timeEnd;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $cant = $row["Cantidad venta Turno"];
            }

            return $cant;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Devuelve la recaudacion por TITULO de pelicula
    public function GetRecaudationByTitleDate($idFilm, $dateFrom, $dateTo)
    {
        try {
            $recaudation = null;

            $query = " SELECT SUM(t.Recaudacion) AS Total
                        FROM 
                            (SELECT pelicula.titulo, (compra.cantEntradas * sala.valorEntrada) AS 'Recaudacion'
                            FROM `compra`
                            INNER JOIN entrada ON entrada.idCompra = compra.idCompra
                            INNER JOIN proyeccion ON proyeccion.idProyeccion = entrada.idProyeccion
                            INNER JOIN sala ON sala.idSala = proyeccion.idSala
                            INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                            WHERE pelicula.idPelicula = :idFilm 
                            AND compra.fecha >= :dateFrom AND compra.fecha <= :dateTo
                            GROUP BY compra.idCompra) AS t";

            $parameters["idFilm"] = $idFilm;
            $parameters["dateFrom"] = $dateFrom;
            $parameters["dateTo"] = $dateTo;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $recaudation = $row["Total"];
            }
            return $recaudation;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Devuelve la recaudacion por CINE
    public function GetRecaudationByCinemaDate($idCinema, $dateFrom, $dateTo)
    {
        try {
            $recaudation = null;
            $query = "  SELECT Sum(t.Recaudacion) AS Total
                        FROM 
                            (SELECT cine.nombre, (compra.cantEntradas * sala.valorEntrada) AS 'Recaudacion'
                            FROM `compra`
                            INNER JOIN entrada ON entrada.idCompra = compra.idCompra
                            INNER JOIN proyeccion ON proyeccion.idProyeccion = entrada.idProyeccion
                            INNER JOIN sala ON sala.idSala = proyeccion.idSala
                            INNER JOIN cine ON cine.idCine = sala.idCine
                            WHERE cine.idCine = :idCinema
                            AND compra.fecha >= :dateFrom AND compra.fecha <= :dateTo
                            GROUP BY compra.idCompra) AS t";

            $parameters["idCinema"] = $idCinema;
            $parameters["dateFrom"] = $dateFrom;
            $parameters["dateTo"] = $dateTo;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $recaudation = $row["Total"];
            }
            return $recaudation;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }
}
