<?php

namespace DAO;

use Models\cinema as Cinema;

interface ICinemaDAO
{
    public function Add(Cinema $cinema, $arraySalas);
    public function GetAll();
    public function GetCinemaByID($cinemaID);
    public function GetCinemaByName($cinemaName);
    public function GetCinemasByIdFilm($filmID);
    public function Delete($cinemaID);
    public function Modify(Cinema $cinema);
}
