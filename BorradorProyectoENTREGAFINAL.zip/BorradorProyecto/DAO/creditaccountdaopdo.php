<?php

namespace DAO;

use Models\CreditAccount as CreditAccount;
use DAO\connection as Connection;

/**
 * 
 */
class CreditAccountDAOPDO
{
    private $connection;
    private $tableName = 'cuentacredito';


    # Devuelve todas las Cuentas Credito (Visa, Master, AMEX)
    public function GetAll()
    {
        try {
            $creditAccountList = array();

            $query = "SELECT * FROM " . $this->tableName;

            $this->connection = Connection::GetInstance();

            $resultSet = $this->connection->Execute($query);

            foreach ($resultSet as $row) {
                $creditAccount = new CreditAccount();
                $creditAccount->setIdCreditAccount($row["idCuentaCredito"]);
                $creditAccount->setEnterprise($row["empresa"]);

                array_push($creditAccountList, $creditAccount);
            }

            return $creditAccountList;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }
}
