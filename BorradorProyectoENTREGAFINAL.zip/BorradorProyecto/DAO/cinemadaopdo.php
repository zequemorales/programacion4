<?php

namespace DAO;

use DAO\ICinemaDAO as ICinemaDAO;
use Models\Cinema as Cinema;
use Models\Sala as Sala;
use DAO\connection as Connection;


/* 
     Clase Cinema DAO PDO   
*/

class CinemaDAOPDO implements ICinemaDAO
{
    private $connection;
    private $tableName = "cine";
    private $tableName2 = "sala";
    private $pdo = null;



    public function Add(Cinema $cinema, $arraySalas)
    {
        try {

            $query = "CALL Cinema_Add(?, ?, ?)";

            $parameters["nombre"]    = $cinema->getName();
            $parameters["direccion"] = $cinema->getAddress();
            $parameters["activo"]    = $cinema->getIsActive();

            $this->connection = Connection::GetInstance();

            $result = $this->connection->Execute($query, $parameters, QueryType::StoredProcedure);

            $lastID = $result[0]["@id_cinema"];

            foreach ($arraySalas as $sala) {
                $query2 = "INSERT INTO sala (numeroSala, idCine, capacidad, valorEntrada) VALUES (:numeroSala, :idCine, :capacidad, :valorEntrada);";


                $parameters2["numeroSala"] = $sala->getName();
                $parameters2["idCine"] = $lastID;
                $parameters2["capacidad"] = $sala->getCapacity();
                $parameters2["valorEntrada"] = $sala->getPrice();

                $this->connection =  Connection::GetInstance();
                $this->connection->ExecuteNonQuery($query2, $parameters2, QueryType::Query);
            }
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }


    # Devuelve todos los cines en una lista
    public function GetAll()         //devuelve instancias de cines             
    {
        try {
            $cinemaList = array();

            $query = "SELECT cine.idCine, cine.nombre, cine.direccion, cine.activo, count(*) as Cantidad_Salas
                FROM " . $this->tableName . " 
                INNER JOIN sala on sala.idCine=cine.idCine
                group by  cine.idCine;";

            $this->connection = Connection::GetInstance();

            $resultSet = $this->connection->Execute($query);


            foreach ($resultSet as $row) {
                $cinema = new Cinema();
                $cinema->setIdCinema($row["idCine"]);
                $cinema->setName($row["nombre"]);
                $cinema->setAddress($row["direccion"]);
                $cinema->setIsActive($row["activo"]);


                array_push($cinemaList, $cinema);
            }

            return $cinemaList;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Devuelve las salas que tiene un cine 
    public function GetSalasByCinema($idCinema)
    {
        try {
            $salas = array();

            $query = "SELECT * FROM sala WHERE idCine = :idCinema";

            $parameters["idCinema"] = $idCinema;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $sala = new Sala();
                $sala->setIdSala($row["idSala"]);
                $sala->setIdCine($row["idCine"]);
                $sala->setName($row["numeroSala"]);
                $sala->setCapacity($row["capacidad"]);
                $sala->setPrice($row["valorEntrada"]);

                array_push($salas, $sala);
            }
            return $salas;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Devuelve una lista de todas las salas de los cines

    public function GetAllSalas()
    {
        try {
            $salasList = array();
            $query = "SELECT * FROM " . $this->tableName2;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query);

            foreach ($resultSet as $row) {
                $sala = new Sala();
                $sala->setIdSala($row["idSala"]);
                $sala->setName($row["numeroSala"]);
                $sala->setCapacity($row["capacidad"]);
                $sala->setPrice($row["valorEntrada"]);
                $sala->setIdCine($row["idCine"]);

                array_push($salasList, $sala);
            }
            return $salasList;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Devuelve un cine por ID
    public function GetCinemaByID($cinemaID)
    {
        try {
            $cinema = null;

            $query = "SELECT * FROM " . $this->tableName . " WHERE idCine = :cinemaID";

            $parameters["cinemaID"] = $cinemaID;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $cinema = new Cinema();

                $cinema->setIdCinema($row["idCine"]);
                $cinema->setName($row["nombre"]);
                $cinema->setAddress($row["direccion"]);
                $cinema->setIsActive($row["activo"]);
            }

            return $cinema;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    public function GetCinemaByName($cinemaName)
    {
        try {
            $cinema = null;

            $query = "SELECT * FROM " . $this->tableName . " WHERE nombre = :cinemaName";

            $parameters["cinemaName"] = $cinemaName;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $cinema = new Cinema();

                $cinema->setIdCinema($row["idCine"]);
                $cinema->setName($row["nombre"]);
                $cinema->setAddress($row["direccion"]);
                $cinema->setIsActive($row["activo"]);
            }

            return $cinema;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Me trae los cines donde haya una pelicula determinada
    public function GetCinemasByIdFilm($filmID)
    {
        try {
            $cinemaList = array();

            $query = "SELECT cine.idCine, nombre FROM " . $this->tableName .
                " INNER JOIN proyeccion ON proyeccion.idCine = cine.idCine
                            INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                            WHERE pelicula.idPelicula = :filmID";

            $parameters["filmID"] = $filmID;

            $this->connection = Connection::GetInstance();

            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $cinema = new Cinema();
                $cinema->setIdCinema($row["idCine"]);
                $cinema->setName($row["nombre"]);
                /*$cinema->setCapacity($row["capacidad"]);
                    $cinema->setTicketPrice($row["valorEntrada"]);
                    $cinema->setAddress($row["direccion"]);
                    $cinema->setIsActive($row["activo"]);*/

                array_push($cinemaList, $cinema);
            }

            return $cinemaList;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Elimina un cine por ID
    public function Delete($cinemaID)
    {
        try {
            //$query = "DELETE FROM ".$this->tableName." WHERE idArtista = :artistID";
            //$query = "SELECT * FROM ".$this->tableName." WHERE idArtista = :artistID";
            $cinema = null;
            $query = "UPDATE " . $this->tableName . "  SET activo = 0 WHERE idCine = :cinemaID";

            $parameters["cinemaID"] = $cinemaID;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->ExecuteNonQuery($query, $parameters);

            foreach ($resultSet as $row) {
                $cinema = new Cinema();

                $cinema->setIdCinema($row["idCine"]);
                $cinema->setName($row["nombre"]);
                $cinema->setCapacity($row["capacidad"]);
                $cinema->setTicketPrice($row["valorEntrada"]);
                $cinema->setAddress($row["direccion"]);
                $cinema->setIsActive($row["activo"]);

                return $cinema;
            }
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    # Modifica el cine que esta en la base
    public function Modify(Cinema $cinema)
    {
        try {

            $query = "UPDATE " . $this->tableName . "  SET nombre = :nombre, direccion = :direccion, activo = :activo WHERE idCine = :idCine";


            $parameters["idCine"] = $cinema->getIdCinema();
            $parameters["nombre"]  = $cinema->getName();
            //$parameters["capacidad"]  = $cinema->getCapacity();
            //$parameters["valorEntrada"]  = $cinema->getTicketPrice();
            $parameters["direccion"] = $cinema->getAddress();
            $parameters["activo"] = $cinema->getIsActive();

            $this->connection = Connection::GetInstance();

            $this->connection->ExecuteNonQuery($query, $parameters);
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }
}
