<?php

namespace DAO;


use Models\Film as Film;
use Models\Genre as Genre;

/**
 *  DAO Peliculas
 */

class FilmDAO
{
    private $filmList;
    private $genreList;

    public function Add()
    { }



    //********** JSON's ************/  

    private function SaveData()  //MODIFICAR. NO ESTá IMPLEMENTADO
    {
        $arrayToEncode = array();

        foreach ($this->filmList as $film) {
            $valuesArray["idFilm"] = $user->getEmail();
            $valuesArray["title"] = $user->getPassword();

            foreach ($film as $genre) {
                $valuesArray["genre"][] = array(
                    'idGenre' => $genre->getIdGenre(),
                    'description' => $genre->getDescription()
                );
            }
            $valuesArray["language"] = $film->getLanguage();
            $valuesArray["description"] = $film->getDescription();
            $valuesArray["duration"] = $film->getDuration();
            $valuesArray["poster_path"] = $film->getUrlImage();

            //$valuesArray["role"]["description"] = $user->getRole()->getDescription();

            //Rol
            /*$valuesArray["role"] = array();
            foreach ($user->getRole() as $role) { 
                $valuesArray["role"][] = array(
                    'description' => $role->getDescription()
                );
            }*/
            /*foreach ($user->getRole() as $role) {
                $valuesArray["role"][] = array(
                    'description' => $role->getDescription()    
                );*/
            //}

            array_push($arrayToEncode, $valuesArray);
        }
        $jsonContent = json_encode($arrayToEncode, JSON_PRETTY_PRINT);

        $path = $this->GetJsonFilePath();
        file_put_contents($path, $jsonContent);
    }

    public function RetrieveData()
    {
        $this->filmList = array();                  // Crea una Lista

        $jsonPath = $this->GetJsonFilePath();       // Devuelve la ruta donde esta el Json
        $jsonContent = file_get_contents($jsonPath); // recupero el contentido del json

        $arrayToDecode = ($jsonContent) ? json_decode($jsonContent, true) : array();  // convierte un String a formato Json

        foreach ($arrayToDecode as $valuesArray) // Convierto el arreglo a Objetos 
        {
            $film = new Film();

            $film->setIdFilm($valuesArray["idFilm"]);
            $film->setTitle($valuesArray["title"]);
            $film->setGenre($valuesArray["genre"]);
            $film->setLanguage($valuesArray["language"]);
            $film->setDescription($valuesArray["description"]);
            $film->setDuration($valuesArray["duration"]);
            $film->setUrlImage($valuesArray["poster_path"]);

            array_push($this->filmList, $film);  // inserto la factura a la Lista
        }
    }

    public function GetJsonFilePath()
    {
        $initialPath = "Data/films.json";
        if (file_exists($initialPath)) {
            $jsonFilePath = $initialPath;
        } else {
            $jsonFilePath = "../" . $initialPath;
        }
        return $jsonFilePath;
    }

    // Funcion que trae un arreglo de peliculas desde la API THEMOVIEDB
    // Devuelve las "Now playing"
    public function GetJsonFromAPI()
    {
        $this->filmList = array();
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.themoviedb.org/3/movie/now_playing?page=1&language=es-LA&api_key=81a2460dbefd7e043882b50c2b6138ce",  // PAGINA 1,2,3,4,5...ETC
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_POSTFIELDS => "{}",
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        }
        $arrayToDecode = json_decode($response, true);
        $totalPages = $arrayToDecode["total_pages"];
        // No me trae todas las peliculas (66 paginas) tira error "time exceeded 30 secs". Le seteo 7 paginas
        for ($i = 1; $i <= 7; $i++) {

            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.themoviedb.org/3/movie/now_playing?page=" . $i . "&language=es-LA&api_key=81a2460dbefd7e043882b50c2b6138ce",  // PAGINA 1,2,3,4,5...ETC
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_POSTFIELDS => "{}",
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
                echo "cURL Error #:" . $err;
            }

            $arrayToDecode2 = json_decode($response, true);

            foreach ($arrayToDecode2["results"] as $valuesArray) {
                $film = new Film();

                $film->setIdFilm($valuesArray["id"]);
                $film->setTitle($valuesArray["title"]);
                // Array genero
                foreach ($valuesArray["genre_ids"] as $genres) {
                    $film->setGenre($genres);
                }
                $film->setLanguage($valuesArray["original_language"]);
                $film->setDescription($valuesArray["overview"]);
                $film->setUrlImage($valuesArray["poster_path"]);
                //$film->setDuration($valuesArray["duration"]);

                array_push($this->filmList, $film);
            }
        }

        return $this->filmList;
    }


    // ***** (start) JSON Generos ***** //

    // Trae datos desde la API generos.
    public function GetJsonGenre()
    {
        $this->genreList = array();

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.themoviedb.org/3/genre/movie/list?language=es-LA&api_key=81a2460dbefd7e043882b50c2b6138ce",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_POSTFIELDS => "{}",
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        }
        $arrayToDecode = json_decode($response, true);

        foreach ($arrayToDecode["genres"] as $valuesArray) {
            $genre = new Genre();
            $genre->setIdGenre($valuesArray["id"]);
            $genre->setDescription($valuesArray["name"]);

            array_push($this->genreList, $genre);
        }
        return $this->genreList;
    }

    // Trae datos desde el archivo local genres.json
    public function RetrieveGenreData()
    {
        $this->genreList = array();                  // Crea una Lista

        $jsonPath = $this->GetJsonGenreFilePath();       // Devuelve la ruta donde esta el Json
        $jsonContent = file_get_contents($jsonPath); // recupero el contentido del json

        $arrayToDecode = ($jsonContent) ? json_decode($jsonContent, true) : array();  // convierte un String a formato Json

        foreach ($arrayToDecode as $valuesArray) // Convierto el arreglo a Objetos 
        {
            $genre = new Genre();

            $genre->setIdGenre($valuesArray["id"]);
            $genre->setDescription($valuesArray["name"]);

            array_push($this->genreList, $genre);  // inserto la factura a la Lista
        }
    }
    // Guarda de la lista al  Json
    public function SaveGenreData()
    {
        $arrayToEncode = array();

        foreach ($this->genreList as $genre) {
            $valuesArray["id"] = $genre->getIdGenre();
            $valuesArray["name"] = $genre->getDescription();

            array_push($arrayToEncode, $valuesArray);
        }
        $jsonContent = json_encode($arrayToEncode, JSON_PRETTY_PRINT);

        $path = $this->GetJsonGenreFilePath();
        file_put_contents($path, $jsonContent);
    }

    public function GetJsonGenreFilePath()
    {
        $initialPath = "Data/genres.json";
        if (file_exists($initialPath)) {
            $jsonFilePath = $initialPath;
        } else {
            $jsonFilePath = "../" . $initialPath;
        }
        return $jsonFilePath;
    }
    // ****** (end) JSON Generos ****** //


    // ****** JSON Duracion ****** //
    public function GetJsonDuration($id)
    {
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.themoviedb.org/3/movie/" . $id . "?language=es-LA&api_key=81a2460dbefd7e043882b50c2b6138ce",  // PAGINA 1,2,3,4,5...ETC
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_POSTFIELDS => "{}",
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } else { }

        $arrayToDecode = json_decode($response, true);
        $film = new Film();
        foreach ($arrayToDecode["runtime"] as $valuesArray) {
            $film->setDuration($valuesArray);
        }
        return $film;
    }
}
