<?php

namespace DAO;

//use Models\CreditAccount as CreditAccount;
use Models\CreditCardPayment as CreditCardPayment;
use DAO\connection as Connection;

/**
 * 
 */

class CreditCardPaymentDAOPDO
{
    private $connection;
    private $tableName = 'pagotc';

    # Agrega un PAGO a la base de datos
    public function Add(CreditCardPayment $payment)
    {
        try {
            $query =  "INSERT INTO " . $this->tableName . "( idCuentaCredito , cod_aut, fecha, total) VALUES  (:idCuentaCredito, :cod_aut, :fecha, :total);";

            $parameters["idCuentaCredito"] = $payment->getIdCreditAccount();
            $parameters["cod_aut"] = $payment->getAuthCode();
            $parameters["fecha"] = $payment->getDate();
            $parameters["total"] = $payment->getTotal();


            $this->connection =  Connection::GetInstance();

            $this->connection->ExecuteNonQuery($query, $parameters);
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }

    public function GetLastInsertId()
    {
        try {
            $lastID = null;

            $query = "SELECT * FROM " . $this->tableName . " ORDER BY idPagoTC DESC LIMIT 0, 1";

            $this->connection =  Connection::GetInstance();
            $resultSet = $this->connection->Execute($query);

            foreach ($resultSet as $row) {
                $lastID = $row["idPagoTC"];
            }

            return $lastID;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }
}
