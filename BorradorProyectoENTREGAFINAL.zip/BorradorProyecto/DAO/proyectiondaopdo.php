<?php

namespace DAO;

use Models\Proyection as Proyection;
use Models\Cinema as Cinema;
use Models\Film as Film;
use Models\Sala as Sala;
use Models\Purchase as Purchase;
use Models\Ticket as Ticket;
use Models\UserProfile as UserProfile;

use DAO\connection as Connection;

/* 
     Clase Funcion/Proyecccion DAO PDO   
*/

class ProyectionDAOPDO
{
  private $connection;
  public $tableName = "proyeccion";
  private $pdo = null;

  # Agrega una proyeccion a la base de datos
  public function Add(Proyection $proyection)
  {
    try {
      $query =  "INSERT INTO " . $this->tableName . "( idPelicula, idSala, dia, hora) VALUES ( :idPelicula, :idSala, :dia, :hora );";

      $parameters["idPelicula"] = $proyection->getFilm();
      $parameters["idSala"] = $proyection->getSala();
      $parameters["dia"] = $proyection->getDay();
      $parameters["hora"] = $proyection->getTime()->format('H:i:s');


      $this->connection =  Connection::GetInstance();

      $this->connection->ExecuteNonQuery($query, $parameters);
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  # Devuelve TODAS las proyecciones 
  public function GetAll()
  {
    try {
      $proyectionList = array();


      $query = "SELECT * , sala.numeroSala, cine.nombre, sala.idSala 
                        FROM proyeccion 
                        INNER JOIN sala ON sala.idSala = proyeccion.idSala
                        INNER JOIN cine ON cine.idCine = sala.idCine 
                        INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula

                        WHERE proyeccion.dia> DATE(now()) 
                        OR   (proyeccion.dia= DATE(now()) and proyeccion.hora> TIME(now()))";

      $this->connection = Connection::GetInstance();

      $resultSet = $this->connection->Execute($query);

      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        $proyection->setIdProyection($row["idProyeccion"]);

        $sala = new Sala();
        $sala->setIdSala($row["idSala"]);
        $sala->setName($row["numeroSala"]);
        /*$sala->setCapacity();
                  $sala->setIdCine();
                  $sala->setPrice();*/

        $cinema = new Cinema();
        $cinema->setIdCinema($row["idCine"]);
        $cinema->setName($row["nombre"]);


        $sala->setIdCine($cinema);

        $proyection->setSala($sala);

        $film = new Film();
        $film->setIdFilm($row["idPelicula"]);
        $film->setTitle($row["titulo"]);
        $film->setDescription($row["descripcion"]);
        if ($row["duracion"] == null) {
          $film->setDuration(130);
        } else {
          $film->setDuration($row["duracion"]);
        }

        $film->setLanguage($row["lenguaje"]);
        $film->setUrlImage($row["imagen"]);

        $proyection->setFilm($film);
        $proyection->setTime($row["hora"]);
        $proyection->setDay($row["dia"]);



        array_push($proyectionList, $proyection);
      }

      return $proyectionList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  # Devuelve todas las proyecciones agrupadas por nombre y titulo
  # PARA LA CARTELERA
  public function GetAllForCartelera()
  {
    try {
      $proyectionList = array();

      $query = "SELECT cine.nombre, sala.numeroSala , pelicula.titulo, pelicula.idPelicula, pelicula.imagen
                      FROM proyeccion
                      INNER JOIN sala ON sala.idSala = proyeccion.idSala 
                      INNER JOIN cine ON cine.idCine = sala.idCine 
                      INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula

                      WHERE proyeccion.dia> DATE(now()) 
                      
                      OR   (proyeccion.dia= DATE(now()) and proyeccion.hora> TIME(now()))

                      GROUP BY pelicula.titulo";

      $this->connection = Connection::GetInstance();

      $resultSet = $this->connection->Execute($query);

      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        //$proyection->setIdProyection($row["idProyeccion"]);

        $sala = new Sala();
        //$sala->setIdSala($row["idSala"]);
        //$sala->setName($row["numeroSala"]);

        //$cinema = new Cinema();
        //$cinema->setIdCinema($row["idCine"]);
        //$cinema->setName($row["nombre"]);

        //$sala->setIdCine($cinema);
        //$cinema->setSala($sala);

        //$proyection->setSala($sala);

        $film = new Film();
        $film->setIdFilm($row["idPelicula"]);
        $film->setTitle($row["titulo"]);
        //$film->setDescription($row["descripcion"]);
        //$film->setDuration($row["duracion"]);
        //$film->setLanguage($row["lenguaje"]);
        $film->setUrlImage($row["imagen"]);

        $proyection->setFilm($film);
        //$proyection->setTime($row["hora"]);
        //$proyection->setDay($row["dia"]);                               

        array_push($proyectionList, $proyection);
      }

      return $proyectionList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  # Devuelve las proyecciones por DIA
  public function GetProyectionByDate($date)
  {
    try {
      $proyectionList = array();
      $query = "SELECT proyeccion.idSala,
                               proyeccion.idPelicula ,
                               proyeccion.idProyeccion AS proyidProyeccion, 
                               pelicula.titulo AS peliTitulo,
                               pelicula.duracion,
                               cine.idCine,
                               cine.nombre AS cineNombre,
                               sala.numeroSala,
                               proyeccion.dia AS proyDia,
                               proyeccion.hora AS proyHora 
                        FROM  proyeccion 
                        INNER JOIN sala ON sala.idSala = proyeccion.idSala
                        INNER JOIN cine ON cine.idCine = sala.idCine 
                        INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                        INNER JOIN pelXgen ON pelXgen.idPelicula = pelicula.idPelicula 
                        INNER JOIN genero ON genero.idGenero = pelXgen.idGenero
                        WHERE  proyeccion.dia = :date
                        GROUP BY proyidProyeccion
                        ORDER BY proyDia ASC";

      $parameters["date"] = $date;

      $this->connection = Connection::GetInstance();

      $resultSet = $this->connection->Execute($query, $parameters);


      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        $proyection->setIdProyection($row["proyidProyeccion"]);
        $proyection->setDay($row["proyDia"]);
        $proyection->setTime($row["proyHora"]);

        $sala = new Sala();
        $sala->setIdSala($row["idSala"]);
        $sala->setName($row["numeroSala"]);

        $cinema = new Cinema();
        $cinema->setIdCinema($row["idCine"]);
        $cinema->setName($row["cineNombre"]);
        $sala->setIdCine($cinema);

        $proyection->setSala($sala);

        $film = new Film();
        $film->setIdFilm($row["idPelicula"]);
        $film->setTitle($row["peliTitulo"]);
        //$film->setDescription($row["descripcion"]);
        if ($row["duracion"] == null) {
          $film->setDuration(130);
        } else {
          $film->setDuration($row["duracion"]);
        }
        //$film->setLanguage($row["lenguaje"]);
        //$film->setUrlImage($row["imagen"]);

        $proyection->setFilm($film);

        array_push($proyectionList, $proyection);
      }

      return $proyectionList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  # Devuelve las proyecciones por GENERO
  public function GetProyectionByGenre($genreID)
  {
    try {
      $proyectionList = null;

      $query = "SELECT proyeccion.idSala,
                               proyeccion.idPelicula ,
                               proyeccion.idProyeccion AS proyidProyeccion, 
                               pelicula.titulo AS peliTitulo,
                               cine.idCine,
                               cine.nombre AS cineNombre,
                               sala.numeroSala,
                               proyeccion.dia AS proyDia,
                               proyeccion.hora AS proyHora 
                        FROM  proyeccion
                        INNER JOIN sala ON sala.idSala = proyeccion.idSala, 
                        INNER JOIN cine ON cine.idCine = sala.idCine 
                        INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                        INNER JOIN pelXgen ON pelXgen.idPelicula = pelicula.idPelicula 
                        INNER JOIN genero ON genero.idGenero = pelXgen.idGenero
                        WHERE genero.idGenero = :genre";

      $parameters["genre"] = $genreID;

      $this->connection = Connection::GetInstance();
      $resultSet = $this->connection->Execute($query, $parameters);

      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        $proyection->setIdProyection($row["proyidProyeccion"]);
        $proyection->setDay($row["proyDia"]);
        $proyection->setTime($row["proyHora"]);

        $sala = new Sala();
        $sala->setIdSala($row["idSala"]);
        $sala->setName($row["numeroSala"]);

        $cinema = new Cinema();
        $cinema->setIdCinema($row["idCine"]);
        $cinema->setName($row["cineNombre"]);

        $sala->setIdCine($cinema);

        $proyection->setSala($sala);

        $film = new Film();
        $film->setIdFilm($row["idPelicula"]);
        $film->setTitle($row["peliTitulo"]);

        $proyection->setFilm($film);

        array_push($proyectionList, $proyection);
      }

      return $proyectionList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  # Busca  las proyecciones por GENERO Y DIA (ambos)
  public function GetProyectionByGenreAndDate($genre, $day)
  {
    try {
      $proyectionList = array();

      $query = "SELECT proyeccion.idSala,
                               proyeccion.idPelicula ,
                               proyeccion.idProyeccion AS proyidProyeccion, 
                               pelicula.titulo AS peliTitulo,
                               pelicula.duracion,
                               sala.idCine,
                               cine.idCine,
                               cine.nombre AS cineNombre,
                               proyeccion.dia AS proyDia,
                               proyeccion.hora AS proyHora,
                               sala.numeroSala 
                        FROM  proyeccion
                        INNER JOIN sala ON sala.idSala = proyeccion.idSala 
                        INNER JOIN cine ON cine.idCine = sala.idCine 
                        INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                        INNER JOIN pelXgen ON pelXgen.idPelicula = pelicula.idPelicula 
                        INNER JOIN genero ON genero.idGenero = pelXgen.idGenero
                        WHERE genero.idGenero = :genre AND proyeccion.dia = :day
                        GROUP BY proyidProyeccion";

      $parameters["genre"] = $genre;
      $parameters["day"] = $day;

      $this->connection = Connection::GetInstance();

      $resultSet = $this->connection->Execute($query, $parameters);


      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        $proyection->setIdProyection($row["proyidProyeccion"]);
        $proyection->setDay($row["proyDia"]);
        $proyection->setTime($row["proyHora"]);

        $sala = new Sala();
        $sala->setIdSala($row["idSala"]);
        $sala->setName($row["numeroSala"]);

        $cinema = new Cinema();
        $cinema->setIdCinema($row["idCine"]);
        $cinema->setName($row["cineNombre"]);

        $sala->setIdCine($cinema);

        $proyection->setSala($sala);

        $film = new Film();
        $film->setIdFilm($row["idPelicula"]);
        $film->setTitle($row["peliTitulo"]);
        //$film->setDescription($row["descripcion"]);
        $film->setDuration($row["duracion"]);
        //$film->setLanguage($row["lenguaje"]);
        //$film->setUrlImage($row["imagen"]);

        $proyection->setFilm($film);

        array_push($proyectionList, $proyection);
      }

      return $proyectionList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  # Devuelve las proyecciones por CINE
  public function GetProyectionByCinema($cinemaID)
  {
    try {
      $proyectionList = null;

      $query = "SELECT * FROM " . $this->tableName . " WHERE idCinema = :cinemaID";

      $parameters["cinemaID"] = $cinemaID;

      $this->connection = Connection::GetInstance();
      $resultSet = $this->connection->Execute($query, $parameters);

      foreach ($resultSet as $row) {
        $proyection = new Proyection();

        $proyection->setIdProyection($row["idProyection"]);
        $proyection->setIdCinema($row["IdSala"]);
        $proyection->setIdFilm($row["IdFilm"]);
        $proyection->setHour($row["hour"]);
        $proyection->setDate($row["day"]);

        array_push($proyectionList, $proyection);
      }

      return $proyectionList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  # Devuelve la proyeccion por TITULO y DIA
  public function GetProyectionByTitleDay($idTitle, $day)
  { //$time
    try {
      $proyectionList = array();

      $query = "SELECT idProyeccion, proyeccion.dia, proyeccion.hora, sala.idSala, pelicula.idPelicula, sala.numeroSala
                          FROM " . $this->tableName . " 
                          INNER JOIN sala ON sala.idSala = proyeccion.idSala
                          INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula 
                          WHERE pelicula.idPelicula = :idTitle AND proyeccion.dia = :day";
      $parameters["idTitle"] = $idTitle;
      $parameters["day"] = $day;


      $this->connection = Connection::GetInstance();
      $resultSet = $this->connection->Execute($query, $parameters);

      foreach ($resultSet as $row) {
        $proyection = new Proyection();

        $proyection->setIdProyection($row["idProyeccion"]);
        //$proyection->setSala($row["idSala"]);
        $proyection->setFilm($row["idPelicula"]);
        $proyection->setTime($row["hora"]);
        $proyection->setDay($row["dia"]);

        $sala = new Sala();
        $sala->setIdSala($row["idSala"]);
        $sala->setName($row["numeroSala"]);

        $proyection->setSala($sala);

        array_push($proyectionList, $proyection);
      }

      return $proyection;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  public function GetProyectionByID($idProyection)
  {
    try {
      $proyection = null;
      $query = "SELECT proyeccion.idSala,
                               proyeccion.idPelicula ,
                               proyeccion.idProyeccion AS proyidProyeccion, 
                               pelicula.titulo AS peliTitulo,
                               cine.nombre AS cineNombre,
                               sala.idCine,
                               sala.numeroSala AS salaNombre,
                               sala.capacidad AS salaCapcidad,
                               sala.valorEntrada AS valorTicket,
                               proyeccion.dia AS proyDia,
                               proyeccion.hora AS proyHora 
                        FROM  proyeccion
                        INNER JOIN sala ON sala.Idsala = proyeccion.idSala  
                        INNER JOIN cine ON cine.idCine = sala.idCine 
                        INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                        INNER JOIN pelXgen ON pelXgen.idPelicula = pelicula.idPelicula 
                        INNER JOIN genero ON genero.idGenero = pelXgen.idGenero
                        WHERE  proyeccion.idProyeccion = :idProyection";

      $parameters["idProyection"] = $idProyection;

      $this->connection = Connection::GetInstance();

      $resultSet = $this->connection->Execute($query, $parameters);


      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        $proyection->setIdProyection($row["proyidProyeccion"]);
        $proyection->setDay($row["proyDia"]);
        $proyection->setTime($row["proyHora"]);

        $sala = new Sala();
        $sala->setIdSala($row["idSala"]);
        $sala->setName($row["salaNombre"]);
        $sala->setCapacity($row["salaCapcidad"]);
        $sala->setPrice($row["valorTicket"]);

        $cinema = new Cinema();
        $cinema->setIdCinema($row["idCine"]);
        $cinema->setName($row["cineNombre"]);
        $cinema->setTicketPrice($row["valorTicket"]);

        $sala->setIdCine($cinema);
        $proyection->setSala($sala);

        $film = new Film();
        $film->setIdFilm($row["idPelicula"]);
        $film->setTitle($row["peliTitulo"]);
        //$film->setDescription($row["descripcion"]);
        //$film->setDuration($row["duracion"]);
        //$film->setLanguage($row["lenguaje"]);
        //$film->setUrlImage($row["imagen"]);

        $proyection->setFilm($film);

        //array_push($proyectionList, $proyection);
      }

      return $proyection;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  # Devuelve proyeccion por ID de pelicula
  public function GetProyectionByIDFilm($idFilm, $day, $hour)
  {
    try {
      $proyectionList = array();
      $query = "SELECT proyeccion.idSala,
                               proyeccion.idPelicula ,
                               proyeccion.idProyeccion AS proyidProyeccion, 
                               sala.idCine,
                               sala.numeroSala,
                               sala.capacidad,
                               cine.nombre AS cineNombre,
                               proyeccion.dia AS proyDia,
                               proyeccion.hora AS proyHora, 
                               pelicula.titulo AS peliTitulo,
                               genero.descripcion
                        FROM  proyeccion
                        INNER JOIN sala ON sala.IdSala = proyeccion.idSala 
                        INNER JOIN cine ON cine.idCine = sala.idCine 
                        INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                        INNER JOIN pelXgen ON pelXgen.idPelicula = pelicula.idPelicula 
                        INNER JOIN genero ON genero.idGenero = pelXgen.idGenero
                        WHERE  proyeccion.idPelicula = :idFilm 

                        AND proyeccion.dia> DATE(now()) 
                      
                        OR (proyeccion.dia= DATE(now()) and proyeccion.hora> TIME(now()))

                        GROUP BY proyDia, proyHora";

      $parameters["idFilm"] = $idFilm;
      //$parameters["hour"] = $hour;
      //$parameters["day"] = $day;

      $this->connection = Connection::GetInstance();

      $resultSet = $this->connection->Execute($query, $parameters);


      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        $proyection->setIdProyection($row["proyidProyeccion"]);
        $proyection->setDay($row["proyDia"]);
        $proyection->setTime($row["proyHora"]);

        $sala = new Sala();
        $sala->setIdSala($row["idSala"]);
        $sala->setName($row["numeroSala"]);
        $sala->setCapacity($row["capacidad"]);
        //$sala->setPrice();

        $cinema = new Cinema();
        $cinema->setIdCinema($row["idCine"]);
        $cinema->setName($row["cineNombre"]);

        $sala->setIdCine($cinema);
        $proyection->setSala($sala);

        $film = new Film();
        $film->setIdFilm($row["idPelicula"]);
        $film->setTitle($row["peliTitulo"]);
        //$film->setDescription($row["descripcion"]);
        //$film->setDuration($row["duracion"]);
        //$film->setLanguage($row["lenguaje"]);
        //$film->setUrlImage($row["imagen"]);

        $proyection->setFilm($film);

        array_push($proyectionList, $proyection);
      }

      return $proyectionList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  # Devuelve las proyecciones en un dia y sala determinado 
  public function GetProyectionsBySalaDay($sala, $day)
  {
    try {
      $proyectionList = array();

      $query = "SELECT proyeccion.idProyeccion, proyeccion.idPelicula, proyeccion.idSala, proyeccion.dia, proyeccion.hora,  
                      sala.numeroSala, pelicula.duracion, pelicula.titulo
                      FROM proyeccion 
                      INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                      INNER JOIN sala ON sala.idSala = proyeccion.idSala 
                      INNER JOIN cine ON cine.idCine = sala.idCine
                      WHERE proyeccion.idSala = :sala AND proyeccion.dia = :day";

      $parameters["sala"] = $sala;
      $parameters["day"] = $day;

      $this->connection = Connection::GetInstance();
      $resultSet = $this->connection->Execute($query, $parameters);

      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        $proyection->setIdProyection($row["idProyeccion"]);

        $sala = new Sala();
        $sala->setIdSala($row["idSala"]);
        $sala->setName($row["numeroSala"]);

        $film = new Film();
        $film->setIdFilm($row["idPelicula"]);
        $film->setTitle($row["titulo"]);
        if ($row["duracion"] == null) {
          $durationDefault = 132;
          $film->setDuration($durationDefault);
        } else {
          $film->setDuration($row["duracion"]);
        }

        $proyection->setFilm($film);
        $proyection->setSala($sala);
        $proyection->setDay($row["dia"]);
        $proyection->setTime($row["hora"]);

        array_push($proyectionList, $proyection);
      }
      return $proyectionList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  # Historial de compras de proyecciones para el usuario.
  public function GetHistorial($idUser, $filter)
  {
    try {
      $ticketList = array();
      /*$query = "SELECT compra.fecha, cine.nombre, pelicula.titulo, proyeccion.dia, proyeccion.hora, entrada.nroEntrada, entrada.qrCode, entrada.idEntrada
              FROM proyeccion
              INNER JOIN entrada ON entrada.idProyeccion = proyeccion.idProyeccion
              INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
              INNER JOIN sala ON sala.idSala = proyeccion.idSala
              INNER JOIN cine ON CINE.idCine = sala.idCine
              INNER JOIN compra ON compra.idCompra = entrada.idCompra
              INNER JOIN usuario ON usuario.idUsuario = compra.idUsuario

              WHERE usuario.idUsuario = :idUser
              GROUP BY compra.idCompra
              ORDER BY ".$filter." ASC ";*/

      $query = "SELECT compra.idCompra, compra.idUsuario, cantEntradas, fecha, total, entrada.qrCode, 
                        entrada.idEntrada, entrada.nroEntrada, compra.fecha AS compraFecha, cine.nombre, proyeccion.dia, 
                        proyeccion.hora, pelicula.titulo, compra.total   
                        FROM compra 
                        INNER JOIN usuario ON usuario.idUsuario = compra.idUsuario
                        INNER JOIN entrada ON entrada.idCompra = compra.idCompra
                        INNER JOIN proyeccion ON proyeccion.idProyeccion = entrada.idProyeccion 
                        INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula
                        INNER JOIN sala ON sala.idSala = proyeccion.idSala 
                        INNER JOIN cine ON cine.idCine = sala.idCine

                        WHERE compra.idUsuario = :idUser
                        GROUP BY compra.idCompra";

      $parameters["idUser"] = $idUser;

      $this->connection = Connection::GetInstance();
      $resultSet = $this->connection->Execute($query, $parameters);

      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        $compra = new Purchase();
        $cinema = new Cinema();
        $film = new Film();
        $sala = new Sala();

        $compra->setIdPurchase($row["idCompra"]);
        $compra->setDate($row["fecha"]);
        $compra->setTotal($row["total"]);

        $cinema->setName($row["nombre"]);
        $sala->setIdCine($cinema);

        $film->setTitle($row["titulo"]);

        $proyection->setDay($row["dia"]);
        $proyection->setTime($row["hora"]);

        $proyection->setSala($sala);
        $proyection->setFilm($film);


        $ticket = new Ticket();
        $ticket->setTicketID($row["idEntrada"]);
        $ticket->setTicketNumber($row["nroEntrada"]);
        $ticket->setQrCode($row["qrCode"]);
        $ticket->setProyection($proyection);
        $ticket->setPurchase($compra);




        array_push($ticketList, $ticket);
      }

      return $ticketList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  # Trame las proyeccion con Cine, sala, y peliculas para las consultas
  public function GetProyectionsForFilm()
  {
    try {
      $proyectionList = array();

      $query = "SELECT cine.nombre, sala.idSala, cine.idCine, sala.numeroSala , pelicula.titulo, pelicula.idPelicula, pelicula.imagen
                      FROM proyeccion
                      INNER JOIN sala ON sala.idSala = proyeccion.idSala 
                      INNER JOIN cine ON cine.idCine = sala.idCine 
                      INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula

                      WHERE proyeccion.dia> DATE(now()) 
                      
                      OR   (proyeccion.dia= DATE(now()) and proyeccion.hora> TIME(now()))

                      GROUP BY pelicula.titulo";

      $this->connection = Connection::GetInstance();

      $resultSet = $this->connection->Execute($query);

      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        //$proyection->setIdProyection($row["idProyeccion"]);

        $sala = new Sala();
        $sala->setIdSala($row["idSala"]);
        $sala->setName($row["numeroSala"]);

        $cinema = new Cinema();
        $cinema->setIdCinema($row["idCine"]);
        $cinema->setName($row["nombre"]);

        $sala->setIdCine($cinema);

        $proyection->setSala($sala);

        $film = new Film();
        $film->setIdFilm($row["idPelicula"]);
        $film->setTitle($row["titulo"]);
        //$film->setDescription($row["descripcion"]);
        //$film->setDuration($row["duracion"]);
        //$film->setLanguage($row["lenguaje"]);
        $film->setUrlImage($row["imagen"]);

        $proyection->setFilm($film);
        //$proyection->setTime($row["hora"]);
        //$proyection->setDay($row["dia"]);                               

        array_push($proyectionList, $proyection);
      }

      return $proyectionList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  public function GetProyectionsForCinema()
  {
    try {
      $proyectionList = array();

      $query = "SELECT cine.nombre, sala.idSala, cine.idCine, sala.numeroSala , pelicula.titulo, pelicula.idPelicula, pelicula.imagen
                      FROM proyeccion
                      INNER JOIN sala ON sala.idSala = proyeccion.idSala 
                      INNER JOIN cine ON cine.idCine = sala.idCine 
                      INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula

                      WHERE proyeccion.dia> DATE(now()) 
                      
                      OR   (proyeccion.dia= DATE(now()) and proyeccion.hora> TIME(now()))

                      GROUP BY cine.idCine";

      $this->connection = Connection::GetInstance();

      $resultSet = $this->connection->Execute($query);

      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        //$proyection->setIdProyection($row["idProyeccion"]);

        $sala = new Sala();
        $sala->setIdSala($row["idSala"]);
        $sala->setName($row["numeroSala"]);

        $cinema = new Cinema();
        $cinema->setIdCinema($row["idCine"]);
        $cinema->setName($row["nombre"]);

        $sala->setIdCine($cinema);

        $proyection->setSala($sala);

        $film = new Film();
        $film->setIdFilm($row["idPelicula"]);
        $film->setTitle($row["titulo"]);
        //$film->setDescription($row["descripcion"]);
        //$film->setDuration($row["duracion"]);
        //$film->setLanguage($row["lenguaje"]);
        $film->setUrlImage($row["imagen"]);

        $proyection->setFilm($film);
        //$proyection->setTime($row["hora"]);
        //$proyection->setDay($row["dia"]);                               

        array_push($proyectionList, $proyection);
      }

      return $proyectionList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  public function GetProyectionsForRemanent()
  {
    try {
      $proyectionList = array();


      $query = "SELECT * , sala.numeroSala, cine.nombre, sala.idSala 
                        FROM proyeccion 
                        INNER JOIN sala ON sala.idSala = proyeccion.idSala
                        INNER JOIN cine ON cine.idCine = sala.idCine 
                        INNER JOIN pelicula ON pelicula.idPelicula = proyeccion.idPelicula";

      $this->connection = Connection::GetInstance();

      $resultSet = $this->connection->Execute($query);


      foreach ($resultSet as $row) {
        $proyection = new Proyection();
        $proyection->setIdProyection($row["idProyeccion"]);

        $sala = new Sala();
        $sala->setIdSala($row["idSala"]);
        $sala->setName($row["numeroSala"]);
        /*$sala->setCapacity();
                  $sala->setIdCine();
                  $sala->setPrice();*/

        $cinema = new Cinema();
        $cinema->setIdCinema($row["idCine"]);
        $cinema->setName($row["nombre"]);


        $sala->setIdCine($cinema);

        $proyection->setSala($sala);

        $film = new Film();
        $film->setIdFilm($row["idPelicula"]);
        $film->setTitle($row["titulo"]);
        $film->setDescription($row["descripcion"]);
        if ($row["duracion"] == null) {
          $film->setDuration(130);
        } else {
          $film->setDuration($row["duracion"]);
        }

        $film->setLanguage($row["lenguaje"]);
        $film->setUrlImage($row["imagen"]);

        $proyection->setFilm($film);
        $proyection->setTime($row["hora"]);
        $proyection->setDay($row["dia"]);



        array_push($proyectionList, $proyection);
      }
      return $proyectionList;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  public function GetRemanentByProyection($idProyeccion, $idSala)
  {
    try {
      $remanente = null;
      $query = "SELECT ifnull(sum(total1.t1 -total2.t2), 0) as 'REMANENTE ENTRADAS'
                        FROM
                        (select sala.capacidad as t1
                        from
                        sala
                        inner join cine on cine.idCine=sala.idCine
                        where sala.idSala = :idSala) as total1,

                        (SELECT count(*) as t2
                        FROM
                        compra
                        inner join entrada on entrada.idCompra = compra.idCompra
                        inner join proyeccion on proyeccion.idProyeccion = entrada.idProyeccion
                        inner join pelicula on proyeccion.idPelicula = pelicula.idPelicula
                        inner join sala on sala.idSala=proyeccion.idSala
                        inner join cine on cine.idCine=sala.idCine
                        where proyeccion.idProyeccion= :idProyeccion) as total2;";

      $parameters["idSala"] = $idSala;
      $parameters["idProyeccion"] = $idProyeccion;

      $this->connection = Connection::GetInstance();

      $resultSet = $this->connection->Execute($query, $parameters);
      foreach ($resultSet as $row) {
        $remanente = $row["REMANENTE ENTRADAS"];
      }
      return $remanente;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }

  public function GetVendidasPorProyeccion($idProyeccion)
  {
    try {
      $vendidas = null;
      $query = "SELECT count(*) as CantVendidas
                        FROM
                        compra
                        inner join entrada on entrada.idCompra = compra.idCompra
                        inner join proyeccion on proyeccion.idProyeccion = entrada.idProyeccion
                        inner join pelicula on proyeccion.idPelicula = pelicula.idPelicula
                        inner join sala on sala.idSala=proyeccion.idSala
                        inner join cine on cine.idCine=sala.idCine
                        where proyeccion.idProyeccion= :idProyeccion;";


      $parameters["idProyeccion"] = $idProyeccion;

      $this->connection = Connection::GetInstance();

      $resultSet = $this->connection->Execute($query, $parameters);
      foreach ($resultSet as $row) {
        $vendidas = $row["CantVendidas"];
      }
      return $vendidas;
    } catch (PDOException $e) {
      throw $e;
    } catch (Exception $ex) {
      throw $ex;
    }
  }
}
