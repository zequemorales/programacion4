<?php

namespace DAO;

use DAO\ICinemaDAO as ICinemaDAO;
use Models\Cinema as Cinema;
use Models\Sala as Sala;
use DAO\connection as Connection;


/* 
     Clase Sala DAO PDO   
*/

class SalaDAOPDO
{
    private $connection;
    private $tableName2 = "sala";
    private $pdo = null;

    # Inserta las salas de un cine
    public function Add(Sala $sala)
    {
        try {
            $query = "INSERT INTO " . $this->tableName2 . " (numeroSala, idCine, capacidad, valorEntrada) values (:numeroSala, :idCine, :capacidad, :valorEntrada);";

            $parameters["numeroSala"] = $sala->getName();
            $parameters["idCine"] = $sala->getIdCine();
            $parameters["capacidad"] = $sala->getCapacity();
            $parameters["valorEntrada"] = $sala->getPrice();

            $this->connection =  Connection::GetInstance();
            $this->connection->ExecuteNonQuery($query, $parameters);
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }


    # Trae salas por idCine 
    public function GetSalasByIdCinema($idCinema)
    {
        try {
            $salas = array();

            $query = "SELECT * FROM sala WHERE idCine = :idCinema";

            $parameters["idCinema"] = $idCinema;

            $this->connection = Connection::GetInstance();
            $resultSet = $this->connection->Execute($query, $parameters);

            foreach ($resultSet as $row) {
                $sala = new Sala();
                $sala->setIdSala($row["idSala"]);
                $sala->setIdCine($row["idCine"]);
                $sala->setName($row["numeroSala"]);
                $sala->setCapacity($row["capacidad"]);
                $sala->setPrice($row["valorEntrada"]);

                array_push($salas, $sala);
            }
            return $salas;
        } catch (PDOException $e) {
            throw $e;
        } catch (Exception $ex) {
            throw $ex;
        }
    }
}
