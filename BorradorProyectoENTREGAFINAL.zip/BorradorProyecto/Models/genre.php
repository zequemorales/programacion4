<?php

namespace models;

/**
 *  Clase genero
 */
class Genre
{
	private $idGenre;
	private $description;


	public function getIdGenre()
	{
		return $this->idGenre;
	}

	public function setIdGenre($idGenre)
	{
		$this->idGenre = $idGenre;
	}

	public function getDescription()
	{
		return $this->description;
	}

	public function setDescription($description)
	{
		$this->description = $description;
	}
}
