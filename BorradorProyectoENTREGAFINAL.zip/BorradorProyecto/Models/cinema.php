<?php

namespace models;

/**
 *  Clase Cine
 */
class Cinema
{
	private $idCinema;
	private $name;
	private $capacity;
	private $ticketPrice;
	private $address;
	private $isActive;   // 1 = true , 0 = false;	
	//private $sala;

	public function __construct()
	{
		$this->isActive = 1;
		$this->sala = array();
	}

	public function getIdCinema()
	{
		return $this->idCinema;
	}

	public function setIdCinema($idCinema)
	{
		$this->idCinema = $idCinema;
	}

	public function getName()
	{
		return $this->name;
	}

	public function setName($name)
	{
		$this->name = $name;
	}

	public function getCapacity()
	{
		return $this->capacity;
	}

	public function setCapacity($capacity)
	{
		$this->capacity = $capacity;
	}

	public function getTicketPrice()
	{
		return $this->ticketPrice;
	}

	public function setTicketPrice($ticketPrice)
	{
		$this->ticketPrice = $ticketPrice;
	}

	public function getAddress()
	{
		return $this->address;
	}

	public function setAddress($address)
	{
		$this->address = $address;
	}

	public function setIsActive($isActive)
	{
		$this->isActive = $isActive;
	}

	public function getIsActive()
	{
		return $this->isActive;
	}

	/*public function setSala($sala){
			array_push($this->sala, $sala);
		}
		
		public function getSala(){
			return $this->sala;
		}*/
}
