<?php

namespace models;

/**
 *  Clase Pago Tarjeta de credito
 */
class CreditCardPayment
{
	private $date;
	private $idCreditAccount;
	private $authCode;
	private $total;

	public function getDate()
	{
		return $this->date;
	}

	public function setDate($date)
	{
		$this->date = $date;
	}

	public function getIdCreditAccount()
	{
		return $this->idCreditAccount;
	}

	public function setIdCreditAccount($idCreditAccount)
	{
		$this->idCreditAccount = $idCreditAccount;
	}

	public function getAuthCode()
	{
		return $this->authCode;
	}

	public function setAuthCode($authCode)
	{
		$this->authCode = $authCode;
	}

	public function getTotal()
	{
		return $this->total;
	}

	public function setTotal($total)
	{
		$this->total = $total;
	}

	public function VerifyCreditCard($creditCardNumber)
	{
		global $type;

		$cardtype = array(
			"visa"       => "/^4[0-9]{12}(?:[0-9]{3})?$/",
			"mastercard" => "/^5[1-5][0-9]{14}$/",
			"amex"       => "/^3[47][0-9]{13}$/",
			"discover"   => "/^6(?:011|5[0-9]{2})[0-9]{12}$/",
		);

		if (preg_match($cardtype['visa'], $creditCardNumber)) {
			$type = "visa";
			return 'visa';
		} else if (preg_match($cardtype['mastercard'], $creditCardNumber)) {
			$type = "mastercard";
			return 'mastercard';
		} else if (preg_match($cardtype['amex'], $creditCardNumber)) {
			$type = "amex";
			return 'amex';
		} else if (preg_match($cardtype['discover'], $creditCardNumber)) {
			$type = "discover";
			return 'discover';
		} else {
			return null;
		}
	}
}
