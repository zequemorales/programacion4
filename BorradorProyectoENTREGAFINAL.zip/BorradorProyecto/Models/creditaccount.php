<?php

namespace models;

/**
 *  Clase Cuenta Credito
 */
class CreditAccount
{
	private $idCreditAccount;
	private $enterprise;

	public function getIdCreditAccount()
	{
		return $this->idCreditAccount;
	}

	public function setIdCreditAccount($idCreditAccount)
	{
		$this->idCreditAccount = $idCreditAccount;
	}

	public function getEnterprise()
	{
		return $this->enterprise;
	}

	public function setEnterprise($enterprise)
	{
		$this->enterprise = $enterprise;
	}
}
