<?php

namespace Models;

/**
 *  Clase Sala
 */
class Sala
{
	private $idSala;
	private $name;
	private $capacity;
	private $idCine;
	private $price;

	public function getIdSala()
	{
		return $this->idSala;
	}

	public function setIdSala($idSala)
	{
		$this->idSala = $idSala;
	}
	public function getName()
	{
		return $this->name;
	}

	public function setName($name)
	{
		$this->name = $name;
	}

	public function getCapacity()
	{
		return $this->capacity;
	}

	public function setCapacity($capacity)
	{
		$this->capacity = $capacity;
	}

	public function getPrice()
	{
		return $this->price;
	}

	public function setPrice($price)
	{
		$this->price = $price;
	}

	public function setIdCine($idCine)
	{
		$this->idCine = $idCine;
	}
	public function getIdCine()
	{
		return $this->idCine;
	}
}
