<?php

namespace Models;

/**
 *  Clase Compra
 */

class Purchase
{
	private $idPurchase;
	private $date;
	private $quantityTickets;
	private $total;
	private $discount;

	public function getIdPurchase()
	{
		return $this->idPurchase;
	}

	public function setIdPurchase($idPurchase)
	{
		$this->idPurchase = $idPurchase;
	}

	public function getDate()
	{
		return $this->date;
	}

	public function setDate($date)
	{
		$this->date = $date;
	}

	public function getQuantityTickets()
	{
		return $this->quantityTickets;
	}

	public function setQuantityTickets($quantityTickets)
	{
		$this->quantityTickets = $quantityTickets;
	}

	public function getTotal()
	{
		return $this->total;
	}

	public function setTotal($total)
	{
		$this->total = $total;
	}

	public function getDiscount()
	{
		/*$date = date("l");
			if (($date=="Tuesday" || $date == "Wednesday") && ($ >= 2) ) {
				$this->setDiscount(0.25);
			}*/
		return $this->discount;
	}

	public function setDiscount($discount)
	{
		$this->discount = $discount;
	}
	# El descuento se hace si la cantidad de tickets es mayor  o igual a 2.
	# Y si la proyeccion de la peli se hace el martes o miercoles. 0.25 de descuento
	public function verifyDiscount($date, $quantityTickets)
	{
		$dayName = date("l", strtotime($date));
		if (($dayName == "Tuesday" || $dayName == "Wednesday") && ($quantityTickets >= 2)) {
			$this->setDiscount(0.25);
		}
		return $this->discount;
	}
}
