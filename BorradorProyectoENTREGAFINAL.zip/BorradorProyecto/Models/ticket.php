<?php

namespace Models;

/**
 * Clase Entrada de cine
 */
class Ticket
{
	private $ticketID;
	private $qrCode;
	private $ticketNumber;
	private $proyection;
	private $purchase;

	public function getTicketID()
	{
		return $this->ticketID;
	}

	public function setTicketID($ticketID)
	{
		$this->ticketID = $ticketID;
	}

	public function getQrCode()
	{
		return $this->qrCode;
	}

	public function setQrCode($qrCode)
	{
		$this->qrCode = 'https://api.qrserver.com/v1/create-qr-code/?data=' . $qrCode . '&amp;size=100x100';
	}

	public function getTicketNumber()
	{
		return $this->ticketNumber;
	}

	public function setTicketNumber($ticketNumber)
	{
		$this->ticketNumber = $ticketNumber;
	}

	public function setProyection($proyection)
	{
		$this->proyection = $proyection;
	}

	public function getProyection()
	{
		return $this->proyection;
	}
	public function setPurchase($purchase)
	{
		$this->purchase = $purchase;
	}

	public function getPurchase()
	{
		return $this->purchase;
	}
}
