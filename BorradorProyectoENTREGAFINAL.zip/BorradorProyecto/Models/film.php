<?php

namespace models;

/**
 *  Clase pelicula
 */
class Film
{
	private $idFilm;
	private $title;
	private $genre;
	private $language;
	private $description;   			// API = Overview
	private $duration;
	private $urlImage;

	public function __construct()
	{
		$this->genre = array();
	}
	public function getIdFilm()
	{
		return $this->idFilm;
	}

	public function setIdFilm($idFilm)
	{
		$this->idFilm = $idFilm;
	}

	public function getTitle()
	{
		return $this->title;
	}

	public function setTitle($title)
	{
		$this->title = $title;
	}

	public function getGenre()
	{
		return $this->genre;
	}

	public function setGenre($genre)
	{
		array_push($this->genre, $genre);
	}

	public function getDescription()
	{
		return $this->description;
	}

	public function setDescription($description)
	{
		$this->description = $description;
	}

	public function getDuration()
	{
		return $this->duration;
	}

	public function setDuration($duration)
	{
		$this->duration = $duration;
	}

	public function getLanguage()
	{
		return $this->language;
	}

	public function setLanguage($language)
	{
		$this->language = $language;
	}

	public function setUrlImage($urlImage)
	{
		$this->urlImage = $urlImage;
	}
	//'https://image.tmdb.org/t/p/w370_and_h556_bestv2'
	public function getUrlImage()
	{
		return $this->urlImage;
	}
}
