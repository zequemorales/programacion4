<?php

namespace Models;

use Models\Cinema as Cinema;
use Models\Film as Film;

/**
 *  Claase Funcion o Poyección
 */
class Proyection
{
	private $idProyection;
	private $film;
	private $sala;
	private $day;
	private $time;
	private $isFree; // 1 = disponible       0 = ocupado

	function __construct()
	{

		$this->isFree = 1;
	}

	public function getIdProyection()
	{
		return $this->idProyection;
	}

	public function setIdProyection($idProyection)
	{
		$this->idProyection = $idProyection;
	}

	public function getSala()
	{
		return $this->sala;
	}

	public function setSala($sala)
	{
		$this->sala = $sala;
	}

	public function getFilm()
	{
		return $this->film;
	}

	public function setFilm($film)
	{
		$this->film = $film;
	}

	public function getDay()
	{
		return $this->day;
	}

	public function setDay($day)
	{
		$this->day = $day;
	}

	public function getTime()
	{
		return $this->time;
	}

	public function setTime($time)
	{
		$this->time = $time;
	}

	public function setIsFree($isFree)
	{
		$this->isFree = $isFree;
	}
	public function getIsFree()
	{
		return $this->isFree;
	}
}
