CREATE TABLE genero(
	idGenero INT NOT NULL,
	descripcion VARCHAR(20),    
	CONSTRAINT pk_idGenero PRIMARY KEY (idGenero),
    CONSTRAINT unq_genero_descripcion UNIQUE (descripcion)
);

CREATE TABLE pelicula(
	idPelicula INT NOT NULL,
	titulo VARCHAR(30),
	duracion INT,
    descripcion VARCHAR(1000),
	lenguaje VARCHAR(15),
	imagen VARCHAR(300),
	CONSTRAINT pk_idPelicula PRIMARY KEY (idPelicula)
);

CREATE TABLE pelXgen(
	idGenero INT NOT NULL, 
	idPelicula INT NOT NULL, 
	CONSTRAINT pk_idGenero_idPelicula PRIMARY KEY (idGenero, idPelicula),
	CONSTRAINT fk_idGenero FOREIGN KEY (idGenero) REFERENCES genero(idGenero),
	CONSTRAINT fk_idPelicula FOREIGN KEY (idPelicula) REFERENCES pelicula(idPelicula)
);

CREATE TABLE cine(
    idCine INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30) NOT NULL, 
    direccion VARCHAR(30),
    activo BOOLEAN, 
    CONSTRAINT pk_idCine PRIMARY KEY (idCine),
    CONSTRAINT unq_nombre UNIQUE (nombre)
);

CREATE TABLE sala(
    idSala INT NOT NULL AUTO_INCREMENT,
    numeroSala VARCHAR(30) NOT NULL, 
    idCine INT NOT NULL,
    capacidad INT NOT NULL,
    valorEntrada REAL NOT NULL,
    CONSTRAINT pk_idSala PRIMARY KEY (idSala),
    CONSTRAINT fk_idCine FOREIGN KEY (idCine) REFERENCES cine(idCine)

);

CREATE TABLE proyeccion(
    idProyeccion INT NOT NULL AUTO_INCREMENT,
    idPelicula INT NOT NULL,
    idSala INT NOT NULL, 
    dia DATE NOT NULL,
    hora TIME NOT NULL,
    CONSTRAINT pk_idProyeccion PRIMARY KEY (idProyeccion),
    CONSTRAINT fk_funcion_idPelicula FOREIGN KEY (idPelicula) REFERENCES pelicula(idPelicula),
    CONSTRAINT fk_idSala FOREIGN KEY (idSala) REFERENCES sala(idSala)
);

CREATE TABLE rol(
    idRol INT NOT NULL,
    descripcion VARCHAR(15), 
    CONSTRAINT pk_idRol PRIMARY KEY (idRol),
    CONSTRAINT unq_rol_descripcion UNIQUE (descripcion)
);

CREATE TABLE usuario(
    idUsuario INT NOT NULL AUTO_INCREMENT,
    idRol INT NOT NULL,
    mail varchar(30), 
    password VARCHAR(15),
    CONSTRAINT pk_idUsuario PRIMARY KEY (idUsuario),
    CONSTRAINT fk_idRol FOREIGN KEY (idRol) REFERENCES rol(idRol),
    CONSTRAINT unq_usuario_mail UNIQUE (mail)
);

CREATE TABLE perfiUsuario(
    idPerfilUsuario INT NOT NULL AUTO_INCREMENT,
    idUsuario INT,
    nombre VARCHAR(30), 
    apellido VARCHAR(30),
    dni INT,
    CONSTRAINT pk_idPerfilUsuario PRIMARY KEY (idPerfilUsuario),  
    CONSTRAINT FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario),
    CONSTRAINT unq_perfilUsuario_dni UNIQUE (dni)
);

CREATE TABLE cuentaCredito(
    idCuentaCredito INT NOT NULL,
    empresa VARCHAR(30),  
    CONSTRAINT pk_idCuentaCredito PRIMARY KEY (idCuentaCredito),
    CONSTRAINT unq_cuentaCredito_empresa UNIQUE (empresa)
);

CREATE TABLE pagoTC(
    idPagoTC INT NOT NULL AUTO_INCREMENT, 
    idCuentaCredito INT NOT NULL,
    cod_aut INT NOT NULL, 
    fecha DATE,
    total REAL,
    CONSTRAINT pk_idPagoTC PRIMARY KEY (idPagoTC),
    CONSTRAINT fk_idCuentaCredito FOREIGN KEY (idCuentaCredito) REFERENCES cuentaCredito(idCuentaCredito)
);

CREATE TABLE compra(
    idCompra INT NOT NULL AUTO_INCREMENT,
    idUsuario INT NOT NULL, 
    idPagoTC INT NOT NULL,
    cantEntradas INT,
    descuento INT,
    fecha DATE, 
    total REAL,
    CONSTRAINT pk_idCompra PRIMARY KEY (idCompra),
    CONSTRAINT fk_compra_idUsuario FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario),
    CONSTRAINT fk_compra_idPagoTC FOREIGN KEY (idPagoTC) REFERENCES pagoTC(idPagoTC)
);
    
CREATE TABLE entrada(
    idEntrada INT NOT NULL AUTO_INCREMENT,
    idProyeccion INT NOT NULL,
    idCompra INT NOT NULL,
    nroEntrada INT NOT NULL,
    qrCode varchar(100),
    CONSTRAINT pk_idEntrada PRIMARY KEY (idEntrada),
    CONSTRAINT fk_idFuncion FOREIGN KEY (idProyeccion) REFERENCES proyeccion(idProyeccion),
    CONSTRAINT fk_idCompra FOREIGN KEY (idCompra) REFERENCES compra(idCompra)
);




/* Defino Roles 1 = ADMIN 0 = USUARIO */
INSERT INTO `rol` (`idRol`, `descripcion`) 
VALUES ('1', 'admin'), 
       ('0', 'usuario');

/* Defino un administrador y un usuario */
INSERT INTO `usuario` (`idRol`, `mail`, `password`) 
VALUES ('1', 'admin@cinema.com.ar', 'admin123'), 
       ('0', 'user@cinema.com.ar', 'user123');

/* Inserto un cine */
INSERT INTO `cine` (`nombre`, `direccion`,  `activo`) VALUES ( 'Aldrey', 'Garay 1800', '1');
INSERT INTO `cine` (`nombre`, `direccion`,  `activo`) VALUES ( 'CinemaCenter', 'Cordoba 1600', '1');


/* Stored procedure para devolver el ultimo cine insertado (ID)*/

DELIMITER $$

CREATE PROCEDURE Cinema_Add(IN nombre varchar(30), IN direccion varchar(30), IN activo tinyint(1))
BEGIN  
    INSERT INTO cine
        (cine.nombre, cine.direccion , cine.activo) VALUES (nombre, direccion, activo);

    SET @id_cinema = LAST_INSERT_ID();
    SELECT @id_cinema;
END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE User_Add(IN mail varchar(30), IN password varchar(30), IN idRol int(1))
BEGIN  
    INSERT INTO usuario
        (mail, password , idRol) VALUES (mail, password, idRol);
    SET @id = LAST_INSERT_ID(); 
    SELECT @id;
     
END 
DELIMITER ;