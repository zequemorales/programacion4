<?php

namespace Controllers;

// Json
use DAO\UserDAO as UserDAO;


// Database
use DAO\UserDAOPDO as UserDaoPdo;
use DAO\FilmDAOPDO as FilmDaoPdo;
use DAO\ProyectionDAOPDO as ProyectionDaoPdo;
use DAO\CinemaDAOPDO as CinemaDaoPdo;

// Modelos
use Models\User as User;
use Models\UserProfile as UserProfile;
use Models\Role as Role;
use Models\Proyection as Proyection;
use Models\Film as Film;

/**
 * 
 */
class UserController
{
	private $userDAO;
	private $filmDAO;
	private $proyectionDAO;
	private $cinemaDAO;

	function __construct()
	{
		$this->userDAO = new UserDaoPdo();
		$this->filmDAO = new FilmDaoPdo();
		$this->cinemaDAO = new CinemaDaoPdo();
		$this->proyectionDAO = new ProyectionDaoPdo();
	}

	public function Index()
	{
		if (isset($_SESSION['loggedUser'])) {
			$loggedUser = $_SESSION['loggedUser'];
			if ($loggedUser->getRole() == 1) {
				$this->ShowAdminView();
			} else
				$this->ShowUserView();
		} else {
			$this->ShowLoginView();
		}
	}

	# Funcion para agregar un usuario
	public function Add($email, $password, $firstName, $lastName, $dni)
	{
		try {
			$userFound = null;
			# Buscar si existe el mail
			$userFound = $this->userDAO->GetUserByEmail($email);
			var_dump($userFound);
			if ($userFound == null) {
				$newUser = new User();
				$newRole = new Role();
				$newRole->setDescription('0');

				$newUser->setEmail($email);
				$newUser->setPassword($password);
				$newUser->setRole($newRole);

				# Crear el User Profile

				$newUser->setFirstName($firstName);
				$newUser->setLastName($lastName);
				$newUser->setDni($dni);

				$this->userDAO->Add($newUser);
				$message = 'Usuario creado!';
			} else {
				$message = 'Ya existe el correo registrado';
			}
			$this->ShowLoginView($message);
		} catch (Exception $ex) {
			$message = 'Oops ! ' . $ex->getMessage();
		} catch (PDOException $e) {
			throw $e;
		}
	}

	# Funcion para ingresar al sistema.
	public function Login($email, $password)
	{
		$userFound = null;
		$userFound = $this->userDAO->GetUserByEmail($email);

		if (($userFound != null) && ($password == $userFound->getPassword())) {
			if ($userFound->getRole() == '0') {
				$_SESSION['loggedUser'] = $userFound;
				$message = 'Bienvenido Usuario';
				$this->ShowUserView($message);
			} else {
				$message = 'Bienvenido Admin';
				$_SESSION['loggedUser'] = $userFound;
				$this->ShowAdminView($message);
			}
		} else {
			$message = "Email o contraseña invalidos!";
			$this->ShowLoginView($message);
		}
	}

	public function ShowLoginView($message = "")
	{
		require_once(VIEWS_PATH . 'login.php');
	}

	public function ShowRegisterView()
	{
		require_once(VIEWS_PATH . 'signup-user.php');
	}

	public function ShowUserView($message = '')
	{
		if (isset($_SESSION['loggedUser'])) {
			$userFound = $_SESSION['loggedUser'];
			$genreList = $this->filmDAO->GetAllGenre();
			$proyectionInCartelera = $this->proyectionDAO->GetAllForCartelera();
			require_once(VIEWS_PATH . 'search-proyection.php');
		} else {
			$message = "Debe iniciar sesión primero!";
			$this->ShowLoginView($message);
		}
	}

	public function ShowInCartelera($message = "")
	{

		$proyectionInCartelera = $this->proyectionDAO->GetAllForCartelera();
		require_once(VIEWS_PATH . 'search-proyection.php');
	}

	public function ShowSearch($message = '')
	{
		$genreList = $this->filmDAO->GetGenreListFromAPI();
		$proyectionList =  $this->proyectionDAO->GetAll();
		require_once(VIEWS_PATH . 'user-dashboard.php');
	}

	public function ShowAdminView($message = '')
	{
		if (isset($_SESSION['loggedUser'])) {
			$userFound = $_SESSION['loggedUser'];
			require_once(VIEWS_PATH . 'admin-dashboard.php');
		} else {
			$message = "Debe iniciar sesión primero!";
			$this->ShowLoginView($message);
		}
	}

	public function ShowProyectionSelectView($idFilm)
	{
		try {
			$remanentList = array();
			$proyectionFilmList = null;
			$filmData = null;
			$day = date("d-m-Y");
			$hour = date("h:i:s");

			$proyectionFilmList = $this->proyectionDAO->GetProyectionByIDFilm($idFilm, $day, $hour);
			$filmData = $this->filmDAO->GetFilmByID($idFilm);

			foreach ($proyectionFilmList as $proyection) {
				$remanente = $this->proyectionDAO->GetRemanentByProyection($proyection->getIdProyection(), $proyection->getSala()->getIdSala());
				array_push($remanentList, $remanente);
			}


			if ($filmData != null && $proyectionFilmList != null) {

				require_once(VIEWS_PATH . 'user-proyection-select-list.php');
			}
		} catch (Exception $ex) {
			$message = 'Oops ! ' . $ex->getMessage();
		} catch (PDOException $e) {
			throw $e;
		}
	}

	public function ShowUserProfile($message = "")
	{
		if (isset($_SESSION['loggedUser'])) {
			$loggedUser = $_SESSION['loggedUser'];

			$userData = $this->userDAO->GetProfileByIdUser($loggedUser->getID());

			if ($userData != null) {
				require_once(VIEWS_PATH . 'user-profile.php');
			} else {
				$message = 'No contiene datos el usuario. Complete los campos';
				require_once(VIEWS_PATH . 'user-profile.php');
			}
		} else {
			$message = 'Debe iniciar sesion';
			$this->ShowLoginView($message);
		}
	}

	public function LogOut()
	{
		session_destroy();
		$message = "Gracias por visitarnos";
		$this->ShowLoginView($message);
	}
}
