<?php

namespace Controllers;

use Models\Ticket as Ticket;

use DAO\ticketDAOPDO as TicketDaoPdo;

/**
 *  Controladora Ticket
 */

class TicketController
{
	private $ticketDAO;


	function __construct()
	{
		$this->ticketDAO = new TicketDaoPdo();
	}

	public function AddQr($nroTicket, $title, $cinema, $day, $hour)
	{

		$newTicket = new Ticket();
		$newTicket->setQrCode($nroTicket, $title, $cinema, $day, $hour);
		$ticketNumber = $nroTicket;
		$encontrado = $this->ticketDAO->GetTicketByTicketNumberAndProyection($ticketNumber);
		if ($encontrado == null) {
			$newTicket->setTicketNumber($ticketNumber);
		}


		$this->ticketDAO->Add($newTicket);
	}

	public function ShowTicketModal($idTicket)
	{
		$ticketFound = null;
		$ticketFound = $this->ticketDAO->getTicketByID();
		if ($ticketFound != null) {
			require_once(VIEWS_PATH . 'ticket-modal.php');
		}
	}
}
