<?php

namespace Controllers;

use \Exception as Exception;
use \PDOException as PDOException;

use DAO\CinemaDAOPDO as CinemaDaoPdo;
use DAO\ProyectionDAOPDO as ProyectionDaoPdo;
use DAO\SalaDAOPDO as SalaDaoPdo;

use Models\Proyection as Proyection;
use Models\Cinema as Cinema;
use Models\Sala as Sala;


/**
 * Controladora Cine 
 */

class CinemaController
{
    private $cinemaDAO;


    public function __construct()
    {
        $this->cinemaDAO = new CinemaDaoPdo();
        $this->salaDAO = new SalaDaoPdo();
        $this->proyectionDAO = new ProyectionDaoPdo();
    }

    public function Index()
    {
        try {
            if (isset($_SESSION['loggedUser'])) {
                $loggedUser = $_SESSION['loggedUser'];
                if ($loggedUser->getRole() == 1) {
                    require_once(VIEWS_PATH . 'cinema-add.php');
                } else {
                    $message = 'Necesita ser admin!';
                    $proyectionInCartelera = $this->proyectionDAO->GetAllForCartelera();
                    require_once(VIEWS_PATH . 'search-proyection.php');
                }
            } else {
                $message = 'Debe iniciar sesion';
                require_once(VIEWS_PATH . 'login.php');
            }
        } catch (Exception $ex) {
            $message = $ex->getMessage() . 'Oops ! \n\n Hubo un problema al intentar mostrar la Pagina.';
        }
    }




    public function validaRequerido($valor)
    {
        if (trim($valor) == '') {
            return false;
        } else {
            return true;
        }
    }

    public function validarEntero($valor, $opciones = null)
    {
        if (filter_var($valor, FILTER_VALIDATE_INT, $opciones) === FALSE) {
            return false;
        } else {
            return true;
        }
    }

    public function validaEmail($valor)
    {
        if (filter_var($valor, FILTER_VALIDATE_EMAIL) === FALSE) {
            return false;
        } else {
            return true;
        }
    }

    public function Add($name, $address, $nameSala, $capacidad, $precio)
    {
        try {
            if ($_POST) {
                isset($_POST['name']) ? $name = $_POST['name'] : $name = '';
                //isset($_POST['capacity']) ? $capacity = $_POST['capacity'] : $capacity='';
                //isset($_POST['ticketPrice']) ? $ticketPrice = $_POST['ticketPrice'] : $ticketPrice= '';
                $arregloNombreSalas = $nameSala; // $_POST['nameSala']; // $nameSala[]
                $arregloCapacidadSalas = $capacidad; //$_POST['capacidad']; // $capacidad[]
                $arregloPrecioSalas = $precio; //$_POST['precio'];  // $precio[]
                isset($_POST['address']) ? $address = $_POST['address'] : $address = '';

                $arraySalas = array();
                $errores = array();


                $nameOK = $this->validaRequerido($name);
                $addresOK = $this->validaRequerido($address);

                if (!$nameOK) {
                    $errores[] = 'El campo nombre es incorrecto.';
                }
                if (!$addresOK) {
                    $errores[] = 'El campo nombre es incorrecto.';
                }

                if (!$errores) {
                    # Creo el Cine y le asigno los datos
                    $cinema = new Cinema();
                    $cinema->setName($name);
                    $cinema->setAddress($address);

                    $encontrado = null;
                    $encontrado = $this->cinemaDAO->GetCinemaByName($cinema->getName());

                    # Recorro cuantas salas hay en arreglo. 
                    # Creo las salas y las guardo en un arreglo.  

                    for ($i = 0; $i < count($arregloNombreSalas); $i++) {
                        if ($arregloCapacidadSalas[$i] != NULL && $arregloCapacidadSalas[$i] > 0 && $arregloNombreSalas[$i] != NULL && $arregloPrecioSalas[$i] != NULL && $arregloPrecioSalas[$i] > 0) {

                            $newSala = new Sala();
                            $newSala->setName($arregloNombreSalas[$i]);
                            $newSala->setCapacity($arregloCapacidadSalas[$i]);
                            $newSala->setPrice($arregloPrecioSalas[$i]);
                            array_push($arraySalas, $newSala);
                        } else {
                            // MENSAJE QUE NO SON  MAYORES LOS DATOS
                            $errores[] = 'El campo nombre es incorrecto.';
                            $message = "COMPLETE LOS CAMPOS CON VALORES VALIDOS";
                            $this->ShowAddView($message);
                        }
                    }

                    if (!$errores) {
                        // VALIDO QUE NO HAYA UN CINE AGREGADO
                        if ($encontrado) {
                            //MENSAJE QUE YA EXISTE EL CINE
                            $message = 'Ya existe el cine que intenta ingresar';
                            $this->ShowListView($message);
                        } else {
                            $this->cinemaDAO->Add($cinema, $arraySalas);
                            $message = "Cine agregado satisfactoriamente!";
                            $this->ShowListView($message);
                        }
                    }
                } else {
                    // MENSAJE QUE NO SON  CORRECTOS
                    $message = "COMPLETE LOS CAMPOS CON VALORES VALIDOS";
                    $this->ShowAddView($message);
                }
            }
        } catch (Exception $ex) {
            $message = 'Oops ! ' . $ex->getMessage();
        }
    }


    # Agrega un cine
    /*public function Add($name,$address, $nameSala, $capacidad, $precio )
        {
            try{
                if ($_POST) 
                { 
                    
                    isset($_POST['name']) ? $name = $_POST['name']: $name ='';
                    isset($_POST['address']) ? $address = $_POST['address']: $address ='';
                    $arregloNombreSalas = $nameSala; // $_POST['nameSala']; // $nameSala[]
                    $arregloCapacidadSalas = $capacidad; //$_POST['capacidad']; // $capacidad[]
                    $arregloPrecioSalas = $precio; //$_POST['precio'];  // $precio[]
                    $arraySalas = array();
                    
                    # Creo el Cine y le asigno los datos
                    $cinema = new Cinema();    
                    $cinema->setName($name);
                                        
                    $cinema->setAddress($address);

                    $encontrado = null;
                    $encontrado = $this->cinemaDAO->GetCinemaByName($cinema->getName());
                
                    if ($encontrado == null) 
                    {    
                        $lastID = $this->cinemaDAO->Add($cinema);

                        # Recorro cuantas salas hay en arreglo. 
                        # Creo las salas y las guardo en un arreglo. Y se la seteo al cine 
                        for ($i=0; $i < count($arregloNombreSalas) ; $i++) {
                            $newSala = new Sala();
                            $newSala->setName($arregloNombreSalas[$i]);
                            $newSala->setIdCine($lastID);
                            $newSala->setCapacity($arregloCapacidadSalas[$i]);
                            $newSala->setPrice($arregloPrecioSalas[$i]);
                        
                            $this->salaDAO->Add($newSala);
                        }
                        $message = 'Cine agregado satisfactoriamente!';
                    }else{
                        $message ='Ya existe el cine que intenta ingresar';        
                    }
                }
            }
            catch(Exception $ex){
                 $message = 'Oops ! '.$ex->getMessage();
            }
            finally{
                    $this->ShowAddView($message);
            }
        }*/

    # Vista para registrar dar de ALTA un CINE
    public function ShowAddView($message = "")
    {
        try {
            if (isset($_SESSION['loggedUser'])) {
                $loggedUser = $_SESSION['loggedUser'];
                if ($loggedUser->getRole() == 1) {
                    require_once(VIEWS_PATH . 'cinema-add.php');
                } else {
                    $message = 'Necesita ser admin!';
                    $proyectionInCartelera = $this->proyectionDAO->GetAllForCartelera();
                    require_once(VIEWS_PATH . 'search-proyection.php');
                }
            } else {
                $message = 'Debe iniciar sesion';
                require_once(VIEWS_PATH . 'login.php');
            }
        } catch (Exception $ex) {
            $message = $ex->getMessage() . 'Oops ! \n\n Hubo un problema al intentar mostrar la Pagina.';
        }
    }


    # Muestra la vista que lista los cines
    public function ShowListView($message = '')
    {
        try {
            $cinemaList = null;
            if (isset($_SESSION['loggedUser'])) {
                $loggedUser = $_SESSION['loggedUser'];
                if ($loggedUser->getRole() == 1) {
                    $cinemaList = $this->cinemaDAO->getAll();

                    if ($cinemaList != null) {
                        require_once(VIEWS_PATH . "cinema-list.php");
                    } else {
                        throw new Exception("No hay cines en la base de datos!");
                    }
                } else {
                    $message = 'Necesita ser admin!';
                    $proyectionInCartelera = $this->proyectionDAO->GetAllForCartelera();
                    require_once(VIEWS_PATH . 'search-proyection.php');
                }
            } else // No está logueado.  
            {
                $message = "debe iniciar sesion";
                require_once(VIEWS_PATH . 'login.php');
            }
        } catch (Exception $ex) {
            $message = 'Oops ! ' . $ex->getMessage();
        } finally {
            require_once(VIEWS_PATH . 'cinema-list.php');
        }
    }

    public function Modify($idCinema, $name,  $address, $active)
    {
        $cinemaNew = new Cinema();
        $cinemaNew->setIdCinema($idCinema);
        $cinemaNew->setName($name);
        $cinemaNew->setAddress($address);
        $cinemaNew->setIsActive($active);

        $this->cinemaDAO->Modify($cinemaNew);

        $message = 'Cine modificado!';
        $this->ShowListView($message);
    }

    public function Delete($idCinema)
    {
        $cinamFound = null;
        $cinemaFound = $this->cinemaDAO->GetCinemaByID($idCinema);
        if ($cinemaFound != null) {
            if ($cinemaFound->getIsActive() == 1) {
                $cinemaFound->setIsActive(0);
                $message = 'Cine dado de BAJA. No eliminado!';
            } else {
                $cinemaFound->setIsActive(1);
                $message = 'Cine dado de ALTA!';
            }
        }
        $this->cinemaDAO->Modify($cinemaFound);
        $this->ShowListView($message);
    }

    # Si agrega una funcion. Borra de la base de datos la que estaba y actualiza
    public function UpdateAndAdd(Cinema $cinema)
    {
        $this->cinemaDAO->Update($cinema);
    }

    # Funcion ShowPanelView. Muestra el panel del Cliente
    public function ShowPanelView()
    {
        $calendarList = $this->calendarDAO->GetAll();
        $categoryList = $this->categoryDAO->getAll();

        require_once(VIEWS_PATH . "");
    }
}
