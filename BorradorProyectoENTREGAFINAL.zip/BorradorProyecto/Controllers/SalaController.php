<?php

namespace Controllers;

use \Exception as Exception;
use \PDOException as PDOException;

use DAO\SalaDAOPDO as SalaDaoPdo;
use DAO\CinemaDAOPDO as CinemaDaoPdo;
use DAO\ProyectionDAOPDO as ProyectionDaoPdo;

use Models\Proyection as Proyection;
use Models\Cinema as Cinema;
use Models\Sala as Sala;

/**
 * 
 */
class SalaController
{
	private $salaDAO;

	function __construct()
	{
		$this->salaDAO = new SalaDaoPdo();
	}

	public function GetSalasByIdCinema($idCinema)
	{
		$salasList = null;
		$salasList = $this->salaDAO->GetSalasByIdCinema($idCinema);
		$salasListJSon = json_encode($salasList);
	}
}
