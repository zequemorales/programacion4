<?php

namespace Controllers;

use \Exception as Exception;
use \PDOException as PDOException;

use DAO\filmDAOPDO as FilmDaoPdo;
use DAO\CinemaDAOPDO as CinemaDaoPdo;
use DAO\ProyectionDAOPDO as ProyectionDaoPdo;
use DAO\TicketDAOPDO as TicketDaoPdo;
use DAO\PurchaseDAOPDO as PurchaseDaoPdo;

use Models\Proyection as Proyection;
use Models\Cinema as Cinema;
use Models\Film as Film;
use Models\Sala as Sala;
use Models\Ticket as Ticket;
use Models\Purchase as Purchase;


/**
 * 
 */
class QueryController
{
    private $filmDAO;
    private $proyectionDAO;
    private $ticketDAO;
    private $purchaseDAO;
    private $cinemaDAO;

    function __construct()
    {
        $this->filmDAO = new FilmDaoPdo();
        $this->proyectionDAO = new ProyectionDaoPdo();
        $this->ticketDAO = new TicketDaoPdo();
        $this->purchaseDAO = new PurchaseDaoPdo();
        $this->cinemaDAO = new CinemaDaoPdo();
    }

    # Vista de entradas
    public function ShowQueryCantView($message1 = '', $message2 = '', $message3 = '', $message4 = '')
    {
        $proyectionList = $this->proyectionDAO->GetProyectionsForFilm();
        $proyectionList2 = $this->proyectionDAO->GetProyectionsForCinema();
        $proyectionList3 = $this->proyectionDAO->GetProyectionsForRemanent();
        require_once(VIEWS_PATH . 'admin-query-sales.php');
    }


    # Vista De Recaudacion
    public function ShowQueryRecaudationView($message = '', $message2 = '')
    {
        $proyectionList = $this->proyectionDAO->GetProyectionsForFilm();
        $proyectionList2 = $this->proyectionDAO->GetProyectionsForCinema();
        require_once(VIEWS_PATH . 'admin-query-recaudation.php');
    }

    # Cantidad de entradas vendidas por Titulo de pelicula
    public function QuantityByIdFilm($idFilm)
    {
        $quantityTickets = $this->purchaseDAO->QuantityByIdFilm($idFilm);
        $film = $this->filmDAO->GetFilmByID($idFilm);
        if ($quantityTickets !=  null) {
            $message1 = 'Cantidad total de tickets vendidos de la pelicula ' . $film->getTitle() . ' es de: ' . $quantityTickets;
            $this->ShowQueryCantView($message1);
        }
    }

    # Cantidad de entradas vendidas por Cine
    public function QuantityByIdCinema($idCinema)
    {

        $quantityTickets = $this->purchaseDAO->QuantityByIdCinema($idCinema);
        $cinema = $this->cinemaDAO->GetCinemaByID($idCinema);
        if ($quantityTickets !=  null) {
            $message2 = 'Cantidad total de tickets vendidos del cine ' . $cinema->getName() . ' es de: ' . $quantityTickets;
            $this->ShowQueryCantView($message1 = '', $message2);
        } else {
            $message2 = 'No hubo tickets vendidos para el cine: ' . $cinema->getName();
            $this->ShowQueryCantView($message1 = '', $message2);
        }
    }

    # Cantidad de entradas vendidas por TURNO [DIA - NOCHE -  TRASNOCHE ]
    public function QuantityByTurn($turn)
    {
        if ($turn == 'dia') {
            $timeStart = '10:00:00';
            $timeEnd = '20:00:00';
        } else
            if ($turn == 'noche') {
            $timeStart = '20:00:00';
            $timeEnd = '00:00:00';
        } else if ($turn == 'trasnoche') {
            $timeStart = '00:00:00';
            $timeEnd = '03:00:00';
        }
        $quantityTickets = $this->purchaseDAO->QuantityByTurn($timeStart, $timeEnd);
        if ($quantityTickets != null) {
            $message3 = 'Cantidad de tickets vendidos en el turno ' . $turn . ' : ' . $quantityTickets;
            $this->ShowQueryCantView($message1 = '', $message2 = '', $message3);
        } else {
            $message3 = 'No hubo tickets vendidos para el turno : ' . $turn;
            $this->ShowQueryCantView($message1 = '', $message2 = '', $message3);
        }
    }


    # Recaudacion por TITULO DE PELICULA
    public function RecaudationByTitleDate($idFilm, $dateFrom, $dateTo)
    {
        $recaudation = null;
        $film = null;
        $film = $this->filmDAO->GetFilmByID($idFilm);
        $recaudation = $this->purchaseDAO->GetRecaudationByTitleDate($idFilm, $dateFrom, $dateTo);
        if ($recaudation != null) {
            $message = 'La recaudación desde ' . $dateFrom . ' hasta ' . $dateTo . ' de la pelicula : ' . $film->getTitle() . ' fue de : $' . $recaudation;
            $this->ShowQueryRecaudationView($message);
        } else {
            $message = 'No hubo recaudacion en la pelicula: ' . $film->getTitle() . ' en esa fecha';
            $this->ShowQueryRecaudationView($message);
        }
    }

    public function RecaudationByCinemaDate($idCinema, $dateFrom, $dateTo)
    {
        $recaudation = null;
        $cinema = null;
        $cinema = $this->cinemaDAO->GetCinemaByID($idCinema);
        $recaudation = $this->purchaseDAO->GetRecaudationByCinemaDate($idCinema, $dateFrom, $dateTo);
        if ($recaudation != null) {
            $message2 = 'La recaudación desde ' . $dateFrom . ' hasta ' . $dateTo . ' del cine : ' . $cinema->getName() . ' fue de : $ ' . $recaudation;
            $this->ShowQueryRecaudationView($message = '', $message2);
        } else {
            $message2 = 'No hubo recaudacion en el cine: ' . $cinema->getName() . ' en esa fecha';
            $this->ShowQueryRecaudationView($message = '', $message2);
        }
    }

    public function GetRemanentByProyection($idProyection)
    {
        $cantVendidas = $this->proyectionDAO->GetVendidasPorProyeccion($idProyection);

        $proy = $this->proyectionDAO->GetProyectionByID($idProyection);

        if ($proy != null) {
            $idSala = $proy->getSala()->getIdSala();
        }
        $restantes = $this->proyectionDAO->GetRemanentByProyection($idProyection, $idSala);

        if ($restantes !=  null) {
            $message4 = 'Se vendieron : ' . $cantVendidas . ' ==> Remanente de entradas de ID   ' . $idProyection . ' es de : ' . $restantes;
            $this->ShowQueryCantView($message1 = '', $message2 = '', $message3 = '', $message4);
        } else {
            $message4 = ' ';
            $this->ShowQueryCantView($message1 = '', $message2 = '', $message3 = '', $message4);
        }
    }

    public function ShowQueryCart($message = '', $filter = 'compra.fecha')
    {
        if (isset($_SESSION['loggedUser'])) {
            $loggedUser = $_SESSION['loggedUser'];
        }

        if ($_POST) {
            if (isset($_POST['filtro'])) {
                $filter = $_POST['filtro'];
            }
        }
        $idUser = $loggedUser->getID();
        $ticketList = $this->proyectionDAO->GetHistorial($idUser, $filter);

        require_once(VIEWS_PATH . 'user-query-cart.php');
    }

    public function ShowTicketsDetail($idPurchase)
    {
        $ticketsByCompraList = null;
        $ticketsByCompraList = $this->ticketDAO->GetTicketsByIdCompra($idPurchase);
        require_once(VIEWS_PATH . 'ticket-detail.php');
    }
}
