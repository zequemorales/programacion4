<?php

namespace Controllers;

use Models\Purchase as Purchase;
use Models\CreditCardPayment as CreditCardPayment;

use DAO\ProyectionDAOPDO as ProyectionDaoPdo;
//use DAO\PurchaseDAOPDO as PurchaseDaoPdo;

/**
 *  Controladora de Compra
 */

class PurchaseController
{
	//private $purchaseDAO;
	private $proyectionDAO;
	private $discount = '0.25';

	function __construct()
	{
		$this->proyectionDAO = new ProyectionDaoPdo();
	}

	# Muestra la vista de compra una vez seleccionada la proyeccioón.
	public function ShowAddView($idProyection)
	{
		$quantity = 0;
		$proyection = $this->proyectionDAO->GetProyectionByID($idProyection);

		$pricePerTicket = $proyection->getSala()->getPrice();

		$dayName = date("l", strtotime($proyection->getDay()));
		if (($quantity >= 2) && ($dayName == "Tuesday" || $dayName == "Wednesday")) {
			$discount = $quantity * $pricePerTicket * 0.25;
		} else {
			$discount = 0;
		}
		$total = $quantity * $pricePerTicket - $discount;

		require_once(VIEWS_PATH . 'purchase-add.php');
	}

	# Calula el descuento del 25% si es martes/miercoles y 2 o mas entradas a comprar.
	/*public function CalculateDiscount($idProyection, $quantity){
		$proyection = $this->proyectionDAO->GetProyectionByID($idProyection);
		$pricePerTicket = $proyection->getSala()->getPrice();
		
		$dayName = date("l", strtotime($proyection->getDay()));
		if (($quantity >= 2) && ($dayName == "Tuesday" || $dayName == "Wednesday") )
		{
			$discount = $quantity * $pricePerTicket * 0.25  ;
		}
		else{
			$discount = 0;
		}
		$total = $quantity * $pricePerTicket - $discount;
		require_once(VIEWS_PATH.'purchase-add.php');
	}*/

	# Muestra la vista de pago con TC

	/*public function ShowCreditCardView($idProyection, $totalPay){
		// VERIFICAR QUE HAYA DISPONIBILDAD DE ENTRADAS EN LA PROYECCION DEL CINE QUE QUIERO COMPRAR!
		$proyection = $this->proyectionDAO->GetProyectionByID($idProyection);
		$totalPayment = $totalPay;
		require_once(VIEWS_PATH.'credit-card-checkout.php');
	}

	public function Authorize($creditCardNumber, $idProyection, $totalPay){
		$creditCardPayment = new creditCardPayment();
		# Verifica si es valida esa tarjeta de credito. 
		$isValid = $creditCardPayment->VerifyCreditCard($creditCardNumber);

		# Trae todas las cuentas credito a una lista
		$creditAccountList = $creditAccountDAO->GetAll();


		$creditAccountAuthorized = null;
		# Recorre la lista de cuentas credito y pregunta si la cuenta credito está en la base.
		# Por ejemplo. La tarjeta que paga es visa, y me fijo si visa esta en la lista para proceder
		# con el pago. 
		foreach ($creditAccountList as $creditAccount) {
			if ($creditAccount->getEnterprise() == $isValid) {
				$creditAccountAuthorized = $creditAccount;
			}
			else {
				$creditAccountAuthorized = null;
			}
		}

		// Si la tarjeta está autorizada, etnonces me tiene que crear las entradas
		if ($creditAccountAuthorized != null) {
			echo "<script>alert('autorizada');</script>";
			for ($i=1; $i <= $cantidad_de_entradas ; $i++) { 
				$ticket = new Ticket();
				//$ticket->setQrCode(); // parametros para generar el QR
				
			}
			// GENERAR LOS CODIGOS QR,
			// RESTAR LA CANTIDAD DE ENTRADAS A LA PROYECCION DEL CINE QUE CORRESPONDA
			// 
		}else{
			echo "<script>alert('Tarjeta NO autorizada!');</script>";
			$proyection = $this->proyectionDAO->GetProyectionByID($idProyection);
			$totalPayment = $totalPay;
			require_once(VIEWS_PATH.'credit-card-checkout.php');
		}
	}*/
}
