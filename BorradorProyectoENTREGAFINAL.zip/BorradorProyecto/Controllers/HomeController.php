<?php

namespace Controllers;

// DAO
use DAO\FilmDAOPDO as FilmDaoPdo;
use DAO\ProyectionDAOPDO as ProyectionDaoPdo;

// Models
use Models\Proyection as Proyection;
use Models\Film as Film;

class HomeController
{

    private $filmDAO;
    private $proyectionDAO;

    function __construct()
    {
        $this->filmDAO = new FilmDaoPdo();
        $this->proyectionDAO = new ProyectionDaoPdo();
    }

    public function Index($message = "")
    {
        $genreList  = null;
        $proyectionList = null;
        if (isset($_SESSION['loggedUser'])) {
            $loggedUser = $_SESSION['loggedUser'];
            if ($loggedUser->getRole() == 1) {

                require_once(VIEWS_PATH . 'admin-dashboard.php');
            } else {

                $genreList = $this->filmDAO->GetAllGenre();
                $proyectionList = $this->proyectionDAO->GetAll();
                require_once(VIEWS_PATH . 'user-dashboard.php');
            }
        } else {

            require_once(VIEWS_PATH . 'login.php');
        }
    }


    public function Logout()
    {
        session_destroy();
        echo "<script>alert('Gracias. Vuelva pronto...')</script>";
        require_once(VIEWS_PATH . 'login.php');
    }
}
