<?php

namespace Controllers;


use Models\CreditCardPayment as CreditCardPayment;
use Models\CreditAccount as CreditAccount;
use Models\Purchase as Purchase;
use Models\Ticket as Ticket;

use DAO\UserDAOPDO as UserDaoPdo;
use DAO\ProyectionDAOPDO as ProyectionDaoPdo;
use DAO\CreditCardPaymentDAOPDO as CreditCardPaymentDaoPdo;
use DAO\CreditAccountDAOPDO as CreditAccountDaoPdo;
use DAO\TicketDAOPDO as TicketDaoPdo;
use DAO\PurchaseDAOPDO as PurchaseDaoPdo;

use DAO\connection as Connection;


/**
 *  Controladora de PAGO TC
 */

class CreditCardPaymentController
{
	private $userDAO;
	private $creditCardPaymentDAO;
	private $creditAccountDAO;
	private $proyectionDAO;
	private $ticketDAO;
	private $purchaseDAO;
	private $dbconn;

	function __construct()
	{
		$this->userDAO = new UserDaoPdo();
		$this->proyectionDAO = new ProyectionDaoPdo();
		$this->creditCardPaymentDAO = new CreditCardPaymentDaoPdo();
		$this->creditAccountDAO = new CreditAccountDaoPdo();
		$this->ticketDAO = new TicketDaoPdo();
		$this->purchaseDAO = new PurchaseDaoPdo();
	}

	public function Index()
	{
		if (isset($_SESSION['loggedUser'])) {
			$proyectionList = $this->proyectionDAO->GetAll();
			require_once(VIEWS_PATH . 'user-dashboard.php');
		} else {
			require_once(VIEWS_PATH . 'login.php');
		}
	}

	# Muestra la vista de pago con TC
	public function ShowCreditCardView($idProyection, $quantityTickets, $discount, $totalPay)
	{
		# VERIFICAR QUE HAYA DISPONIBILDAD DE ENTRADAS EN LA PROYECCION DEL CINE QUE QUIERO COMPRAR!
		$proyection = $this->proyectionDAO->GetProyectionByID($idProyection);
		$remanentes = $this->proyectionDAO->GetRemanentByProyection($idProyection, $proyection->getSala()->getIdSala());



		if ($quantityTickets > $remanentes) {
			$message = 'No se puede comprar esa cantidad de entradas. No hay lugares disponibles.';



			$this->ShowTticketSelector($message, $idProyection);
		} else {
			$totalPayment = $totalPay;

			require_once(VIEWS_PATH . 'credit-card-checkout.php');
		}
	}

	public function ShowTticketSelector($message = '', $idProyection)
	{
		$proyection = $this->proyectionDAO->GetProyectionByID($idProyection);
		$discount = 0;

		require_once(VIEWS_PATH . 'purchase-add.php');
	}


	# Autoriza el pago con la tarjeta de credito que ingresa.
	public function Authorize($idProyection, $authCode, $quantityTickets, $creditCardNumber, $discount, $totalPay)
	{
		$creditCardPayment = new creditCardPayment();
		# Verifica si es valida esa tarjeta de credito. 
		$isValid = $creditCardPayment->VerifyCreditCard($creditCardNumber);

		# Trae todas las cuentas credito a una lista
		$creditAccountList = $this->creditAccountDAO->GetAll();

		$creditAccountAuthorized = null;
		# Recorre la lista de cuentas credito y pregunta si la cuenta credito está en la base.
		# Por ejemplo. La tarjeta que paga es visa, y me fijo si visa esta en la lista para proceder
		# con el pago. 
		foreach ($creditAccountList as $creditAccount) {
			if ($creditAccount->getEnterprise() == $isValid) {
				$creditAccountAuthorized = $creditAccount;
			} else {
				$creditAccountAuthorized = null;
			}
		}

		# Si la tarjeta está autorizada, entonces me tiene que crear las entradas
		if ($creditAccountAuthorized != null) {
			# GENERAR 
			#	1 PAGOTC	
			#	2 COMPRA (PURCHASE)
			#	3 ENTRADAS

			# ===============================================================================
			# 1  Pago TC

			$creditCardPayment->setDate(date('Y-m-d'));
			$creditCardPayment->setIdCreditAccount($creditAccountAuthorized->getIdCreditAccount());
			$creditCardPayment->setAuthCode($authCode);
			$creditCardPayment->setTotal($totalPay);

			$this->creditCardPaymentDAO->Add($creditCardPayment);
			$creditCardPaymentID = null;

			$creditCardPaymentID = $this->creditCardPaymentDAO->GetLastInsertId();


			# ================================================================================
			# 2 Compra

			$purchase = new Purchase();
			$purchase->setDate(date('Y-m-d'));
			$purchase->setQuantityTickets($quantityTickets);
			$purchase->setTotal($totalPay);
			$purchase->setDiscount($discount);

			$purchaseID = null;
			if (isset($_SESSION['loggedUser'])) {
				$loggedUser = $_SESSION['loggedUser'];
				$user = $this->userDAO->getUserByEmail($loggedUser->getEmail());
			}

			if ($creditCardPaymentID != null) {
				$this->purchaseDAO->Add($purchase, $user->getID(),  $creditCardPaymentID);
				$purchaseID = $this->purchaseDAO->GetLastInsertId();
			} else {
				$message = "No existe Pago valido para efectuar la compra";
			}

			# ================================================================================
			# 3 Entrada
			$proyection = null;
			$proyection = $this->proyectionDAO->GetProyectionByID($idProyection);

			for ($i = 1; $i <= $quantityTickets; $i++) {
				$ticket = new Ticket();
				$ticketFound = null;
				$numberTicket = rand(1, 999999);

				$ticketFound = $this->ticketDAO->getTicketByNumber($numberTicket);
				if ($ticketFound != null) {
					$ticket->setTicketNumber($numberTicket + rand(1, 70000));
				} else {
					$ticket->setTicketNumber($numberTicket);
				}

				if ($proyection != null) {

					$qrCode = $ticket->getTicketNumber() . $proyection->getFilm()->getTitle() . $proyection->getDay() . $proyection->getTime();
					$ticket->setQrCode($qrCode);
				} else {
					$message = "no existe proyeccion para la compra de este ticket";
				}

				$this->ticketDAO->Add($ticket, $idProyection, $purchaseID);
			}
			$message = 'Compra exitosa';
			$proyectionList = $this->proyectionDAO->GetAll();
			require_once(VIEWS_PATH . 'user-dashboard.php');
			// Restar la cantidad de tickets a la capacidad para que me de la cantidad de disponibles ?

		} else {
			$message = 'Tarjeta NO autorizada!';
			$proyection = $this->proyectionDAO->GetProyectionByID($idProyection);
			$totalPayment = $totalPay;
			require_once(VIEWS_PATH . 'credit-card-checkout.php');
		}
	}
}
