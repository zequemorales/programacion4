<?php

namespace Controllers;


use DAO\ProyectionDAOPDO as ProyectionDaoPdo;
use DAO\CinemaDAOPDO as CinemaDaoPdo;
use DAO\FilmDAOPDO as FilmDaoPdo;

use Models\Proyection as Proyection;
use Models\Cinema as Cinema;
use Models\Film as Film;
use Models\Sala as Sala;

use \Exception as Exception;
use \PDOException as PDOException;

/**
 *  Controladora de funciones
 */

class ProyectionController
{
	private $proyectionDAO;
	private $cinemaDAO;
	private $filmDAO;

	function __construct()
	{
		$this->proyectionDAO = new ProyectionDaoPdo();
		$this->cinemaDAO = new CinemaDaoPdo();
		$this->filmDAO = new FilmDaoPdo();
	}

	public function Index()
	{
		if (!isset($_SESSION['loggedUser'])) {
			$message = 'Debe iniciar sesion';
			require_once(VIEWS_PATH . 'login.php');
		} else {
			$loggedUser = $_SESSION['loggedUser'];
			if ($loggedUser->getRole() == 1) {
				$message = 'Redireccionando admin..';
				require_once(VIEWS_PATH . 'admin-dashboard.php');
			} else {
				$message = 'Redireccionando user..';
				$proyectionInCartelera = $this->proyectionDAO->GetAllForCartelera();

				require_once(VIEWS_PATH . 'search-proyection.php');
			}
		}
	}

	# Muestra la vista para agregar una función.
	public function ShowAddView($message = '')
	{
		if (isset($_SESSION['loggedUser'])) {
			//$salasByCinemaList = $this->cinemaDAO->GetSalasByCinema();
			$salasList = $this->cinemaDAO->GetAllSalas();
			$filmList = $this->filmDAO->GetAll();
			$cinemaList = $this->cinemaDAO->GetAll();
			require_once(VIEWS_PATH . "proyection-add.php");
		} else {
			require_once(VIEWS_PATH . 'login.php');
		}
	}

	# ME tendria que traer las salas
	public function GetSalas($idCine)
	{
		$idCine = $_POST['cinema'];
		$data = $idCine;
		$salas = $this->cinemaDAO->GetSalasByCinema($data);
	}

	# Agrega una funcion a la Base de Datos.
	public function Add($title,  $sala, $day, $time)
	{
		try {
			if ($_POST) {
				if (isset($_POST['title']) && isset($_POST['day']) && isset($_POST['time'])) {
					var_dump($_POST['sala']);

					$title = $_POST['title'];
					$sala = $_POST['sala'];
					$day = $_POST['day'];
					$time = $_POST['time'];
					//$idSala = $_POST['sala'];		
					//var_dump($Sala);
					//"Id Sala:".$sala.'<br>';

					# Evalua si existe la pelicula para un dia determinado
					$proyectionFound = null;
					$proyectionFound = $this->proyectionDAO->GetProyectionByTitleDay($title, $day, $time);

					if ($proyectionFound == null) {
						$proyection = new Proyection();

						$proyection->setFilm($title);
						$proyection->setSala($sala);
						$proyection->setDay($day);
						$proyection->setTime($time);


						# Evalua el horario para insertar la proyeccion
						$proyections = $this->proyectionDAO->GetAll();
						$cantProyections = count($proyections);


						/*for ($i=0; $i < $cantProyections ; $i++) {
								// (1) SI ES LA PRIMERA
								$horaInicio = new \DateTime($proyections[$i]->getTime());
								
								//$date = new DateTime($proyection->getTime());
								$horaFinMas = new \DateTime($proyections[$i]->getTime());
								$horaFinMas->modify('+'.$proyections[$i]->getFilm()->getDuration().'minute');
								$horaFinMas->modify('+15minute');
 								var_dump($horaInicio); var_dump($horaFinMas);
								if ($time < $horaInicio) {
									$this->proyectionDAO->Add($proyection);
								}
								else{
										if ($time > $horaFinMas ) {
											$this->proyectionDAO->Add($proyection);
										}
										else{
											$message = "No se puede ingresar la proyeccion en ese horario!";
										}
								}
								// (2) SI ESTA EN EL MEDIO 
								$filmToInsert = $this->filmDAO->GetFilmByTitle($title);
								$timeEndNewFilm = new \DateTime($time);
								$timeEndNewFilm->modify('+'.$filmToInsert->getDuration().'minute');
								$timeEndNewFilm->modify('+15minute');
								if (($time > $horaFinMas) && ($timeEndNewFilm < $proyections[$i+1]->getTime()) ) {
									$this->proyectionDAO->Add($proyection);
								}
								else{
									$message = "No se puede ingresar la proyeccion en ese horario!";
								}
								// (3) SI ESTA A LO ULTIMO
								/*if ($time > $horaFinMas) {
									$this->proyectionDAO->Add($proyection);
								}
								else{
									$message = "No se puede ingresar la proyeccion en ese horario!";	
								}
							}*/

						$message = 'Proyeccion agregada satisfactoriamente!';
					} else {
						$message = "Ya existe la pelicula en alguna proyeccion para ese dia!";
					}
				} else {
					$message = "Falta información requerida";
				}
			} else {
				$message = "Eror al ingresar. Intente nuevamente";
			}
		} catch (Exception $ex) {
			$message = 'Oops ! ' . $ex->getMessage();
		} catch (PDOException $e) {
			throw $e;
		} finally {
			$this->ShowAddView($message);
		}
	}

	public function Add2($title, $cinema, $sala, $day, $time)
	{
		try {
			if ($_POST) {
				if (isset($_POST['title']) && isset($_POST['cinema']) && isset($_POST['day']) && isset($_POST['time'])) {
					$cinema = $_POST['cinema'];
					$title = $_POST['title'];
					$day = $_POST['day'];
					$time = $_POST['time'];
					$sala = $_POST['sala'];

					# Creo el horario de finalizacion de la proyec. que quiero ingresar
					$timeStart = new \DateTime($time);
					$timeEnd = new \DateTime($time);
					$filmDuration = $this->filmDAO->GetFilmByID($title);
					$timeEnd->modify('+' . $filmDuration->getDuration() . 'minute');
					$timeEnd->modify('+15 minute');

					# Si esta fuera de rango, NO Deja insertar.
					if ($timeStart->format('H:i:s') < '10:00:00' && $timeEnd->format('H:i:s') > '03:00:00') {
						$message = ' No se puede insertar fuera de horario';
					} else { # Evalúo si esta dentro del rango.

						# Verifico que no exista la pelicula para un dia determinado
						$arrayProyectionFound = null;
						$arrayProyectionFound = $this->proyectionDAO->GetProyectionByTitleDay($title, $day);

						if ($arrayProyectionFound != null) {

							if ($arrayProyectionFound->getSala()->getIdSala() == $sala) {
								# Traeme las proy. de esa sala, ese dia
								$proyectionsSalaDay = null;
								$proyectionsSalaDay = $this->proyectionDAO->GetProyectionsBySalaDay($sala, $day);
								if ($proyectionsSalaDay != null) {
									for ($i = 0; $i < count($proyectionsSalaDay); $i++) {

										$proyectionTime = new \DateTime($proyectionsSalaDay[$i]->getTime());

										# Creo el horario de finalizacion de la proyeccion en el arreglo.
										$proyectionTimeEnd = new \DateTime($proyectionsSalaDay[$i]->getTime());
										$proyectionTimeEnd->modify('+' . $proyectionsSalaDay[$i]->getFilm()->getDuration() . ' minute');
										$proyectionTimeEnd->modify('+15 minute');

										# Evalúo primera condicion.
										if ($timeStart < $proyectionTime && $timeEnd < $proyectionTime) {
											$proyectionAdd = new Proyection();
											$proyectionAdd->setFilm($title);
											$proyectionAdd->setSala($sala);
											$proyectionAdd->setDay($day);
											$proyectionAdd->setTime($timeStart);
											$message = 'Proyeccion agregada satisfactoriamente!';
											$this->proyectionDAO->Add($proyectionAdd);
										}

										# Evalúo segunda condicion

										if (!empty($proyectionsSalaDay[$i + 1])) {
											$proyectionNextTime = new \DateTime($proyectionsSalaDay[$i + 1]->getTime());
											if ($timeStart > $proyectionTimeEnd  && $timeEnd < $proyectionNextTime) {

												$proyectionAdd = new Proyection();
												$proyectionAdd->setFilm($title);
												$proyectionAdd->setSala($sala);
												$proyectionAdd->setDay($day);
												$proyectionAdd->setTime($timeStart->format('H:i:s'));
												$message = 'Proyeccion agregada satisfactoriamente!';
												$this->proyectionDAO->Add($proyectionAdd);
											}
										} else
											# Evalúo tercera condicion
											if ($timeStart > $proyectionTimeEnd) {
												$proyectionAdd = new Proyection();
												$proyectionAdd->setFilm($title);
												$proyectionAdd->setSala($sala);
												$proyectionAdd->setDay($day);
												$proyectionAdd->setTime($timeStart);
												$message = 'Proyeccion agregada satisfactoriamente!';
												$this->proyectionDAO->Add($proyectionAdd);
											} else { # No hay horario disponible para esa sala que tiene la peli
												$message = 'No existe horario disponible';
											}
									}	# Cierre del FOR
								} #Cierre del If $proyectionsSalaDay
								else {
									// NO SE PUEDE DAR EN OTRA SALA 
									$message = 'No se puede agregar proyección!! ';
									echo 'no se puede dar en otra sala';
								}
							} #Cierre del if getSala() = $sala
							else {
								# Si $arrayProyectionFound[0]->getSala() No Es la sala que quiero ingresar
								$message = 'No se puede ingresar en otra sala! ';
							}
						} else # $arrayProyectionFound == null
						{
							$proyectionsList = null;
							$proyectionsList = $this->proyectionDAO->GetProyectionsBySalaDay($sala, $day);

							if ($proyectionsList == null) {
								$proyectionAdd = new Proyection();
								$proyectionAdd->setFilm($title);
								$proyectionAdd->setSala($sala);
								$proyectionAdd->setDay($day);
								$proyectionAdd->setTime($timeStart);
								$message = 'Proyeccion agregada satisfactoriamente!';
								$this->proyectionDAO->Add($proyectionAdd);
							} else {
								for ($i = 0; $i < count($proyectionsList); $i++) {
									# Evalúo primera condicion.
									$proyectionTime = new \DateTime($proyectionsList[$i]->getTime());
									# Creo el horario de finalizacion de la proyeccion en el arreglo.
									$proyectionTimeEnd = new \DateTime($proyectionsList[$i]->getTime());
									$proyectionTimeEnd->modify('+' . $proyectionsList[$i]->getFilm()->getDuration() . ' minute');
									$proyectionTimeEnd->modify('+15 minute');

									if ($timeStart < $proyectionTime && $timeEnd < $proyectionTime) {
										$proyectionAdd = new Proyection($proyectionsList->getTime());
										$proyectionAdd->setFilm($title);
										$proyectionAdd->setSala($sala);
										$proyectionAdd->setDay($day);
										$proyectionAdd->setTime($timeStart);
										$message = 'Proyeccion agregada satisfactoriamente!';
										$this->proyectionDAO->Add($proyectionAdd);
									} else # Evalúo segunda condicion
										if ($timeStart > $proyectionTimeEnd  && $timeEnd < $proyectionTime) {
											$proyectionAdd = new Proyection();
											$proyectionAdd->setFilm($title);
											$proyectionAdd->setSala($sala);
											$proyectionAdd->setDay($day);
											$proyectionAdd->setTime($timeStart);
											$message = 'Proyeccion agregada satisfactoriamente!';
											$this->proyectionDAO->Add($proyectionAdd);
										} else # Evalúo tercera condicion
											if ($timeStart > $proyectionTimeEnd) {
												$proyectionAdd = new Proyection();
												$proyectionAdd->setFilm($title);
												$proyectionAdd->setSala($sala);
												$proyectionAdd->setDay($day);
												$proyectionAdd->setTime($timeStart);
												$message = 'Proyeccion agregada satisfactoriamente!';
												$this->proyectionDAO->Add($proyectionAdd);
											} else { # No hay horario disponible para esa sala que tiene la peli
												$message = 'No existe horario disponible';
											}
								} # Cierre del FOR
							}
						}
					}
				} #Cierre del isset
				else {
					$message = 'falta algun dato requerido';
				}
			} #cierre del POST	
			else {
				$message = "Error al procesar informacion por POST";
			}
		} #cierre del TRY
		catch (Exception $ex) {
			$message = 'Oops ! ' . $ex->getMessage();
		} catch (PDOException $e) {
			throw $e;
		} finally {
			$this->ShowAddView($message);
		}
	}

	# Busca proyecciones 
	public function Search($genre, $date, $message = '')
	{
		try {
			if ($this->ValidateSession() == true) {
				$proyectionList = null;

				# Estan seteadas las 2 (genero y fecha)
				if (($genre != 0) && ((isset($date) || $date != null))) {
					# Genero y fecha
					$proyectionList = $this->proyectionDAO->GetProyectionByGenreAndDate($genre, $date);

					if ($proyectionList == null) {
						$message = "No se encontraron proyecciones para el genero y fecha ingresado!";

						$this->ShowUserDashboard($message);
					} else {

						$genreList = $this->filmDAO->GetAllGenre();
						require_once(VIEWS_PATH . 'user-dashboard.php');
					}
				}

				# Solo el genero ( Pero por default le paso la fecha)
				/*else if ( ($genre != 0)  ){
			 		//$date = date('Y-m-d');
			 		$proyectionList = $this->proyectionDAO->GetProyectionByGenreAndDate($genre, $date);
			 		if ($proyectionList == null){
			 			$message = "No se encontraron proyecciones para el genero solicitado";
			 		}else{
			 			echo"<script>alert('GENERO ');</script>";
			 			$genreList = $this->filmDAO->GetAllGenre();
			 			require_once(VIEWS_PATH.'user-dashboard.php');	
			 		}	
			 	}*/

				# Solo seteada la fecha
				else if ((isset($date) || $date != null) && ($genre == 0)) {
					$proyectionList = $this->proyectionDAO->GetProyectionByDate($date);
					if ($proyectionList == null) {
						$message = "No se encontraron proyecciones para la fecha ingresada";
						$this->ShowUserDashboard($message);
					} else {

						$genreList = $this->filmDAO->GetAllGenre();
						require_once(VIEWS_PATH . 'user-dashboard.php');
					}
				}
			} else {
				$message = 'Debe iniciar sesion!';
				$this->ShowLoginView($message);
			}
		} catch (Exception $ex) {
			$message = 'Oops ! ' . $ex->getMessage();
		} catch (PDOException $e) {
			throw $e;
		}
	}

	public function ShowUserDashboard($message = '')
	{
		$proyectionList = $this->proyectionDAO->GetAll();
		$genreList = $this->filmDAO->GetAllGenre();
		require_once(VIEWS_PATH . 'user-dashboard.php');
	}

	public function ShowLoginView($message = '')
	{
		require_once(VIEWS_PATH . 'login.php');
	}

	private function ValidateSession()
	{
		if (isset($_SESSION['loggedUser'])) {
			return true;
		} else {
			return false;
		}
	}

	public function ProyectionAdded()
	{
		require_once(VIEWS_PATH . 'proyection-add.php');
	}
}
