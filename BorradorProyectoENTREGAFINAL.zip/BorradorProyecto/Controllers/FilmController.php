<?php

namespace Controllers;

use \Exception as Exception;
use \PDOException as PDOException;

//Json
use DAO\FilmDAO as FilmDAO;


//PDO
use DAO\FilmDAOPDO as FilmDaoPdo;  // Dentro del FilmDAOPDO estan los generos.
use DAO\ProyectionDAOPDO as ProyectionDaoPdo;

/**
 * Controladora pelicula
 */

class FilmController
{
	private $filmDAO;

	function __construct()
	{
		$this->filmDAO = new FilmDaoPdo();
		$this->proyectionDAO = new ProyectionDaoPdo();
	}

	public function Index()
	{
		try {
			if (isset($_SESSION['loggedUser'])) {
				$loggedUser = $_SESSION['loggedUser'];
				if ($loggedUser->getRole() == 1) {
					require_once(VIEWS_PATH . 'cinema-add.php');
				} else {
					$message = 'Necesita ser admin!';
					$proyectionInCartelera = $this->proyectionDAO->GetAllForCartelera();
					require_once(VIEWS_PATH . 'search-proyection.php');
				}
			} else {
				$message = 'Debe iniciar sesion';
				require_once(VIEWS_PATH . 'login.php');
			}
		} catch (Exception $ex) {
			$message = $ex->getMessage() . 'Oops ! \n\n Hubo un problema al intentar mostrar la Pagina.';
		}
	}

	# Peliculas en Cartelera "now playing". AHORA desde la API a una lista
	public function ShowCarteleraView()
	{
		$filmList = $this->filmDAO->GetJsonFromAPI();
		require_once(VIEWS_PATH . '3dcarruousel2.php');
	}

	# MODIFICAR ?
	public function ShowListView()
	{
		// Trae las peliculas Primero local, despues de la api
		$filmList = null;
		$filmList = $this->filmDAO->RetrieveData();
		if ($filmList == null) {
			echo "<script>alert('Trayendo pelis de la API');</script>";
			$filmList = $this->filmDAO->GetJsonFromAPI();
		}

		# Trae los generos. Primero local. Despues de  la api
		$genreList = null;
		$genreList = $this->filmDAO->RetrieveGenreData();
		if ($genreList != null) {
			echo "<script>alert('Generos del archivo local');</script>";
		} else {
			echo "<script>alert('Generos de la API');</script>";
			$genreList = $this->filmDAO->getJsonGenre();
		}
		$this->filmDAO->SaveGenreData();

		require_once(VIEWS_PATH . "film-list.php");
	}

	public function ShowFichaView($filmID)
	{
		try {
			if (isset($_SESSION['loggedUser'])) {
				$loggedUser = $_SESSION['loggedUser'];
				if ($loggedUser->getRole() == 1) {
					require_once(VIEWS_PATH . 'cinema-add.php');
				} else {
					$message = 'Necesita ser admin!';
					$filmFound = null;
					$filmFound = $this->filmDAO->GetFilmByID($filmID);
					require_once(VIEWS_PATH . 'film-ficha.php');
				}
			} else {
				$message = 'Debe iniciar sesion';
				require_once(VIEWS_PATH . 'login.php');
			}
		} catch (Exception $ex) {
			$message = $ex->getMessage() . 'Oops ! \n\n Hubo un problema al intentar mostrar la Pagina.';
		}
	}

	/* Metodo para actualizar la base de datos de las peliculas y generos.
		** Ambas las almaceno de la api a una lista. Y consulto si esta c/   
		** pelicula y c/ género en la base. Si no están, las guardo.
		*/
	public function UpdateFilmsAndGenres()
	{
		$filmList = null;
		$genreList = null;
		$filmList = $this->filmDAO->GetFilmListFromAPI();
		$genreList = $this->filmDAO->GetGenreListFromAPI();

		if ($filmList != null) {
			foreach ($filmList as $film) {
				$filmFound = null;
				$filmFound = $this->filmDAO->GetFilmByTitle($film->getTitle());
				if ($filmFound = null) {
					$this->filmDAO->Add($film);			 # Si no está, la agrego a la base de datos
					$this->filmDAO->AddFilmGenre($film); # Agrego los generos de esa pelicula a la tabla intermedia
				}
			}
		}

		if ($genreList != null) {
			$this->filmDAO->DeleteAllGenres();

			foreach ($genreList as $genre) {
				$genreFound = null;
				$genreFound = $this->filmDAO->GetGenreByDescription($genre->GetDescription());
				if ($genreFound = null) {
					$this->filmDAO->AddGenre($genre);
				}
			}
		}
	}

	# Metodo para consultar la duracion de una pelicula. (Hay que consumir otra API)
	public function GetDuration(Film $film)
	{
		try {
			$duration = null;
			$duration = $this->filmDAO->GetJsonDuration($film->getIdFilm());
			if ($duration == null) {
				echo "<script>alert('No existe la pelicula!');</script>";
			} else {
				return $duration;
			}
		} catch (Exception $ex) {
			$message = 'Oops ! ' . $ex->getMessage();
		} catch (PDOException $e) {
			throw $e;
		}
	}

	public function GetFilmDetails($filmID)
	{
		//$filmDetails = null;
		//$filmDetails = $hits->filmDAO->GetFilmByID($filmID);	
	}

	public function Update($message = '')
	{
		try {
			$filmList = null;
			$filmList = $this->filmDAO->GetFilmListFromAPI();

			$genreList = null;
			$genreList = $this->filmDAO->GetGenreListFromAPI();

			# Agrego los generos
			if ($genreList != null) {
				foreach ($genreList as $genre) {
					$this->filmDAO->AddGenre($genre);
				}
			}

			# Agrego las peliculas y los generos x pelicula
			if ($filmList != null) {
				foreach ($filmList as $film) {
					$this->filmDAO->Add($film);
					$this->filmDAO->AddFilmGenre($film);
				}
			}

			$message = 'Peliculas actualizadas con sus generos';

			require_once(VIEWS_PATH . 'admin-dashboard.php');
		} catch (Exception $ex) {
			$message = 'Oops ! ' . $ex->getMessage();
		} catch (PDOException $e) {
			throw $e;
		}
	}
}
