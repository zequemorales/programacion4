<?php
if ($_POST) {
	if (isset($_POST['time'])) {
		//var_dump($_POST['time']);
		$time = $_POST['time'];
		foreach ($time as $valor) {
			echo $valor . '---';
		}
		//print_r($_POST['time'][0]);
	} else {
		echo "no hay ISSET POST";
	}
}
?>

<!-- Begin page content -->

<html>
<form action="?" method="post">

	<label class="heading">Seleccione su hora favorito:</label>
	<div class="checkbox">
		<label><input type="checkbox" name="time[]" value="11:00">11:00</label>
	</div>
	<div class="checkbox">
		<label><input type="checkbox" name="time[]" value="13:50">13:50</label>
	</div>
	<div class="checkbox">
		<label><input type="checkbox" name="time[]" value="15:00">15:00</label>
	</div>
	<div class="checkbox">
		<label><input type="checkbox" name="time[]" value="21:50">21:50</label>
	</div>
	<div class="checkbox">
		<label><input type="checkbox" name="time[]" value="00:30">00:30</label>
	</div>
	<button type="submit" name="enviar">Enviar Información</button>
	<!----- Including PHP Script  ----->

</form>


</body>

</html>