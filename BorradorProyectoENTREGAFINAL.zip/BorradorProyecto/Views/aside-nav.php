<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Peliculas</title>

    <link href="https://fonts.googleapis.com/icon?family=Poppins" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css">
    <link rel="stylesheet" href="css/app.css">
</head>


<div class="column is-2 is-fullheight is-hidden-touch" id="navigation">
    <aside class="menu">
        <p class="menu-label is-hidden-touch">General</p>
        <ul class="menu-list">
            <li>
                <a class="" href="index.html">
                    <span class="icon">
                        <i class="fa fa-home"></i>
                    </span> ABM Cines
                </a>
            </li>
            <li>
                <a class="" href="forms.html">
                    <span class="icon">
                        <i class="fa fa-edit"></i>
                    </span> Peliculas
                </a>
            </li>
            <li>
                <a class="" href="elements.html">
                    <span class="icon">
                        <i class="fa fa-desktop"></i>
                    </span> Cartelera
                </a>
            </li>
            <li>
                <a class="is-active" href="datatables.html">
                    <span class="icon">
                        <i class="fa fa-table"></i>
                    </span> Datatables
                </a>
            </li>
        </ul>

        <p class="menu-label is-hidden-touch">Sample Pages</p>
        <ul class="menu-list">
            <li>
                <a class="" href="login.html">
                    <span class="icon">
                        <i class="fa fa-lock"></i>
                    </span> Login
                </a>
            </li>
        </ul>
    </aside>
</div>