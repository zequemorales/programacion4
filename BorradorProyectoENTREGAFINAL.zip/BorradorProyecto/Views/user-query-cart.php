<?php include('top-nav.php'); ?>



<div class="columns" id="app-content">
    <?php include('user-aside-nav.php'); ?>

    <div class="column is-10" id="page-content">

        <div class="content-header">
            <h4 class="title is-4">Carrito </h4>
            <span class="separator"></span>
            <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                <ul>
                    <li>Historial Compras</li>

                    <li style="color:red"><b><?php if ($message != null) {
                                                    $string = explode(".", $message);
                                                    echo "Filtrando por " . $string[1];
                                                } ?></b></li>
                </ul>
            </nav>
        </div>


        <div class="content-body">
            <div class="card">
                <form action="<?= FRONT_ROOT ?>Query/ShowQueryCart" method="POST">
                    <div class="card-filter">
                        <div class="field">
                            <p class="title is-4">Entradas Adquiridas</p>
                            <div class="select">
                                <select name="filtro">
                                    <option value="pelicula.titulo">Pelicula</option>
                                    <option value="compra.fecha">Fecha</option>
                                </select>
                            </div>
                            <button class="button is-link has-icons-right" type="submit">Ordenar</button>
                        </div>



                        <!--    <div class="field">
                                    <input class="input" name="date" type="date" 
                                    min="<?php echo date('Y-m-d'); ?>" 
                                    value="<?php echo date('Y-m-d'); ?>" 
                                    max="<?php echo (date('Y') + 1) . date('-Y-m-d'); ?>"  >
                                </div>-->
                        <div class="field">

                        </div>
                    </div>
                </form>
                <div class="card-content">
                    <table class="table is-hoverable is-bordered is-fullwidth" id="datatable">
                        <thead>
                            <tr>
                                <th class="has-text-centered"> Fecha de Compra</th>
                                <th class="has-text-centered"> Cine</th>
                                <th class="has-text-centered"> Pelicula</th>
                                <th class="has-text-centered"> Dia</th>
                                <th class="has-text-centered"> Horario</th>
                                <th class="has-text-centered"> Total compra </th>


                                <th class="has-text-centered">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php if ($ticketList != null) {
                                foreach ($ticketList as $ticket) {


                                    ?>

                                    <tr>
                                        <td class="has-text-centered"><?= $ticket->getPurchase()->getDate(); ?></td>
                                        <td class="has-text-centered"><?= $ticket->getProyection()->getSala()->getIdCine()->getName(); //$ticket->getFilm()->getTitle(); 
                                                                                ?></td>
                                        <td class="has-text-centered"><?= $ticket->getProyection()->getFilm()->getTitle(); ?></td>
                                        <td class="has-text-centered"><?= $ticket->getProyection()->getDay(); ?></td>
                                        <td class="has-text-centered"><?= $ticket->getProyection()->getTime(); ?></td>
                                        <td class="has-text-centered"><?= '$ ' . $ticket->getPurchase()->getTotal(); ?></td>

                                        <td class="has-text-centered">
                                            <form action="<?= FRONT_ROOT ?>Query/ShowTicketsDetail" method="POST">
                                                <a class="btnEdit"><button type="submit" class="button is-success" value="<?= $ticket->getPurchase()->getIdPurchase(); ?>" id="modifyButton2<?= $ticket->getTicketID(); ?>" name="btnTicket<?= $ticket->getTicketID(); ?>">Ver Detalle</button></a>
                                            </form>
                                        </td>

                                    </tr>
                            <?php }
                            } ?>


                        </tbody>

                    </table>
                </div>
            </div>
        </div>



    </div>
</div>


<!-- SCRIPT PARA CREAR MODALES DINAMICOS -->
<script type="text/javascript">
    <?php
    foreach ($ticketList as $value) {
        echo "var boton" . $value->getTicketID() . "= document.getElementById('modifyButton2" . $value->getTicketID() . "');";
        echo "boton" . $value->getTicketID() . ".onclick = function(){
                    modal.style.display = 'block';
                    };";
    }
    ?>
</script>


<script type="text/javascript">
    var button = document.getElementById('modifyButton');
    // var botoncito =  document.getElementById('modifyButton2');
    var modal = document.getElementById('exampleModal');
    var close = document.getElementById('modal-close');

    //button.onclick= function(){
    //   modal.style.display = 'block';
    //}
    //botoncito.onclick= function(){
    //  modal.style.display = 'block';
    //}           
</script>

<script type="text/javascript">
    var fila;
    // Codigo para boton editar
    $(document).on("click", ".btnEdit", function() {
        fila = $(this).closest("tr");
        id = parseInt(fila.find('td:eq(0)').text());
        name = fila.find('td:eq(1)').text();
        //capacity = parseInt(fila.find('td:eq(2)').text());
        //ticketPrice = parseInt(fila.find('td:eq(3)').text());
        address = fila.find('td:eq(2)').text();
        active = fila.find('td:eq(3)').text();

        $("#id").val(id);
        $("#name").val(name);
        //$("#capacity").val(capacity);
        //$("#ticketPrice").val(ticketPrice);
        $("#address").val(address);
        $("#active").val(active);
    });
</script>