<?php

namespace Views;

include('top-nav.php'); ?>

<div class="columns" id="app-content">

    <?php include('admin-aside-nav.php'); ?>

    <div class="column is-10" id="page-content">

        <div class="content-header">
            <h4 class="title is-4">Forms</h4>
            <span class="separator"></span>
            <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                <ul>
                    <li><a href="#">Administrar Cines</a></li>
                    <li class="is-active"><a href="#" aria-current="page">Alta Cine</a></li>
                </ul>
            </nav>
        </div>

        <div class="content-body">
            <div class="columns">
                <div class="column">
                    <div class="card">
                        <div class="card-content">
                            <p class="title is-4">Formulario Alta Cine</p>
                            <p style="color: red;font-size:18px"> <?php if ($message != null) {
                                                                        echo $message;
                                                                    } ?></p>
                            <form action="<?= FRONT_ROOT ?>Cinema/Add" method="POST">

                                <div class="field">
                                    <label class="label">Nombre </label>
                                    <div class="control">
                                        <input class="input" name="name" type="text" placeholder="Nombre del Cine" required="">
                                    </div>
                                </div>

                                <div class="field">
                                    <label class="label">Dirección</label>
                                    <div class="control">
                                        <input class="input" name="address" type="address" placeholder="Dirección" required="">
                                    </div>
                                </div>


                                <!-- AGREGAMOS UN INPUT FIJO PARA QUE SI O SI AGREGUE AL MENOS UNA SALA CON CAMPOS REQUERIDOS PARA VALIDAR EL INGRESO DE DATOS  -->

                                <div class="field">
                                    <label class="label">Sala 1 </label>
                                    <div class="control">
                                        <input class="input" id="nameSala1" name="nameSala[]" type="text" placeholder="Nombre de la Sala" value="SALA 1" required="">
                                    </div>
                                    <label class="label">Capacidad Sala 1 </label>
                                    <div class="control">
                                        <input class="input" id="capacidadSala1" name="capacidad[]" type="text" placeholder="Capacidad de la Sala" required="">
                                    </div>
                                    <label class="label">Precio Ticket Sala 1 </label>
                                    <div class="control">
                                        <input class="input" id="precioSala1" name="precio[]" type="text" placeholder="Precio Ticket" required="">
                                    </div>
                                </div>

                                <!-- campo = '<u><li id="labelName'+nextinput+'" style="font-size:20px">sala '+nextinput+':</u>	<input class="input"  type="text" size="20" id="nameSala' + nextinput + '"&nbsp; name="nameSala[]" value="SALA '+nextinput+'"  /></li><br><li id="labelCapacidad'+nextinput+'">Capacidad sala '+nextinput+':<input class="input" type="text" size="20" id="capacidadSala' + nextinput + '"&nbsp; name="capacidad[]"/></li><br><li id="labelPrecio'+nextinput+'">Precio ticket sala '+nextinput+':<input class="input" type="text" size="20" id="precioSala' + nextinput + '"&nbsp; name="precio[]" /></li><br>'; -->




                                <label class="label"><a href="#" onclick="AgregarCampos();">Agregar Sala</a></label>
                                <div id="campos">
                                </div>






                                <!--<div class="field">
                                        <label class="label">Capacidad máxima</label>
                                        <div class="control">
                                            <input class="input" name="capacity" type="number" placeholder="Capacidad del cine" min="1" required="">

                                        </div>
                                    </div>

                                    <div class="field">
                                        <label class="label">Precio de la entrada</label>
                                        <div class="control">
                                            <input class="input" name="ticketPrice" type="number" placeholder="Precio" step=".10" required="">
                                        </div>
                                    </div>-->



                                <div class="field is-grouped centered" style="padding-left: 30%">
                                    <div class="control">
                                        <button class="button is-link" type="submit">Registrar</button>
                                    </div>
                                    <div class="control">
                                        <button class="button is-text" type="reset">Limpiar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>