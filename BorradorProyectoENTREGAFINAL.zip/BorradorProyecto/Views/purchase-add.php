<?php include('top-nav.php');

?>
<!--<script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script> -->


<script type="text/javascript">
    function Calculate() {
        var precioTicket = document.getElementById('priceT').value;
        var cantidad = document.getElementById('quantityT').value;
        var descuento = document.getElementById('discountT').value;
        var calculo = document.getElementById('totalP').value;
        var fecha = document.getElementById('date').value;
        var f = new Date(fecha);
        var n = f.getDay();

        if (((n == 1) && (cantidad >= 2)) || ((n == 2) && (cantidad >= 2))) {
            descuento = (0.25 * parseInt(precioTicket) * cantidad);
            calculo = (0.75 * parseInt(precioTicket) * cantidad);
        } else {
            descuento = 0;
            calculo = (parseInt(precioTicket) * cantidad);
        }


        var totalapagar = document.getElementById('totalapagar');
        var inputTotalP = document.getElementById('totalP');
        var discountTot = document.getElementById('discountT');
        var descuentoFinal = document.getElementById('descuentoFinal');
        descuentoFinal.innerHTML = '$' + descuento;
        discountTot.value = descuento;
        totalapagar.innerHTML = '<strong> $' + calculo + '</strong>';
        inputTotalP.value = calculo;

        var duplicate = document.getElementById('cantDuplicado');
        duplicate.value = cantidad;

    }
</script>
<!--<script type="text/javascript">
    $(document).ready(function() {
        alert(1);
    
    $('#quantityT').on/('change', function() {
        calcular();
    }

    function calcular(){
        var result = 0;
        var precio = $("#priceT").val();
        var cant = $("#quantityT").val();
        var desc = $("#dicountT").val();
        result += (parseFloat(precio) * cant) - parseFloat(desc);
        $("#result").val(result);
    }
});

</script> -->


<div class="columns" id="app-content">
    <?php include('user-aside-nav.php'); ?>

    <div class="column is-10" id="page-content">

        <div class="content-header">
            <h4 class="title is-4">Compra </h4>
            <span class="separator"></span>
            <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                <ul>
                    <li><a href="#">Tickets</a></li>
                    <li class="is-active"><a href="#" aria-current="page">Proyecciones</a></li>
                    <li style="color:red"> <?php if ($message != null) {
                                                echo $message;
                                            } ?></li>
                </ul>
            </nav>
        </div>


        <div class="content-body">
            <div class="card">

                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-10 col-md-offset-1">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th class="text-center">Tickets</th>
                                        <th class="text-center">Cantidad</th>
                                        <th class="text-center">Precio</th>
                                        <th class="text-center">Descuento</th>
                                        <th class="text-center">Total</th>
                                        <th> </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="col-sm-8 col-md-6">
                                            <form action="<?= FRONT_ROOT ?>Purchase/CalculateDiscount" method="post">
                                                <div class="media">
                                                    <a class="thumbnail pull-left" href="#"> <img class="media-object" src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-2/128/ticket-icon.png" style="width: 72px; height: 72px;"> </a>
                                                    <div class="media-body">
                                                        <input type="text" name="idProyection" hidden="true" value="<?= $proyection->getIdProyection(); ?>">
                                                        <h4 class="media-heading">Pelicula: <a href="#"><?= $proyection->getFilm()->getTitle(); ?></a></h4>
                                                        <h5 class="media-heading"> Cine: <a href="#"><?= $proyection->getSala()->getIdCine()->getName(); ?></a></h5>

                                                        <span>Dia: <?= $proyection->getDay(); ?></span><br>
                                                        <input type="text" hidden value="<?= $proyection->getDay(); ?>" id="date">
                                                        <span>Hora: <?= $proyection->getTime(); ?></span>

                                                    </div>
                                                </div>
                                        </td>
                                        <td class="col-sm-1 col-md-1" style="text-align: center">
                                            <input type="number" id="quantityT" name="quantity" class="form-control" placeholder="tkts" value="1" onchange="Calculate();" min="1">
                                        </td>
                                        <td class="col-sm-1 col-md-1 text-center"><strong>$
                                                <?= $proyection->getSala()->getPrice(); ?></strong></td>
                                        <td class="col-sm-1 col-md-1 text-center"><input type="number" hidden id="discountT" name="discount" value=<?= $discount ?>><strong id="descuentoFinal">$</strong></td>
                                        <td class="col-sm-1 col-md-1 text-center" id="totalapagar"><strong>$<?= $proyection->getSala()->getPrice(); ?> </strong></td>
                                        <!--<td class="col-sm-1 col-md-1">
                                <button type="submit" class="btn btn-danger">
                                    <span class="glyphicon glyphicon-remove"></span> Calcular
                                </button>
                            </td>-->
                                        </form>
                                    </tr>

                                    <tr>
                                        <form action="<?= FRONT_ROOT ?>CreditCardPayment/ShowCreditCardView" method="POST">
                                            <td>   </td>
                                            <td>   </td>
                                            <td>   </td>
                                            <td>
                                                <h5></h5>
                                            </td>
                                            <input hidden="" type="number" id="priceT" value="<?= $proyection->getSala()->getPrice(); ?>">
                                            <input hidden="" type="text" name="idProyection" value="<?= $proyection->getIdProyection(); ?>">
                                            <input hidden="" type="number" id="cantDuplicado" name="quantityTickets">
                                            <input hidden="" type="number" name="discount" value="<?= $discount ?>">
                                            <td class="text-right">
                                                <h5><input type="text" hidden="" id="totalP" name="totalPay" value="<?= $total ?>"><strong></strong></label></h5>
                                            </td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td class="text-right">
                                            <button type="submit" class="btn btn-success">
                                                Pagar <span class="glyphicon glyphicon-play"></span>
                                            </button>
                                        </td>
                                    </tr>
                                    </form>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>