<link rel="stylesheet" type="text/css" href="<?= CSS ?>style-3dcarrousel.css">
<script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
<?php include('top-nav.php'); ?>

<div class="carousel" style="margin-top: 5%">
  <?php foreach ($filmList as $film) {
    ?>
    <img src="<?= $film->getUrlImage(); ?>" alt="<?= $film->getTitle(); ?>" />
  <?php } ?><br>

</div>
<center>
  <select>
    <?php foreach ($filmList as $film) { ?>
      <option value="<?= $film->getIdFilm() ?>" onClick="alert('Se');"><?= $film->getTitle(); ?></option><?php } ?>
  </select>
</center>