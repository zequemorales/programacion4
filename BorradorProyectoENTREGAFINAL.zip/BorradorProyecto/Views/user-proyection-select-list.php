<?php include('top-nav.php'); ?>
<link rel="stylesheet" href="<?= CSS ?>bootstrap.min.css" crossorigin="anonymous">

<div class="columns" id="app-content">
    <?php include('user-aside-nav.php'); ?>

    <div class="column is-10" id="page-content">
        <!-- Content Header -->
        <div class="content-header">
            <h4 class="title is-4">General </h4>
            <span class="separator"></span>
            <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                <ul>
                    <li><a href="#">Buscador</a></li>
                    <li class="is-active"><a href="#" aria-current="page">Proyecciones</a></li>
                </ul>
            </nav>
        </div>
        <!-- Content Header END-->

        <!-- Content Body -->
        <div class="content-body">
            <div class="card">
                <!-- Card filtro-->
                <div class="card-filter">
                    <div class="field">
                        <div class="control has-icons-left">
                            <!-- <input class="input" id="table-search" type="text" placeholder="Ingrese Pelicula" value="<?= $idFilm; ?>"> -->
                            <!--<span class="icon is-left">
                                    <i class="fa fa-search"></i>
                            </span>-->
                            <center>
                                <h4 class="title is-4">Pelicula: <?= $proyectionFilmList[0]->getFilm()->getTitle(); ?></h4>
                                <!-- <form action="<?= FRONT_ROOT ?>Film/ShowFichaView" method="post">-->

                                <!--<button class="button is-warning btnEdit" 
                                        value="<?= $proyectionFilmList[0]->getFilm()->getIdFilm(); ?>" 
                                        name="modifyButton2<?= $proyectionFilmList[0]->getFilm()->getIdFilm() ?>" 
                                        id="modifyButton2<?= $proyectionFilmList[0]->getFilm()->getIdFilm() ?>"
                                        type="button"> Ver ficha 
                                </button>-->
                                <!--</form>-->
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                                    Ver ficha
                                </button>
                            </center>

                            <!--------------------------------------------------------------------------------------------->
                            <!------------------------------------------ Modal -------------------------------------------->
                            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLongTitle">
                                                <p class="modal-card-title">Ficha de Pelicula : <?= $filmData->getTitle(); ?></p>
                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="field">
                                                <label class="tag is-link">Descripción:</label>
                                                <label><?= $filmData->getDescription(); ?></label>
                                            </div>
                                            <div class="field">
                                                <label class="tag is-link">Género:</label>
                                                <ul>
                                                    <?php foreach ($filmData->getGenre() as $genre) {
                                                        ?>
                                                        <li><?= $genre->getDescription() ?></li>
                                                    <?php } ?>
                                                </ul>
                                            </div>
                                            <div class="field">
                                                <label class="tag is-link">Idioma: </label><br>
                                                <label><?= $filmData->getLanguage(); ?></label>
                                            </div>

                                            <div class="field">
                                                <label class="tag is-link">Duración:</label><br>
                                                <label><?= $filmData->getDuration(); ?></label>
                                            </div>

                                            <div class="field">
                                                <label class="tag is-link">Poster: </label>
                                                <img src="<?= $filmData->getUrlImage(); ?>">
                                            </div>

                                        </div>
                                        <div class="modal-footer">

                                            <button type="button" class="btn btn-secondary" data-dismiss="modal" style="margin-right: 40%;">
                                                Aceptar
                                            </button>


                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--------------------------------------------- Modal End-------------------------------------------->
                            <!--------------------------------------------------------------------------------------------------->


                        </div>
                    </div>
                </div>
                <!-- Card Contenido -->
                <div class="card-content">
                    <table class="table is-hoverable is-bordered is-fullwidth" id="datatable">
                        <thead>
                            <tr>
                                <th class="has-text-centered"> Cine</th>
                                <th class="has-text-centered"> Sala</th>
                                <th class="has-text-centered"> Dia</th>
                                <th class="has-text-centered"> Horario</th>
                                <th class="has-text-centered"> Finalizacion</th>
                                <!--<th class="has-text-centered"> Disponible </th>-->
                                <th class="has-text-centered"> Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            foreach ($proyectionFilmList as $proyecciones) {
                                ?>
                                <tr>
                                    <td class="has-text-centered"><?= $proyecciones->getSala()->getIdCine()->getName(); ?></td>
                                    <td class="has-text-centered"><?= $proyecciones->getSala()->getName(); ?></td>
                                    <td class="has-text-centered"><?= $proyecciones->getDay(); ?></td>
                                    <td class="has-text-centered"><?= $proyecciones->getTime(); ?></td>
                                    <td class="has-text-centered">
                                        <?php
                                            $date = new DateTime($proyecciones->getTime());
                                            $date->modify('+10 ' . $filmData->getDuration() . 'minute');
                                            $date->modify('+15 minute');
                                            echo $date->format('H:i:s');

                                            ?>
                                    </td>


                                    <!--<td class="has-text-centered">< //$proyecciones->getSala()->getCapacity();?> lugares</td>-->
                                    <td class="has-text-centered">
                                        <!-- CAPACIDAD MENOS TOTAL DE ENTRADAS VENDIDAS -->
                                        <div class="field is-grouped action">
                                            <form action="<?= FRONT_ROOT ?>Purchase/ShowAddView" method="post">
                                                <p class="control">
                                                    <button class="button is-danger" name="BtnDel" data-id="1" value="<?= $proyecciones->getIdProyection(); ?>">
                                                        Comprar
                                                    </button>
                                                </p>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <!-- CArd Contenido END -->
            </div>

        </div>
        <!-- Content Body END -->
    </div>
</div>