<?php

namespace Views;

include('top-nav.php');
?>

<script type="text/javascript">
    $(document).ready(function() {
        $('#cinema').on('change', function() {
            var cinemaID = $(this).val();
            var x = document.getElementById("sala-select");
            // borras select 
            x.options.length = 0;

            <?php foreach ($salasList as $sala) {
                ?>
                if (cinemaID == <?php echo $sala->getIdCine(); ?>) {
                    var option = document.createElement("option");
                    option.text = "<?php echo $sala->getName(); ?>";
                    option.value = "<?php echo $sala->getIdSala(); ?>";
                    x.add(option);

                }
            <?php } ?>

        });
    });
</script>



<div class="columns" id="app-content">
    <?php include('admin-aside-nav.php'); ?>


    <div class="column is-10" id="page-content">
        <div class="content-header">
            <h4 class="title is-4">Dashboard</h4>
            <span class="separator"></span>
            <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                <ul>
                    <li><a href="#">Peliculas</a></li>
                    <li class="is-active"><a href="#" aria-current="page">Alta Proyección</a></li>
                </ul>
            </nav>
        </div>

        <div class="content-body">
            <div class="columns">
                <div class="column">
                    <div class="card">
                        <div class="card-content">
                            <p class="title is-4">Alta Proyección</p>
                            <p style="color: red;font-size: 18px;">
                                <?php
                                if ($message != null) {
                                    echo $message;
                                }
                                ?>
                            </p>
                            <form action="<?= FRONT_ROOT ?>Proyection/Add2" method="POST">

                                <div class="field">
                                    <label class="label">Seleccione película </label>
                                    <div class="control">

                                        <div class="select" style="width: 150%">
                                            <select style="width: 150%" name="title">
                                                <?php foreach ($filmList as $film) {
                                                    ?>
                                                    <option value="<?= $film->getIdFilm(); ?>"><?= $film->getTitle(); ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="field">

                                    <div class="field">
                                        <div class="select" style="width: 150%">
                                            <select style="width: 150%" id="cinema" name="cinema">
                                                <option value="">Seleccione cine</option>

                                                <?php foreach ($cinemaList as $cinema) {
                                                    ?>
                                                    <option value="<?= $cinema->getIdCinema(); ?>"><?= $cinema->getName(); ?></option>
                                                <?php } ?>

                                            </select>
                                        </div>
                                    </div>


                                    <label class="label">Seleccione sala</label>
                                    <div class="field">
                                        <div class="select" style="width: 150%">
                                            <select name="sala" id="sala-select" style="width: 150%">
                                                <option value="">Seleccione sala</option>

                                            </select>
                                        </div>
                                    </div>



                                    <div class="field">
                                        <label class="label">Fecha</label>
                                        <div class="control">

                                            <input class="input" type="date" name="day" min="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" max="<?php echo (date('Y') + 1) . date('-Y-m-d'); ?>">
                                        </div><br>
                                        <label class="label">Horario</label>
                                        <input class=input type="time" name="time" value="10:00">

                                    </div>
                                </div>

                                <div class="field is-grouped centered" style="padding-left: 25%">
                                    <div class="control">
                                        <button class="button is-link">Alta Proyeccion</button>
                                    </div>
                                    <div class="control">
                                        <button class="button is-text" type="reset">Limpiar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>