<?php

namespace Views;

include('top-nav.php');

use Models\film as Film;
use DAO\FilmDAO as FilmDAO;
?>
<html>

<head>
    <meta charset="utf-8">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Peliculas</title>

    <link href="https://fonts.googleapis.com/icon?family=Poppins" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css">
    <link rel="stylesheet" href=<?php CSS ?>"app.css">



</head>

<body>

    <div class="columns" id="app-content">
        <div class="column is-2 is-fullheight is-hidden-touch" id="navigation">
            <aside class="menu">
                <p class="menu-label is-hidden-touch">General</p>
                <ul class="menu-list">
                    <li>
                        <a class="" href="index.html">
                            <span class="icon">
                                <i class="fa fa-home"></i>
                            </span> Dashboard
                        </a>
                    </li>
                    <li>
                        <a class="" href="forms.html">
                            <span class="icon">
                                <i class="fa fa-edit"></i>
                            </span> Forms
                        </a>
                    </li>
                    <li>
                        <a class="" href="elements.html">
                            <span class="icon">
                                <i class="fa fa-desktop"></i>
                            </span> UI Elements
                        </a>
                    </li>
                    <li>
                        <a class="is-active" href="datatables.html">
                            <span class="icon">
                                <i class="fa fa-table"></i>
                            </span> Datatables
                        </a>
                    </li>
                </ul>

                <p class="menu-label is-hidden-touch">Sample Pages</p>
                <ul class="menu-list">
                    <li>
                        <a class="" href="login.html">
                            <span class="icon">
                                <i class="fa fa-lock"></i>
                            </span> Login
                        </a>
                    </li>
                </ul>
            </aside>
        </div>

        <div class="column is-10" id="page-content">
            <div class="content-header">
                <h4 class="title is-4">Listados</h4>
                <span class="separator"></span>
                <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                    <ul>
                        <li><a href="#">Administrar Peliculas</a></li>
                        <li class="is-active"><a href="#" aria-current="page">Listado de Peliculas actuales</a></li>
                    </ul>
                </nav>
            </div>

            <div class="content-body">
                <div class="card">
                    <div class="card-filter">
                        <div class="field">
                            <div class="control has-icons-left has-icons-right">
                                <input class="input" id="table-search" type="text" placeholder="Search for records...">
                                <span class="icon is-left">
                                    <i class="fa fa-search"></i>
                                </span>
                            </div>
                        </div>
                        <div class="field">
                            <div class="select">
                                <select id="table-length">
                                    <option>10</option>
                                    <option>25</option>
                                    <option>50</option>
                                </select>
                            </div>
                        </div>
                        <div class="field has-addons">
                            <p class="control">
                                <a class="button" href="#">
                                    <span class="icon is-small">
                                        <i class="fa fa-plus"></i>
                                    </span>
                                    <span>Create Record</span>
                                </a>
                            </p>
                            <p class="control">
                                <a class="button" id="table-reload">
                                    <span class="icon is-small">
                                        <i class="fa fa-refresh"></i>
                                    </span>
                                    <span>Reload</span>
                                </a>
                            </p>
                        </div>
                    </div>
                    <div class="card-content">
                        <table class="table is-hoverable is-bordered is-fullwidth" id="datatable">
                            <thead>
                                <tr>
                                    <th>Id Película</th>
                                    <th>Título</th>
                                    <th>Género</th>
                                    <th>Idioma</th>
                                    <th>Description</th>
                                    <th>Duración</th>
                                    <th class="has-text-centered">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($filmList as $film) {

                                    ?>
                                    <tr>
                                        <td><?= $film->getIdFilm(); ?></td>
                                        <td><?= $film->getTitle(); ?></td>
                                        <td><?php foreach ($film->getGenre() as $genreValue) {
                                                    foreach ($genreList as $genre) {
                                                        if ($genreValue == $genre->getIdGenre()) {
                                                            echo $genre->getDescription() . '<br>';
                                                        }
                                                    }
                                                }


                                                ?></td>
                                        <td><?= $film->getLanguage(); ?></td>
                                        <td><?= $film->getDescription(); ?></td>
                                        <td><?= $film->getDuration() . ' minutos'; ?></td>
                                        <td class="has-text-centered">

                                            <div class="field is-grouped action">
                                                <p class="control">

                                                    <a class="button is-rounded is-text btnEdit" id="modifyButton2<?= $film->getIdFilm(); ?>" onclick="">
                                                        <span class="icon">
                                                            <i class="fa fa-edit"></i>
                                                        </span>
                                                    </a>
                                                </p>

                                                <p class="control">
                                                    <form action="<?= FRONT_ROOT ?>Film/Delete" method="post">
                                                        <button class="button is-rounded is-text action-delete" name="BtnDel" data-id="1">
                                                            <i class="fa fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </p>

                                            </div>

                                        </td>
                                    </tr>
                                <?php } ?>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!------------------ VENTANA MODAL --------------------------------->
    <div class="modal" id="exampleModal">
        <div class="modal-background"></div>
        <div class="modal-card">
            <header class="modal-card-head">
                <p class="modal-card-title">Modificar pelicula</p>
                <button class="delete" aria-label="close" onclick="document.getElementById('exampleModal').style.display='none'"></button>
            </header>

            <section class="modal-card-body">
                <form action="<?= FRONT_ROOT ?>Cinema/Modify" method="POST">
                    <div class="field">
                        <!-- Id Cine (hidden) -->
                        <div class="control">
                            <input class="input" name="idCinema" type="number" placeholder="Nombre del Cine" id="id" hidden="true">
                        </div>
                    </div>

                    <div class="field">
                        <label class="label">Nombre </label>
                        <div class="control">
                            <input class="input" name="name" type="text" placeholder="Nombre del Cine" id="name">
                        </div>
                    </div>

                    <div class="field">
                        <label class="label">Capacidad máxima</label>
                        <div class="control">
                            <input class="input" name="capacity" type="number" placeholder="Capacidad del cine" id="capacity">
                        </div>
                    </div>

                    <div class="field">
                        <label class="label">Precio de la entrada</label>
                        <div class="control">
                            <input class="input" name="ticketPrice" type="number" placeholder="Precio" step=".10" id="ticketPrice">
                        </div>
                    </div>

                    <div class="field">
                        <label class="label">Direccion</label>
                        <div class="control">
                            <input class="input" name="address" type="text" placeholder="Precio por entrada" id="address">
                        </div>
                    </div>



            </section>

            <footer class="modal-card-foot">
                <button class="button is-success" type="submit">Modificar</button>
                </form>
                <button class="button" onclick="document.getElementById('exampleModal').style.display='none'">Cancel</button>
            </footer>


        </div>
    </div>
    <!------------------ FIN VENTANA MODAL -------------------------->

    <!---------------- < SCRIPTS > -------------------------->
    <script src="<?php echo JS_PATH ?>/app.js"></script>
    <script>
        $(document).ready(function() {
            var table = $('#datatable').DataTable({
                dom: "<'columns table-wrapper'<'column is-12'tr>><'columns table-footer-wrapper'<'column is-5'i><'column is-7'p>>"
            });

            $('#table-search').on('keyup', function() {
                let value = $(this).val();
                table.search(value).draw();
            });

            $('#table-length').on('change', function() {
                let value = $(this).val();
                table.page.len(value).draw();
            });

            $('#table-reload').on('click', function() {
                table.draw();
            });
        });
    </script>

    <!-- SCRIPT PARA CREAR MODALES DINAMICOS -->
    <script type="text/javascript">
        <?php
        foreach ($cinemaList as $value) {
            echo "var boton" . $value->getIdCinema() . "= document.getElementById('modifyButton2" . $value->getIdCinema() . "');";
            echo "boton" . $value->getIdCinema() . ".onclick = function(){
                    modal.style.display = 'block';
                    };";
        }
        ?>
    </script>


    <script type="text/javascript">
        var button = document.getElementById('modifyButton');
        // var botoncito =  document.getElementById('modifyButton2');
        var modal = document.getElementById('exampleModal');
        var close = document.getElementById('modal-close');

        //button.onclick= function(){
        //   modal.style.display = 'block';
        //}
        //botoncito.onclick= function(){
        //  modal.style.display = 'block';
        //}           
    </script>

    <script type="text/javascript">
        var fila;
        // Codigo para boton editar
        $(document).on("click", ".btnEdit", function() {
            fila = $(this).closest("tr");
            id = parseInt(fila.find('td:eq(0)').text());
            name = fila.find('td:eq(1)').text();
            capacity = parseInt(fila.find('td:eq(2)').text());
            ticketPrice = parseInt(fila.find('td:eq(3)').text());
            address = fila.find('td:eq(4)').text();
            alert(address);

            $("#id").val(id);
            $("#name").val(name);
            $("#capacity").val(capacity);
            $("#ticketPrice").val(ticketPrice);
            $("#address").val(address);


        });
    </script>
    <!-- --------------- < SCRIPTS > ------------------------->
</body>


</html>