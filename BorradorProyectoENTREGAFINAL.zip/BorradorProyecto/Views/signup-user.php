<?php

namespace Views;

error_reporting(E_ALL);
ini_set('display_errors', '1');
?>


<head>


    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Registro Usuario</title>
</head>

<body>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


    <div class="container" style="margin-left: 30%; margin-top: 5%;">


        <div class="justify-content-center">
            <div class="brand_logo_container" style="margin-left: 15%">
                <a href="<?= FRONT_ROOT ?>"> <img src="<?php echo FRONT_ROOT . IMG_PATH; ?>logo-reversed.svg" class="brand_logo" alt="Logo"></a>
            </div>
        </div><br><br><br><br>
        <h1 style="margin-left: 10%">ALTA USUARIO</h1>
        <form action="<?= FRONT_ROOT ?>User/Add" method="post">
            <div class="form-row is-center">

                <div class="form-group col-md-6">
                    <label for="inputEmail">Email: </label>
                    <input type="email" name='email' class="form-control" id="inputEmail" placeholder="ejemplo@hotmail.com" required="">

                    <label for="inputPassword">Contraseña: </label>
                    <input type="text" name='password' class="form-control" id="inputPassword" placeholder="Contraseña" required="">

                    <label>Nombre: </label>
                    <input type="text" name='firstName' class="form-control" id="inputName" placeholder="Nombre" required="">

                    <label>Apellido: </label>
                    <input type="text" name='lastName' class="form-control" id="inputLastName" placeholder="Apellido" required="">

                    <label>Dni: </label>
                    <input type="number" name='dni' class="form-control" id="inputDni" placeholder="Dni" required=""><br>

                    <button type="submit" class="btn btn-primary" style="margin-left: 35%">Crear Usuario</button>
                </div>

            </div>
        </form>
    </div>