<div class="column is-2 is-fullheight is-hidden-touch" id="navigation">
    <aside class="menu">
        <ul class="menu-list"><br>
            <li>
                <a class="is-active" href="<?= FRONT_ROOT ?>User/ShowAdminView">
                    <span class="icon">
                        <i class="fa fa-home"></i>
                    </span> Dashboard
                </a>
            </li>
        </ul>
        <p class="menu-label is-hidden-touch">Cines </p>
        <ul class="menu-list">
            <li>
                <a class="" href="<?= FRONT_ROOT ?>Cinema/ShowAddView">
                    <span class="icon">
                        <i class="fa fa-edit"></i>
                    </span> Alta cine
                </a>
            </li>
            <li>
                <a class="" href="<?= FRONT_ROOT ?>Cinema/ShowListView">
                    <span class="icon">
                        <i class="fa fa-list"></i>
                    </span> Listar cines
                </a>
            </li>
            <li>
                <a class="" href="<?= FRONT_ROOT ?>Film/Update">
                    <span class="icon">
                        <i class="fa fa-desktop"></i>
                    </span> Actualizar Base de datos
                </a>
            </li>
        </ul>

        <p class="menu-label is-hidden-touch">Peliculas</p>
        <ul class="menu-list">
            <li>
                <a class="" href="<?= FRONT_ROOT ?>Proyection/ShowAddView">
                    <span class="icon">
                        <i class="fa fa-edit"></i>
                    </span> Alta proyección
                </a>
            </li>
            <li>
                <a class="" href="<?= FRONT_ROOT ?>Film/ShowCarteleraView">
                    <span class="icon">
                        <i class="fa fa-lock"></i>
                    </span> Now playing
                </a>
            </li>
        </ul>
        <p class="menu-label is-hidden-touch">Consultas</p>
        <ul class="menu-list">
            <li>
                <a class="" href="<?= FRONT_ROOT ?>Query/ShowQueryCantView">
                    <span class="icon">
                        <i class="fa fa-edit"></i>
                    </span> Cantidades
                </a>
            </li>
            <li>
                <a class="" href="<?= FRONT_ROOT ?>Query/ShowQueryRecaudationView">
                    <span class="icon">
                        <i class="fa fa-dollar"></i>
                    </span> Recaudación
                </a>
            </li>
        </ul>
    </aside>
</div>