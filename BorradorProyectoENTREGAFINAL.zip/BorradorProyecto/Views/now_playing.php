<?php session_start();
if (isset($_SESSION['page'])) {  // Si la session esta seteada, va avanzando
  $page = $_SESSION['page'];
} else {                            // si no esta seteada, quiere decir que esta en la pagina 1
  $page = 1;
}
if ($_POST) {
  if (isset($_POST['next'])) { // Si esta seteado el post del boton siguiente, le sumo uno

    $next = $_POST['next'];
    $page = $page + 1;
    $_SESSION['page'] = $page;      // guardo en session el numero de pagina.

  }
}
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.themoviedb.org/3/movie/now_playing&api_key=81a2460dbefd7e043882b50c2b6138ce",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => "{}",
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo "<pre>";
  var_dump($response);
  echo "</pre>";
}
echo "<pre>";
//$array_generos = json_decode($response, true);
//print_r($response);
//print_r($arrayNowPlaying);
//print_r($array_generos);
$arrayNowPlaying = json_decode($response);
//echo $array_generos['results'][0]['title'].'<br>';

//print_r($arrayNowPlaying);
echo "</pre>";

//echo $arrayNowPlaying->results[0]->title;
?>

<!DOCTYPE html>
<html>

<head>
  <title></title>
</head>

<body>
  <!--<h1>Peliculas now playing..</h1> -->

  <select>
    <?php foreach ($arrayNowPlaying->results as $key => $value) { ?>
      <option value="<?= $key ?>"><?= $value->title; ?></option>
    <?php } ?>
  </select><br>
  <form action="?" method="POST">
    <button name="next" value="1">SIGUIENTE</button>
  </form>
</body>

</html>