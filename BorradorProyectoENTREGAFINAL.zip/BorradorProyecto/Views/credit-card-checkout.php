<?php include('top-nav.php');
if (!isset($_POST["quantity"]) || $_POST["quantity"] == null) {
    $discount = 0;
    $total = 0;
}
?>

<title>Confirmacion de compra</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="<?= FRONT_ROOT . ASSETS_CSS_PATH ?>styles.css">
<link rel="stylesheet" type="text/css" href="<?= FRONT_ROOT . ASSETS_CSS_PATH ?>demo.css">
</head>

<div class="columns" id="app-content">
    <?php include('user-aside-nav.php'); ?>

    <div class="column is-10" id="page-content">

        <div class="content-header">
            <h4 class="title is-4">Compra </h4>
            <span class="separator"></span>
            <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                <ul>
                    <li><a href="#">Tickets</a></li>
                    <li class="is-active"><a href="#" aria-current="page">Confirmar Compra</a></li>

                </ul>
            </nav>
        </div>

        <div class="content-body">
            <div class="card">
                <div class="container">
                    <div class="container-fluid">

                        <div class="creditCardForm" style="margin-top: 5%">
                            <header>
                                <div class="heading">
                                    <h1 style="color:white; font-size: 22px;">Confirmar compra</h1>
                                    <h1 style="color:white; font-size: 22px;">$ <?= $totalPayment; ?></h1>
                                </div>
                            </header>
                            <div class="payment">
                                <form action="<?= FRONT_ROOT ?>CreditCardPayment/Authorize" method="post">
                                    <div class="form-group owner">

                                        <input type="text" name="idProyection" value="<?= $proyection->getIdProyection(); ?>" hidden="true">
                                        <label for="owner">Titular</label>
                                        <input type="text" class="form-control" id="owner" required="">
                                    </div>
                                    <div class="form-group CVV">
                                        <label for="cvv">CVV</label>
                                        <input type="text" name="authCode" class="form-control" id="cvv" required="">
                                        <input type="number" name="quantityTickets" value="<?= $quantityTickets; ?>" hidden="true">
                                    </div>
                                    <div class="form-group" id="card-number-field">
                                        <label for="cardNumber">Numero de tarjeta</label>
                                        <!--<input type="text" class="form-control" id="cardNumber" name="creditCardNumber">-->
                                        <input type="text" name="creditCardNumber" class="form-control" required="">
                                        <input type="number" name="discount" value="<?= $discount; ?>" hidden="true">
                                        <input type="text" name="totalPay" value="<?= $totalPayment; ?>" hidden="true">
                                    </div>
                                    <div class="form-group" id="expiration-date">
                                        <label>Fecha de Expiración</label>
                                        <select>
                                            <option value="01">Enero</option>
                                            <option value="02">Febrero </option>
                                            <option value="03">Marzo</option>
                                            <option value="04">Abril</option>
                                            <option value="05">Mayo</option>
                                            <option value="06">Junio</option>
                                            <option value="07">Julio</option>
                                            <option value="08">Agosto</option>
                                            <option value="09">Septiembre</option>
                                            <option value="10">Octubre</option>
                                            <option value="11">Noviembre</option>
                                            <option value="12">Deciembre</option>
                                        </select>
                                        <select>
                                            <option value="19"> 2019</option>
                                            <option value="20"> 2020</option>
                                            <option value="21"> 2021</option>
                                            <option value="22"> 2022</option>
                                            <option value="23"> 2023</option>
                                            <option value="24"> 2024</option>

                                        </select>
                                    </div>
                                    <div class="form-group" id="credit_cards">
                                        <img src="<?= FRONT_ROOT . ASSETS_IMG_PATH ?>visa.jpg" id="visa">
                                        <img src="<?= FRONT_ROOT . ASSETS_IMG_PATH ?>mastercard.jpg" id="mastercard">
                                        <img src="<?= FRONT_ROOT . ASSETS_IMG_PATH ?>amex.jpg" id="amex">
                                    </div>

                                    <div class="form-group" id="pay-now" style="padding-left: 10%">
                                        <button style="width: 220px" type="submit" class="btn btn-default">Confirmar</button>

                                        <button type="submit" style="width: 220px" class="btn btn-default">Cancelar</button>
                                    </div>


                                </form>
                            </div>
                        </div>

                        <p class="examples-note">Here are some dummy credit card numbers and CVV codes so you can test out the form:</p>

                        <div class="examples">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Type</th>
                                            <th>Card Number</th>
                                            <th>Security Code</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Visa</td>
                                            <td>4716108999716531</td>
                                            <td>257</td>
                                        </tr>
                                        <tr>
                                            <td>Master Card</td>
                                            <td>5281037048916168</td>
                                            <td>043</td>
                                        </tr>
                                        <tr>
                                            <td>American Express</td>
                                            <td>342498818630298</td>
                                            <td>3156</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>