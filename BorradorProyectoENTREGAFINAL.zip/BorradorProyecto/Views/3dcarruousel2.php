<?php

namespace Views;

include('top-nav.php');
$loggedUser = $_SESSION['loggedUser'];
?>


<head>
    <title>Now playing...</title>


</head>

<div class="columns" id="app-content">
    <?php if ($loggedUser->getRole() == '1') {
        include('admin-aside-nav.php');
    } else {
        include('user-aside-nav.php');
    }
    ?>
    <div class="column is-10" id="page-content">

        <div class="content-header">
            <h4 class="title is-4">Listados</h4>
            <span class="separator"></span>
            <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                <ul>
                    <li><a href="#">Administrar peliculas</a></li>
                    <li class="is-active"><a href="#" aria-current="page">Now Playing...</a></li>
                </ul>
            </nav>
        </div>

        <div class="content-body">
            <div class="columns">
                <div class="column">
                    <div class="card">
                        <div class="card-content">
                            <p class="title is-4">Now Playing...</p>
                            <div class="box">
                                <div class="field select">
                                    <select>
                                        <?php foreach ($filmList as $film) { ?>
                                            <option value="<?= $film->getIdFilm() ?>" onClick="alert('Se');"><?= $film->getTitle(); ?></option><?php } ?>
                                    </select>
                                </div>
                                <div class="field">
                                    <div class="carousel" style="margin-top: 5%">
                                        <?php foreach ($filmList as $film) {
                                            ?>
                                            <img src="<?= $film->getUrlImage(); ?>" alt="<?= $film->getTitle(); ?>" />
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>