<html>

<head>


	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

	<!-- MODAL-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" crossorigin="anonymous">
	<!-- MODAL -->


	<meta http-equiv="X-UA-Compatible" content="IE=edge">



	<link href="https://fonts.googleapis.com/icon?family=Poppins" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css">

	<link rel="stylesheet" href="<?= CSS ?>app.css">
	<link rel="stylesheet" href="<?= CSS ?>estilos.css">

	<script src="<?php echo JS_PATH ?>jquery.min.js"></script>

	<!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>-->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>

	<script type="text/javascript">
		var nextinput = 1;

		function AgregarCampos() {
			nextinput++;
			campo = '<li  class="label" id="labelName' + nextinput + '" >Sala ' + nextinput + ':	<input class="input"  type="text"  id="nameSala' + nextinput + '"&nbsp; name="nameSala[]" value="SALA ' + nextinput + '"  /></li><br><li class="label" id="labelCapacidad' + nextinput + '">Capacidad Sala ' + nextinput + ':<input class="input" type="text" size="20" id="capacidadSala' + nextinput + '"&nbsp; name="capacidad[]"/></li><br><li class="label" id="labelPrecio' + nextinput + '">Precio Ticket Sala ' + nextinput + ':<input class="input" type="text" size="20" id="precioSala' + nextinput + '"&nbsp; name="precio[]" /></li><br>';
			$("#campos").append(campo);
		}
	</script>





</head>

<body id="top">