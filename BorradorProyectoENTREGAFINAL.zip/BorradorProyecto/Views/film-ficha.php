<div class="modal-background"></div>
<div class="modal-card">
    <header class="modal-card-head">
        <?php if ($filmFound != null) { ?>
            <p class="modal-card-title">Ficha de Pelicula : <?= $filmFound->getTitle(); ?></p>

    </header>

    <section class="modal-card-body">

        <div class="field">
            <!-- Id Cine (hidden) -->
            <div class="control">
                <input class="input" name="idCinema" type="number" placeholder="Nombre del Cine" id="id" hidden="true">
            </div>
        </div>



        <div class="field">
            <label class="tag is-link">Descripción:</label>
            <label><?= $filmFound->getDescription(); ?>
            </label>
        </div>

        <div class="field">
            <label class="tag is-link">Género:</label>
            <ul>
                <li>Acción</li>
                <li>Suspenso</li>
            </ul>
        </div>

        <div class="field">
            <label class="tag is-link">Idioma: </label><br>
            <label><?= $filmFound->getLanguage(); ?></label>
        </div>

        <div class="field">
            <label class="tag is-link">Duración:</label><br>
            <label><?= $filmFound->getDuration(); ?> </label>
        </div>

        <div class="field">
            <label class="tag is-link">Poster: </label>
            <img src="<?= $filmFound->getUrlImage(); ?>">
        </div>
    <?php } ?>
    </section>

    <footer class="modal-card-foot">

        <button class="button is-success" onclick="window.history.go(-1); return false;">Aceptar</button>
        <button class="button" onclick="document.getElementById('exampleModal').style.display='none'">Cancel</button>
    </footer>


</div>

<!------------------ FIN FICHA  -------------------------->