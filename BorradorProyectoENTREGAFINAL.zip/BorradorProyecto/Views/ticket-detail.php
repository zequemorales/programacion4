    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">

        <p class="modal-card-title">Detalle de la compra</p>

      </header>

      <section class="modal-card-body">
        <!--Table-->
        <table id="tablePreview" class="table table-hover table-striped table-bordered">
          <!--Table head-->
          <thead>
            <tr>
              <th># ID compra</th>
              <th>Ticket Nro</th>
              <th>Codigo Qr</th>

            </tr>
          </thead>
          <!--Table head-->
          <!--Table body-->
          <tbody><?php foreach ($ticketsByCompraList as $ticket) {
                    ?>
              <tr>
                <th scope="row"><?= $ticket->getPurchase()->getIdPurchase(); ?></th>
                <td><?= $ticket->getTicketNumber(); ?></td>
                <td><img src="<?= $ticket->getQrCode(); ?>"></td>
              </tr>
            <?php } ?>
          </tbody>
          <!--Table body-->
        </table>
        <!--Table-->

      </section>

      <footer class="modal-card-foot">

        <button class="button is-success" onclick="window.history.go(-1); return false;" style="margin-left: 240px;">Aceptar</button>

      </footer>


    </div>
    </div>