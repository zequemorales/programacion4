<?php

namespace Views;

include('top-nav.php');

use models\cinema as Cinema;
use DAO\cinemaDAO as CinemaDAO;
?>

<div class="columns" id="app-content">
    <?php include('admin-aside-nav.php'); ?>


    <div class="column is-10" id="page-content">
        <div class="content-header">
            <h4 class="title is-4">Listados</h4>
            <span class="separator"></span>
            <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                <ul>
                    <li><a href="#">Administrar Cines</a></li>
                    <li class="is-active"><a href="#" aria-current="page">Listado de Cines</a></li>
                    <li style="color:red"><?php if ($message != null) {
                                                echo $message;
                                            } ?></li>
                </ul>
            </nav>
        </div>

        <div class="content-body">
            <div class="card">

                <div class="card-content">
                    <table class="table is-hoverable is-bordered is-fullwidth" id="datatable">
                        <thead>
                            <tr>
                                <th>Id Cine</th>
                                <th>Nombre Cine</th>
                                <!--<th>Capacidad</th>
                                        <th>Precio de la entrada</th>-->
                                <th>Direccion</th>
                                <th>Activo </th>
                                <th class="has-text-centered">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php foreach ($cinemaList as $cinema) {

                                ?>
                                <tr>
                                    <td><?= $cinema->getIdCinema(); ?></td>
                                    <td><?= $cinema->getName(); ?></td>
                                    <!--<td><?php #$cinema->getCapacity();
                                                ?></td>-->
                                    <!--<td><?php #$cinema->getTicketPrice();
                                                ?></td>-->
                                    <td><?= $cinema->getAddress(); ?></td>
                                    <td><?= $cinema->getIsActive(); ?></td>
                                    <td class="has-text-centered">

                                        <div class="field is-grouped action">
                                            <p class="control">

                                                <a class="button is-rounded is-text btnEdit" id="modifyButton2<?= $cinema->getIdCinema(); ?>" onclick="">
                                                    <span class="icon">
                                                        <i class="fa fa-edit"></i>
                                                    </span>
                                                </a>
                                            </p>

                                            <form action="<?= FRONT_ROOT ?>Cinema/Delete" method="post">
                                                <p class="control">
                                                    <button class="button is-rounded is-text action-delete" name="BtnDel" data-id="1" value="<?= $cinema->getIdCinema(); ?>">
                                                        <span class="icon">
                                                            <?php if ($cinema->getIsActive() == 0) {
                                                                    echo "<i class='fa fa-toggle-off'></i>";
                                                                } else {
                                                                    echo "<i class='fa fa-toggle-on'></i>";
                                                                }
                                                                ?>

                                                        </span>
                                                    </button>
                                                </p>
                                            </form>
                                        </div>

                                    </td>
                                </tr>
                            <?php } ?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
<!------------------ VENTANA MODAL --------------------------------->
<div class="modal" id="exampleModal">
    <div class="modal-background"></div>
    <div class="modal-card">
        <header class="modal-card-head">
            <p class="modal-card-title">Modificar cine</p>
            <button class="delete" aria-label="close" onclick="document.getElementById('exampleModal').style.display='none'"></button>
        </header>

        <section class="modal-card-body">
            <form action="<?= FRONT_ROOT ?>Cinema/Modify" method="POST">
                <div class="field">
                    <!-- Id Cine (hidden) -->
                    <div class="control">
                        <input class="input" name="idCinema" type="number" placeholder="Nombre del Cine" id="id" hidden="true">
                    </div>
                </div>

                <div class="field">
                    <label class="label">Nombre </label>
                    <div class="control">
                        <input class="input" name="name" type="text" placeholder="Nombre del Cine" id="name">
                    </div>
                </div>

                <!--<div class="field">
                        <label class="label">Capacidad máxima</label>
                        <div class="control">
                            <input class="input" name="capacity" type="number" placeholder="Capacidad del cine" id="capacity">
                        </div>
                    </div>-->

                <!--<div class="field">
                        <label class="label">Precio de la entrada</label>
                        <div class="control">
                            <input class="input" name="ticketPrice" type="number" placeholder="Precio" step=".10" id="ticketPrice">
                        </div>
                    </div>-->

                <div class="field">
                    <label class="label">Direccion</label>
                    <div class="control">
                        <input class="input" name="address" type="text" placeholder="Direccion" id="address">
                    </div>
                </div>

                <div class="field">
                    <label class="label">Cine activo?: </label>
                    <div class="control">
                        <select class="select" id="active" name="active">
                            <option value="1">Si</option>
                            <option value="0">No</option>
                        </select>

                    </div>
                </div>


        </section>

        <footer class="modal-card-foot">
            <button class="button is-success" type="submit">Modificar</button>
            </form>
            <button class="button" onclick="document.getElementById('exampleModal').style.display='none'">Cancel</button>
        </footer>


    </div>
</div>
<!------------------ FIN VENTANA MODAL -------------------------->

<!---------------- < SCRIPTS > -------------------------->

<script>
    $(document).ready(function() {
        var table = $('#datatable').DataTable({
            dom: "<'columns table-wrapper'<'column is-12'tr>><'columns table-footer-wrapper'<'column is-5'i><'column is-7'p>>"
        });

        $('#table-search').on('keyup', function() {
            let value = $(this).val();
            table.search(value).draw();
        });

        $('#table-length').on('change', function() {
            let value = $(this).val();
            table.page.len(value).draw();
        });

        $('#table-reload').on('click', function() {
            table.draw();
        });
    });
</script>

<!-- SCRIPT PARA CREAR MODALES DINAMICOS -->
<script type="text/javascript">
    <?php
    foreach ($cinemaList as $value) {
        echo "var boton" . $value->getIdCinema() . "= document.getElementById('modifyButton2" . $value->getIdCinema() . "');";
        echo "boton" . $value->getIdCinema() . ".onclick = function(){
                    modal.style.display = 'block';
                    };";
    }
    ?>
</script>


<script type="text/javascript">
    var button = document.getElementById('modifyButton');
    // var botoncito =  document.getElementById('modifyButton2');
    var modal = document.getElementById('exampleModal');
    var close = document.getElementById('modal-close');
</script>

<script type="text/javascript">
    var fila;
    // Codigo para boton editar
    $(document).on("click", ".btnEdit", function() {
        fila = $(this).closest("tr");
        id = parseInt(fila.find('td:eq(0)').text());
        name = fila.find('td:eq(1)').text();
        //capacity = parseInt(fila.find('td:eq(2)').text());
        //ticketPrice = parseInt(fila.find('td:eq(3)').text());
        address = fila.find('td:eq(2)').text();
        active = fila.find('td:eq(3)').text();


        $("#id").val(id);
        $("#name").val(name);
        //$("#capacity").val(capacity);
        //$("#ticketPrice").val(ticketPrice);
        $("#address").val(address);
        $("#active").val(active);


    });
</script>
<!-- --------------- < SCRIPTS > ------------------------->