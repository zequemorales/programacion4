<?php include('top-nav.php'); ?>


<div class="columns" id="app-content">
    <?php include('user-aside-nav.php'); ?>

    <div class="column is-10" id="page-content">

        <div class="content-header">
            <h4 class="title is-4">General </h4>
            <span class="separator"></span>
            <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                <ul>
                    <li><a href="#">Buscador</a></li>
                    <li class="is-active"><a href="#" aria-current="page">Proyecciones</a></li>
                    <li style="color:red"><b><?php if ($message != null) {
                                                    echo $message;
                                                } ?></b></li>
                </ul>
            </nav>
        </div>


        <div class="content-body">
            <div class="card">
                <form action="<?= FRONT_ROOT ?>Proyection/Search" method="POST">
                    <div class="card-filter">
                        <div class="field">
                            <div class="control has-icons-left">
                                <input class="input" id="table-search" type="text" placeholder="Ingrese Pelicula">
                                <span class="icon is-left">
                                    <i class="fa fa-search"></i>
                                </span>

                            </div>
                        </div>


                        <div class="select">
                            <select name="genre">
                                <option value="0">Genero</option>
                                <?php foreach ($genreList as $genre) { ?>
                                    <option value="<?= $genre->getIdGenre(); ?>"><?= $genre->getDescription(); ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="field">
                            <input class="input" name="date" type="date" min="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" max="<?php echo (date('Y') + 1) . date('-Y-m-d'); ?>">
                        </div>
                        <div class="field">
                            <button class="button is-link has-icons-right" type="submit">Buscar</button>
                        </div>
                    </div>
                </form>
                <div class="card-content">
                    <table class="table is-hoverable is-bordered is-fullwidth" id="datatable">
                        <thead>
                            <tr>
                                <th class="has-text-centered"> Cine</th>
                                <th class="has-text-centered"> Pelicula</th>
                                <th class="has-text-centered"> Dia</th>
                                <th class="has-text-centered"> Horario</th>
                                <th class="has-text-centered"> Finalizacion</th>

                                <th class="has-text-centered">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php if ($proyectionList != null) {
                                foreach ($proyectionList as $proyection) {

                                    ?>
                                    <tr>
                                        <td class="has-text-centered"><?= $proyection->getSala()->getIdCine()->getName(); ?></td>
                                        <td class="has-text-centered"><?= $proyection->getFilm()->getTitle(); ?></td>
                                        <td class="has-text-centered"><?= $proyection->getDay(); ?></td>
                                        <td class="has-text-centered"><?= $proyection->getTime(); ?></td>
                                        <td class="has-text-centered">
                                            <?php
                                                    $date = new DateTime($proyection->getTime());
                                                    $date->modify('+' . $proyection->getFilm()->getDuration() . ' minute');
                                                    $date->modify('+15 minute');
                                                    echo $date->format('H:i:s');
                                                    //$proyection->getFilm()->getDuration()+15 . " minutos"; 

                                                    ?>
                                        </td>
                                        <td class="has-text-centered">

                                            <div class="field is-grouped action">
                                                <p class="control">
                                                    <form action="<?= FRONT_ROOT ?>Film/ShowFichaView" method="post">
                                                        <button class="button is-warning btnEdit" value="<?= $proyection->getFilm()->getIdFilm(); ?>" "
                                                                name=" filmID" type="submit">
                                                            Ver ficha

                                                    </form>
                                                </p>

                                                <form action="<?= FRONT_ROOT ?>Purchase/ShowAddView" method="post">
                                                    <p class="control">
                                                        <button class="button is-danger" name="BtnDel" data-id="1" value="<?= $proyection->getIdProyection(); ?>">
                                                            Comprar
                                                        </button>
                                                    </p>
                                                </form>

                                            </div>
                                        </td>
                                    </tr>
                            <?php }
                            } ?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('modal-ficha.php'); ?>


<!--<script type="text/javascript">
       <?php
        foreach ($proyectionList as $value) {
            echo "var boton" . $value->getIdProyection() . "= document.getElementById('modifyButton2" . $value->getIdProyection() . "');";
            echo "boton" . $value->getIdProyection() . ".onclick = function(){
                    modal.style.display = 'block';
                    };";
        }
        ?> 
</script> -->

<script type="text/javascript">
    // var button = document.getElementById('modifyButton');
    var modal = document.getElementById('exampleModal');
    //var close = document.getElementById('modal-close');
</script>