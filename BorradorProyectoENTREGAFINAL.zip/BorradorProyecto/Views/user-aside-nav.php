<div class="column is-2 is-fullheight is-hidden-touch" id="navigation">
    <aside class="menu">
        <p class="menu-label is-hidden-touch"> General</p>
        <ul class="menu-list">
            <li>
                <a class="" href="<?= FRONT_ROOT ?>User/ShowInCartelera">
                    <span class="icon">
                        <i class="fa fa-home"></i>
                    </span> En cartelera
                </a>
            </li>
            <li>
                <a class="" href="<?= FRONT_ROOT ?>User/ShowSearch">
                    <span class="icon">
                        <i class="fa fa-search"></i>
                    </span> Buscador
                </a>
            </li>

        </ul>

        </ul>
        <p class="menu-label is-hidden-touch">Usuario</p>
        <ul class="menu-list">
            <li>
                <a class="" href="<?= FRONT_ROOT ?>User/ShowUserProfile">
                    <span class="icon">
                        <i class="fa fa-user"></i>
                    </span> Mi perfil
                </a>
            </li>
            <li>
                <a class="" href="<?= FRONT_ROOT ?>Query/ShowQueryCart">
                    <span class="icon">
                        <i class="fa fa-shopping-cart"></i>
                    </span> Carrito
                </a>
            </li>
            <li>
                <a class="" href="<?= FRONT_ROOT ?>User/logout">
                    <span class="icon">
                        <i class="fa fa-sign-out"></i>
                    </span> Cerrar sesión
                </a>
            </li>
        </ul>
    </aside>
</div>