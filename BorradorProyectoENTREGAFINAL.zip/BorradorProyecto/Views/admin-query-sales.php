<?php include('top-nav.php'); ?>
<div class="columns" id="app-content">
    <?php include('admin-aside-nav.php') ?>

    <div class="column is-10" id="page-content">
        <div class="content-header">
            <h4 class="title is-4">Dashboard</h4>
            <span class="separator"></span>
            <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                <ul>
                    <li><a href="#">Consultas</a></li>
                    <li class="is-active"><a href="#" aria-current="page">Cantidades y remanentes</a></li>
                </ul>
            </nav>
        </div>

        <div class="content-body">
            <div class="columns">
                <div class="column">
                    <div class="card">
                        <div class="card-content">
                            <p class="title is-2">Por Pelicula</p>
                            <div class="box">
                                <article class="media">
                                    <div class="media-left">
                                        <figure class="image is-64x64">
                                            <img src="https://image.flaticon.com/icons/png/512/24/24654.png" alt="Image">
                                        </figure>
                                    </div>
                                    <div class="media-content">
                                        <form action="<?= FRONT_ROOT ?>Query/QuantityByIdFilm" method="POST">
                                            <div class="content">
                                                <div class="select is-medium">

                                                    <select name="idFilm">
                                                        <?php foreach ($proyectionList as $proyection) { ?>
                                                            <option value="<?= $proyection->getFilm()->getIdFilm(); ?>"><?= $proyection->getFilm()->getTitle(); ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                                <button class="button is-dark" type="submit">Reporte</button>
                                                <?php if ($message1 != null) {
                                                    echo "<p style='color: red'>" . $message1 . "</p>";
                                                } ?>
                                            </div>
                                        </form>
                                    </div>
                                </article>
                            </div>
                            <p class="title is-2">Por Cine</p>

                            <div class="box">
                                <article class="media">
                                    <div class="media-left">
                                        <figure class="image is-64x64">
                                            <img src="https://image.flaticon.com/icons/png/512/24/24654.png" alt="Image">
                                        </figure>
                                    </div>
                                    <div class="media-content">
                                        <form action="<?= FRONT_ROOT ?>Query/QuantityByIdCinema" method="POST">
                                            <div class="content">
                                                <div class="select is-medium">
                                                    <select style="width: 339.479166px" name="idCinema">
                                                        <?php foreach ($proyectionList2 as $proyection) { ?>

                                                            <option value="<?= $proyection->getSala()->getIdCine()->getIdCinema(); ?>">
                                                                <?= $proyection->getSala()->getIdCine()->getName(); ?>

                                                            </option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                                <button class="button is-dark" type="submit">Reporte</button>
                                                <?php if ($message2 != null) {
                                                    echo "<p style='color: red'>" . $message2 . "</p>";
                                                } ?>

                                            </div>
                                        </form>

                                    </div>
                                </article>
                            </div>

                            <p class="title is-2">Por Turno</p>
                            <div class="box">
                                <article class="media">
                                    <div class="media-left">
                                        <figure class="image is-64x64">
                                            <img src="https://image.flaticon.com/icons/png/512/24/24654.png" alt="Image">
                                        </figure>
                                    </div>
                                    <div class="media-content">
                                        <form action="<?= FRONT_ROOT ?>Query/QuantityByTurn" method="POST">
                                            <div class="content">
                                                <div class="select is-medium">
                                                    <select style="width: 339.479166px" name="turn">

                                                        <option value="dia">Dia</option>
                                                        <option value="noche">Noche</option>
                                                        <option value="trasnoche">Trasnoche</option>
                                                    </select>
                                                </div>
                                                <button class="button is-dark" type="submit">Reporte</button>
                                                <?php if ($message3 != null) {
                                                    echo "<p style='color: red'>" . $message3 . "</p>";
                                                } ?>


                                            </div>
                                        </form>

                                    </div>
                                </article>
                            </div>

                            <p class="title is-2">Por Proyeccion</p>

                            <div class="box">
                                <article class="media">
                                    <div class="media-left">
                                        <figure class="image is-64x64">
                                            <img src="https://image.flaticon.com/icons/png/512/24/24654.png" alt="Image">
                                        </figure>
                                    </div>
                                    <div class="media-content">
                                        <form action="<?= FRONT_ROOT ?>Query/GetRemanentByProyection" method="POST">
                                            <div class="content">
                                                <div class="select is-medium">
                                                    <select style="width: 339.479166px" name="idProyection">
                                                        <?php foreach ($proyectionList3 as $proyection) { ?>

                                                            <option value="<?= $proyection->getIdProyection(); ?>">
                                                                <?= $proyection->getIdProyection() . ' - ' . $proyection->getSala()->getIdCine()->getName() . ' - ' . $proyection->getSala()->getName() . ' - ' . $proyection->getFilm()->getTitle() . ' - ' . $proyection->getDay() . ' - ' . $proyection->getTime(); ?>

                                                            </option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                                <button class="button is-dark" type="submit">Reporte</button>
                                                <?php if ($message4 != null) {
                                                    echo "<p style='color: red'>" . $message4 . "</p>";
                                                } ?>

                                            </div>
                                        </form>

                                    </div>
                                </article>
                            </div>


                        </div>
                    </div>



                </div>

            </div>
        </div>
    </div>
</div>