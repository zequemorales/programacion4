<?php

namespace Views;

if ($message != null) {
	echo "<script>alert('" . $message . "');</script>";
}
?>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">


<title>MOVIEPASS</title>



<div class="container h-100">
	<div class="d-flex justify-content-center h-100">
		<div class="user_card">
			<div class="d-flex justify-content-center">
				<div class="brand_logo_container">
					<img src="<?php echo FRONT_ROOT . IMG_PATH; ?>logo-reversed.svg" class="brand_logo" alt="Logo">
				</div>
			</div>
			<div class="d-flex justify-content-center form_container">
				<form action="<?= FRONT_ROOT ?>User/Login" method="POST">
					<div class="input-group mb-3">
						<div class="input-group-append">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="email" name="email" class="form-control input_user" value="" placeholder="email">
					</div>
					<div class="input-group mb-2">
						<div class="input-group-append">
							<span class="input-group-text"><i class="fas fa-key"></i></span>
						</div>
						<input type="password" name="password" class="form-control input_pass" value="" placeholder="password">
					</div>
					<!--<div class="form-group">
							<div class="custom-control custom-checkbox">
								<input type="checkbox" class="custom-control-input" id="customControlInline">
								<label class="custom-control-label" for="customControlInline">Recuerdame</label>
							</div>
						</div>-->
					<div class="d-flex justify-content-center mt-3 login_container">
						<button type="subtmit" name="button" class="btn login_btn"> Login</button>
					</div>
				</form>
			</div>
			<div class="mt-4">
				<div class="d-flex justify-content-center links">
					No estas registrado? <a href="<?= FRONT_ROOT ?>User/ShowRegisterView" class="ml-2">Registrarse</a>
				</div>
				<a href="#">
					<div class="input-group mb-1" style="margin-left: 25%">
						<div class="input-group-append">
							<button class="facebook-button button is-medium"><i class="fab fa-facebook-f"></i></button>
							<label class="form-control">Login </label>
						</div>
					</div>
				</a>
			</div>

			<? php/* 
				$date = '2019-11-01';
				$dia = date("l", strtotime($date));
				echo $dia;*/
			?>

		</div>
	</div>
</div>
</body>

</html>