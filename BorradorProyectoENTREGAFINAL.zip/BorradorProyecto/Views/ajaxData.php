<?php
//Include database configuration file
include('dbConfig.php');

if (isset($_POST["cinema_id"]) && !empty($_POST["cinema_id"])) {
    //Get all state data
    $query = $db->query("SELECT * FROM sala WHERE idCine = " . $_POST['cinema_id'] . " ;");

    //Count total number of rows
    $rowCount = $query->num_rows;

    //Display states list
    if ($rowCount > 0) {
        echo '<option value="">Seleccione sala</option>';
        while ($row = $query->fetch_assoc()) {
            echo '<option value="' . $row['idSala'] . '">' . $row['numeroSala'] . '</option>';
        }
    } else {
        echo '<option value="">Sala no disponible </option>';
    }
}

if (isset($_POST["state_id"]) && !empty($_POST["state_id"])) {
    //Get all city data
    $query = $db->query("SELECT * FROM cities WHERE state_id = " . $_POST['state_id'] . " AND status = 1 ORDER BY city_name ASC");

    //Count total number of rows
    $rowCount = $query->num_rows;

    //Display cities list
    if ($rowCount > 0) {
        echo '<option value="">Select city</option>';
        while ($row = $query->fetch_assoc()) {
            echo '<option value="' . $row['city_id'] . '">' . $row['city_name'] . '</option>';
        }
    } else {
        echo '<option value="">City not available</option>';
    }
}
