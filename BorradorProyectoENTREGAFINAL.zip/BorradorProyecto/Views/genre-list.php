<?php

namespace view;

include('..\repositories\genreRepository.php');
include('..\repositories\IgenreRepository.php');

use repositories\genreRepository as GenreRepository;
use repositories\IgenreRepository as IGenreRepository;
use models\genre as Genre;

$genreList = new GenreRepository();
$genreList = $genreList->RetrieveData2();
echo "<pre>";
print_r($genreList);
echo "</pre>";
?>

<html>
<style type="text/css">
	table {
		font-family: arial, sans-serif;
		border-collapse: collapse;
		width: 20%;
	}

	td,
	th {
		border: 1px solid #dddddd;
		text-align: left;
		padding: 5px;
	}

	tr:nth-child(even) {
		background-color: #dddddd;
	}
</style>

<body>
	<h1>Generos de la API a JSON objets</h1>

	<table>
		<thead>
			<tr>
				<th>ID</th>
				<th>GENERO</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($genreList->genres as $genre) {
				?>
				<tr>
					<td><?= $genre->id; ?></td>
					<td><?= $genre->name; ?></td>
				</tr>
			<?php } ?>
		</tbody>
	</table>



	<h1>Generos desde el json file</h1>
	<table>
		<?php $genreList->SaveData(); ?>
		<?php $genreList->RetrieveData(); ?>
		<thead>
			<tr>
				<th>ID</th>
				<th>GENERO</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($genreList->genres as $genre) {
				?>
				<tr>
					<td><?= $genre->id; ?></td>
					<td><?= $genre->name; ?></td>
				</tr>
			<?php } ?>
		</tbody>
	</table>





</body>


</html>