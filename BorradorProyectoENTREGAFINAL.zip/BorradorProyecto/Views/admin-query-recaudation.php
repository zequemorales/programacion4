<?php include('top-nav.php'); ?>

<div class="columns" id="app-content">
    <?php include('admin-aside-nav.php') ?>

    <div class="column is-10" id="page-content">
        <div class="content-header">
            <h4 class="title is-4">Dashboard</h4>
            <span class="separator"></span>
            <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                <ul>
                    <li><a href="#">Consultas</a></li>
                    <li class="is-active"><a href="#" aria-current="page">Recaudaciones</a></li>
                </ul>
            </nav>
        </div>

        <div class="content-body">
            <div class="columns">
                <div class="column">
                    <div class="card">
                        <div class="card-content">
                            <p class="title is-2">Por Pelicula</p>
                            <div class="box">
                                <article class="media">
                                    <div class="media-left">
                                        <figure class="image is-64x64">
                                            <img src="https://image.flaticon.com/icons/png/512/24/24654.png" alt="Image">
                                        </figure>
                                    </div>
                                    <div class="media-content">
                                        <form action="<?= FRONT_ROOT ?>Query/RecaudationByTitleDate" method="post">
                                            <div class="content">
                                                <div class="select is-medium">
                                                    <select class="select" name="idFilm">
                                                        <?php foreach ($proyectionList as $proyection) { ?>

                                                            <option value="<?= $proyection->getFilm()->getIdFilm(); ?>"><?= $proyection->getFilm()->getTitle(); ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div><br>
                                                <p>Desde</p><input type="date" name="dateFrom" value='2019-01-01' class="input"><br>
                                                <p>Hasta</p><input type="date" name="dateTo" value="<?= date('Y-m-d') ?>" class="input">

                                                <button class="button is-dark" type="submit">Reporte</button>
                                                <?php if ($message != null) {
                                                    echo "<p style='color: red'>" . $message . "</p>";
                                                } ?>
                                            </div>
                                        </form>
                                    </div>
                                </article>
                            </div>

                            <p class="title is-2">Por Cine</p>
                            <div class="box">
                                <article class="media">
                                    <div class="media-left">
                                        <figure class="image is-64x64">
                                            <img src="https://image.flaticon.com/icons/png/512/24/24654.png" alt="Image">
                                        </figure>
                                    </div>
                                    <div class="media-content">
                                        <form action="<?= FRONT_ROOT ?>Query/RecaudationByCinemaDate" method="POST">
                                            <div class="content">
                                                <div class="select is-medium">
                                                    <select style="width: 339.479166px" name="idCinema">
                                                        <?php foreach ($proyectionList2 as $proyection) { ?>

                                                            <option value="<?= $proyection->getSala()->getIdCine()->getIdCinema(); ?>"><?= $proyection->getSala()->getIdCine()->getName(); ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                                <br>
                                                <p>Desde</p><input type="date" value='2019-01-01' name="dateFrom" class="input"><br>
                                                <p>Hasta</p><input type="date" value="<?= date('Y-m-d') ?>" name="dateTo" class="input">
                                                <button class="button is-dark" type="submit">Reporte</button>

                                                <?php if ($message2 != null) {
                                                    echo "<p style='color: red'>" . $message2 . "</p>";
                                                } ?>
                                            </div>
                                            <form>
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>