<?php

namespace Views;

include('top-nav.php');
if ($message != null) {
    echo "<script>confirm('" . $message . "')</script>";
}
?>

<body>

    <div class="columns" id="app-content">
        <?php include('user-aside-nav.php'); ?>



        <div class="column is-10" id="page-content">

            <div class="content-header">
                <h4 class="title is-4">Listados</h4>
                <span class="separator"></span>
                <nav class="breadcrumb has-bullet-separator" aria-label="breadcrumbs">
                    <ul>
                        <li><a href="#"> Peliculas</a></li>
                        <li class="is-active"><a href="#" aria-current="page">Peliculas en proyeccion</a></li>
                    </ul>
                </nav>
            </div>


            <div class="content-body">

                <div class="columns is-4">

                    <table>
                        <tr>
                            <td>
                                <div class='column'>
                                    <div class='box' style='height: 250px; width: 250px;'>
                                        <article class='media'>
                                            <div class='media-left'>
                                                <figure class='image is-128x128'>
                                                    <form action="<?= FRONT_ROOT ?>User/ShowProyectionSelectView" method="post">
                                                        <input type="hidden" name="idFilm" value="<?= $proyectionInCartelera[0]->getFilm()->getIdFilm(); ?>">
                                                        <img src="<?= $proyectionInCartelera[0]->getFilm()->getUrlImage() ?>" alt='Image'>
                                                </figure>
                                            </div>
                                            <div class='media-content'>
                                                <div class='content'>

                                                    <strong>"<?= $proyectionInCartelera[0]->getFilm()->getTitle(); ?>"
                                                    </strong>
                                                    <br>
                                                </div>
                                                <nav class='level is-mobile'>
                                                    <div class='level-right'>
                                                        <a class='level-item' aria-label='reply'>

                                                            <button class="button is-link" style="width: 86px;height: 27px;padding-top: 0px" type="submit">Funciones</button>
                                                        </a>
                                                    </div>
                                                    </form>
                                                </nav>
                                            </div>
                                        </article>
                                    </div>
                                </div>
                            </td>
                            <?php for ($i = 1; $i < count($proyectionInCartelera); $i++) { ?>
                            <?php //Arranca el for desde 1 
                                if ($i % 4 != 0) {

                                    echo "<td>
                                        <div class='column'>
                                            <div class='box' style='margin-right: 0px; height: 250px; width: 250px;'>
                                                <article class='media'>
                                                    <div class='media-left'>
                                                        <figure class='image is-128x128'>
                                                            <img src=" . $proyectionInCartelera[$i]->getFilm()->getUrlImage() . " alt='Image'>
                                                        </figure>
                                                    </div>
                                                    <div class='media-content'>
                                                        <div class='content'>
                                                            
                                                                <strong>" . $proyectionInCartelera[$i]->getFilm()->getTitle() . "  
                                                                 
                                                        </div>
                                                      <form action='ShowProyectionSelectView' method='post'>
                                                        <nav class='level is-mobile'>
                                                        <input type='hidden' name='idFilm' value=" . $proyectionInCartelera[$i]->getFilm()->getIdFilm() . ">
                                                            <div class='level-right'>

                                                                <button class='button is-link' style='width: 86px;height: 27px;padding-top: 0px' type='submit'>Funciones</button>
                                                            </div>
                                                       </form>     
                                                        </nav>
                                                    
                                                    </div>
                                                </article>
                                            </div>
                                        </div>
                                        </td>
                                        ";
                                } else {
                                    if ($i % 4 == 0) {
                                        echo "</tr>
                                            <tr>
                                                <td>
                                        <div class='column'>
                                            <div class='box' style='margin-right: 0px; height: 250px; width: 250px;'>
                                                <article class='media'>
                                                    <div class='media-left'>
                                                        <figure class='image is-128x128'>
                                                            <img src=" . $proyectionInCartelera[$i]->getFilm()->getUrlImage() . " alt='Image'>
                                                        </figure>
                                                    </div>
                                                    <div class='media-content'>
                                                        <div class='content'>
                                                            
                                                                <strong>" . $proyectionInCartelera[$i]->getFilm()->getTitle() . "  

                                                        </div>
                                                        <form action='" . FRONT_ROOT . "User/ShowProyectionSelectView' method='post'>
                                                        <input type='hidden' name=idFilm'" . $proyectionInCartelera[$i]->getFilm()->getIdFilm() . " value=" . $proyectionInCartelera[$i]->getFilm()->getIdFilm() . ">
                                                        <nav class='level is-mobile'>
                                                            <div class='level-right'>
                                                                <button class='button is-link' style='width: 86px;height: 27px;padding-top: 0px' type='submit'>Funciones</button>
                                                            </div>
                                                        </nav>
                                                        </form>
                                                    </div>
                                                </article>
                                            </div>
                                        </div>
                                        </td>";
                                    }
                                }
                            } ?>



                        </tr>
                    </table>
                </div>



            </div>
        </div>

    </div>

    </div>


    <!---------------- < SCRIPTS > -------------------------->

    <!--<script src="<?php echo JS_PATH ?>/app.js"></script>-->

    <script>
        function captureIdFilm() {
            var idFilm = document.getElementById("selectPelicula").value;
            alert(idFilm);
        }
    </script>