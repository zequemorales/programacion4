<!------------------ VENTANA MODAL --------------------------------->
<div class="modal" id="exampleModal">
    <div class="modal-background"></div>
    <div class="modal-card">
        <header class="modal-card-head">
            <p class="modal-card-title">Ficha de Pelicula : Toy Story 4</p>
            <button class="delete" aria-label="close" onclick="document.getElementById('exampleModal').style.display='none'"></button>
        </header>

        <section class="modal-card-body">

            <div class="field">
                <!-- Id Cine (hidden) -->
                <div class="control">
                    <input class="input" name="idCinema" type="number" placeholder="Nombre del Cine" id="id" hidden="true">
                </div>
            </div>



            <div class="field">
                <label class="tag is-link">Descripción:</label>
                <label>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </label>
            </div>

            <div class="field">
                <label class="tag is-link">Género:</label>
                <ul>
                    <li>Acción</li>
                    <li>Suspenso</li>
                </ul>
            </div>

            <div class="field">
                <label class="tag is-link">Idioma: </label><br>
                <label>English</label>
            </div>

            <div class="field">
                <label class="tag is-link">Duración:</label><br>
                <label>132 minutos </label>
            </div>

            <div class="field">
                <label class="tag is-link">Poster: </label>
                <img src="https://image.tmdb.org/t/p/w185_and_h278_bestv2/aMpyrCizvSdc0UIMblJ1srVgAEF.jpg">
            </div>

        </section>

        <footer class="modal-card-foot">

            <button class="button is-success" type="submit">Aceptar</button>
            <button class="button" onclick="document.getElementById('exampleModal').style.display='none'">Cancel</button>
        </footer>


    </div>
</div>
<!------------------ FIN VENTANA MODAL -------------------------->