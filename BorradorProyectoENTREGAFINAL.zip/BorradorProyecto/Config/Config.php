<?php

namespace Config;

define("ROOT", dirname(__DIR__) . "/");
//Path to your project's root folder
define("FRONT_ROOT", "/2019/BorradorProyecto/");
define("VIEWS_PATH", "Views/");
define("CSS", FRONT_ROOT . VIEWS_PATH . "css/");
define("CSS_PATH", FRONT_ROOT . VIEWS_PATH . "layout/styles/");
define("JS_PATH", FRONT_ROOT . VIEWS_PATH . "js/");
define("IMG_PATH", VIEWS_PATH . "images/");

define("ASSETS_PATH", VIEWS_PATH . "assets/");
define("ASSET_JS_PATH", ASSETS_PATH . "js/");
define("ASSETS_IMG_PATH", ASSETS_PATH . "images/");
define("ASSETS_CSS_PATH", ASSETS_PATH . "css/");


define("DB_HOST", "localhost");
define("DB_NAME", "test_cinema1");
define("DB_USER", "root");
define("DB_PASS", "");
