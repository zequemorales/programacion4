<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.themoviedb.org/3/genre/movie/list?language=en-US&api_key=81a2460dbefd7e043882b50c2b6138ce",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => "{}",
));


$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo "1";
  var_dump($response);
}
// $array_generos = json_decode($response, true); Con true hace un json de arrays
$array_generos = json_decode($response);
echo "<pre>";
print_r($array_generos);
echo "</pre>";
echo $array_generos->genres[0]->name;  // ACTION
//echo $array_generos['genres'][0]['name']."<br>";
//echo $array_generos['genres'][1]['name']."<br>";
//echo $array_generos['genres'][2]['name']."<br>";

?>


<!DOCTYPE html>
<html>

<head>
  <title></title>
</head>

<body>
  <h1>Peliculas "now playing.."</h1>
  <select>

  </select>


  <h1>Generos de las peliculas</h1>
  <select>
    <?php foreach ($array_generos->genres as $key => $value) { ?>
      <option value="<?= $key ?>"> <?= $value->name .  " = " . $value->id; ?></option>
    <?php
    }
    ?>
  </select>
</body>

</html>